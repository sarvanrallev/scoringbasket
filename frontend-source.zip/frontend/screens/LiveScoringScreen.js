import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Modal,
  FlatList,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { gamesAPI } from '../services/apiService';
import { COLORS, SPACING, STORAGE_KEYS, API_BASE_URL } from '../config';

export default function LiveScoringScreen() {
  const router = useRouter();
  const { gameId, start } = useLocalSearchParams();
  
  const [game, setGame] = useState(null);
  const [scoreboard, setScoreboard] = useState(null);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const [showPlayerModal, setShowPlayerModal] = useState(false);
  const [showEventModal, setShowEventModal] = useState(false);
  const [currentPeriod, setCurrentPeriod] = useState(1);
  const [roster, setRoster] = useState([]);
  const [quarterScores, setQuarterScores] = useState({
    1: { home: 0, away: 0 },
    2: { home: 0, away: 0 },
    3: { home: 0, away: 0 },
    4: { home: 0, away: 0 }
  });
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [eventType, setEventType] = useState(null); // 'score', 'foul', 'violation'
  const [isTimeoutActive, setIsTimeoutActive] = useState(false);
  const [timeoutStartTime, setTimeoutStartTime] = useState(null);

  useEffect(() => {
    console.log('LiveScoringScreen mounted with gameId:', gameId);
    if (gameId) {
      loadGameData();
    } else {
      console.error('No gameId provided to LiveScoringScreen');
      Alert.alert('Error', 'No game ID provided');
    }
  }, [gameId]);

  const loadGameData = async () => {
    try {
      setLoading(true);
      console.log('Loading game data for gameId:', gameId);
      
      const [gameData, eventsData] = await Promise.all([
        gamesAPI.getGame(gameId).catch(err => {
          console.error('Error loading match:', err);
          throw err;
        }),
        gamesAPI.getGameEvents(gameId).catch(err => {
          console.error('Error loading events:', err);
          return []; // Return empty array if events fail
        })
      ]);
      
      console.log('Game data loaded:', { gameData, eventsData });
      
      setGame(gameData);
      setEvents(eventsData || []);
      
      // Load current user and check admin status
      let userData = await AsyncStorage.getItem(STORAGE_KEYS.USER);
      let user;
      
      if (!userData) {
        // Try to get user data from API if we have a token
        const token = await AsyncStorage.getItem(STORAGE_KEYS.TOKEN);
        if (token) {
          try {
            console.log('Fetching user data from API...');
            const userResponse = await fetch(`${API_BASE_URL}/auth/me`, {
              headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
              },
            });
            
            if (userResponse.ok) {
              const userFromApi = await userResponse.json();
              user = userFromApi;
              // Store user data for future use
              await AsyncStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(userFromApi));
              console.log('User data fetched and stored:', userFromApi);
            } else {
              console.error('Failed to fetch user data from API');
              throw new Error('Failed to fetch user data');
            }
          } catch (error) {
            console.error('Error fetching user data:', error);
            Alert.alert('Authentication Required', 'You need to log in to access this feature.', [
              { text: 'OK', onPress: () => router.replace('/login') }
            ]);
            return;
          }
        } else {
          console.error('No user data or token found in AsyncStorage - user not logged in!');
          Alert.alert('Authentication Required', 'You need to log in to access this feature.', [
            { text: 'OK', onPress: () => router.replace('/login') }
          ]);
          return;
        }
      } else {
        user = JSON.parse(userData);
      }
      
      setCurrentUser(user);
      
      // Check if user is admin (game creator or team admin)
      const isGameCreator = gameData.created_by && parseInt(gameData.created_by) === parseInt(user.id);
      const isHomeTeamAdmin = gameData.home_team?.owner_id && parseInt(gameData.home_team.owner_id) === parseInt(user.id);
      const isAwayTeamAdmin = gameData.away_team?.owner_id && parseInt(gameData.away_team.owner_id) === parseInt(user.id);
      
      console.log('LiveScoring Admin check:', {
        userId: user.id,
        userIdType: typeof user.id,
        userEmail: user.email,
        gameCreator: gameData.created_by,
        gameCreatorType: typeof gameData.created_by,
        homeTeamOwner: gameData.home_team?.owner_id,
        homeTeamOwnerType: typeof gameData.home_team?.owner_id,
        awayTeamOwner: gameData.away_team?.owner_id,
        awayTeamOwnerType: typeof gameData.away_team?.owner_id,
        isGameCreator,
        isHomeTeamAdmin,
        isAwayTeamAdmin,
        gameStatus: gameData.status
      });
      
      setIsAdmin(isGameCreator || isHomeTeamAdmin || isAwayTeamAdmin);
      
      // Set timeout state from game data
      setIsTimeoutActive(gameData?.timeout_active || false);
      setTimeoutStartTime(gameData?.timeout_started_at || null);
      
      const allPlayers = [...gameData.home_players, ...gameData.away_players];
      setRoster(allPlayers);
      
      // Initialize quarter scores from events or set to zero
      const calculatedQuarterScores = {
        1: { home: 0, away: 0 },
        2: { home: 0, away: 0 },
        3: { home: 0, away: 0 },
        4: { home: 0, away: 0 }
      };

      if (eventsData) {
        eventsData.forEach(event => {
          if ((event.event_type === '2PT' || event.event_type === '3PT' || event.event_type === 'FT') && event.outcome === 'made') {
            const points = event.event_type === '2PT' ? 2 : event.event_type === '3PT' ? 3 : 1;
            const isHomeTeam = event.team_id === gameData.home_team_id;
            const team = isHomeTeam ? 'home' : 'away';
            calculatedQuarterScores[event.period][team] += points;
          } else if (event.event_type === 'SCORE_ADJUST') {
            // Manual score adjustment (positive)
            const isHomeTeam = event.team_id === gameData.home_team_id;
            const team = isHomeTeam ? 'home' : 'away';
            calculatedQuarterScores[event.period][team] += (event.points || 1);
          } else if (event.event_type === 'SCORE_ADJUST_NEG') {
            // Manual score adjustment (negative)
            const isHomeTeam = event.team_id === gameData.home_team_id;
            const team = isHomeTeam ? 'home' : 'away';
            calculatedQuarterScores[event.period][team] -= (event.points || 1);
          }
        });
      }

      setQuarterScores(calculatedQuarterScores);
      
      // Set scoreboard from match data
      setScoreboard({
        home_score: gameData?.home_score || 0,
        away_score: gameData?.away_score || 0,
        period: 1 // Default to quarter 1
      });

      // Auto-start the game if requested and it's scheduled
      if (start === 'true' && gameData?.status === 'scheduled') {
        console.log('Auto-starting scheduled game...');
        try {
          await gamesAPI.updateGame(gameId, { status: 'in_progress' });
          // Reload data to get updated status
          const updatedGameData = await gamesAPI.getGame(gameId);
          setGame(updatedGameData);
          setCurrentPeriod(1);
          Alert.alert('Success', 'Match started! You can now begin scoring.');
        } catch (startError) {
          console.error('Error starting game:', startError);
          Alert.alert('Error', 'Failed to start the match automatically');
        }
      }
    } catch (error) {
      console.error('loadGameData error:', error);
      Alert.alert('Error', `Failed to load match data: ${error.message || 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  const startGame = async () => {
    try {
      await gamesAPI.updateGame(gameId, { status: 'in_progress' });
      await loadGameData();
      Alert.alert('Success', 'Match started!');
    } catch (error) {
      Alert.alert('Error', error.message || 'Failed to start match');
    }
  };

  const endGame = async () => {
    Alert.alert(
      'End Match',
      'Are you sure you want to end this match? This will calculate player statistics.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'End Match',
          style: 'destructive',
          onPress: async () => {
            try {
              const response = await gamesAPI.finalizeGame(gameId);
              await loadGameData();
              Alert.alert(
                'Success',
                `Match ended! Stats calculated for ${response.player_stats?.length || 0} players.`
              );
            } catch (error) {
              console.error('Error ending game:', error);
              Alert.alert('Error', error.message || 'Failed to end match');
            }
          }
        }
      ]
    );
  };

  const selectTeamAndPlayer = (team, type) => {
    setSelectedTeam(team);
    setEventType(type);
    setShowPlayerModal(true);
  };

  const selectPlayer = (player) => {
    setSelectedPlayer(player);
    setShowPlayerModal(false);
    setShowEventModal(true);
  };

  const recordEvent = async (eventType, outcome = null) => {
    if (!selectedPlayer || !selectedTeam) {
      Alert.alert('Error', 'Please select a player first');
      return;
    }

    try {
      const eventData = {
        user_id: selectedPlayer.user_id,
        team_id: selectedTeam === 'home' ? game.home_team_id : game.away_team_id,
        event_type: eventType,
        period: currentPeriod,
        timestamp: Math.floor(Date.now() / 1000),
        outcome: outcome
      };

      await gamesAPI.recordGameEvent(gameId, eventData);

      // Update score if it's a made shot
      if ((eventType === '2PT' || eventType === '3PT' || eventType === 'FT') && outcome === 'made') {
        const points = eventType === '2PT' ? 2 : eventType === '3PT' ? 3 : 1;
        const scoreUpdate = selectedTeam === 'home'
          ? { home_score: (scoreboard?.home_score || 0) + points, away_score: scoreboard?.away_score || 0 }
          : { home_score: scoreboard?.home_score || 0, away_score: (scoreboard?.away_score || 0) + points };

        await gamesAPI.updateGameScore(gameId, scoreUpdate);
      }

      await loadGameData();
      setShowEventModal(false);
      setSelectedPlayer(null);
      setSelectedTeam(null);
      setEventType(null);
    } catch (error) {
      Alert.alert('Error', error.message || 'Failed to record event');
    }
  };

  const recordTeamEvent = async (team, eventType) => {
    try {
      const eventData = {
        team_id: team === 'home' ? game.home_team_id : game.away_team_id,
        event_type: eventType,
        period: currentPeriod,
        timestamp: Math.floor(Date.now() / 1000),
      };

      await gamesAPI.recordGameEvent(gameId, eventData);
      await loadGameData();
    } catch (error) {
      Alert.alert('Error', error.message || 'Failed to record event');
    }
  };

  const getTeamPlayers = (teamId) => {
    return roster.filter(player => player.team_id === teamId);
  };

  const getQuarterScore = (team) => {
    return quarterScores[currentPeriod]?.[team] || 0;
  };

  const handleTimeoutStart = async () => {
    Alert.alert(
      'Start Timeout',
      'This will disable all scoring until timeout is revoked.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Start Timeout',
          style: 'destructive',
          onPress: async () => {
            try {
              const token = await AsyncStorage.getItem(STORAGE_KEYS.TOKEN);
              const response = await fetch(`${API_BASE_URL}/games/${gameId}/timeout`, {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${token}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action: 'start' })
              });
              
              if (response.ok) {
                setIsTimeoutActive(true);
                setTimeoutStartTime(new Date());
                Alert.alert('Timeout Started', 'Scoring is now disabled. Tap "Revoke Timeout" to resume.');
              } else {
                Alert.alert('Error', 'Failed to start timeout');
              }
            } catch (error) {
              Alert.alert('Error', error.message || 'Failed to start timeout');
            }
          }
        }
      ]
    );
  };

  const handleTimeoutRevoke = async () => {
    Alert.alert(
      'Revoke Timeout',
      'This will enable scoring again.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Revoke Timeout',
          onPress: async () => {
            try {
              const token = await AsyncStorage.getItem(STORAGE_KEYS.TOKEN);
              const response = await fetch(`${API_BASE_URL}/games/${gameId}/timeout`, {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${token}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action: 'revoke' })
              });
              
              if (response.ok) {
                setIsTimeoutActive(false);
                setTimeoutStartTime(null);
                Alert.alert('Timeout Revoked', 'Scoring is now enabled.');
              } else {
                Alert.alert('Error', 'Failed to revoke timeout');
              }
            } catch (error) {
              Alert.alert('Error', error.message || 'Failed to revoke timeout');
            }
          }
        }
      ]
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.PRIMARY} />
        <Text style={styles.loadingText}>Loading game...</Text>
      </View>
    );
  }

  if (!game) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Game not found</Text>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const homeTeamPlayers = getTeamPlayers(game.home_team_id);
  const awayTeamPlayers = getTeamPlayers(game.away_team_id);

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.backText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>🏀 Live Scoring</Text>
        <TouchableOpacity onPress={loadGameData}>
          <Text style={styles.refreshText}>↻</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        {/* Small Total Score View at Top */}
        <View style={styles.smallTotalScoreboard}>
          <View style={styles.smallTeamScore}>
            <Text style={styles.smallTeamName}>{game.home_team?.name || 'Home'}</Text>
            <Text style={styles.smallScore}>
              {Object.values(quarterScores).reduce((sum, quarter) => sum + quarter.home, 0)}
            </Text>
          </View>

          <View style={styles.smallGameInfo}>
            <Text style={styles.smallScoreLabel}>TOTAL</Text>
          </View>

          <View style={styles.smallTeamScore}>
            <Text style={styles.smallTeamName}>{game.away_team?.name || 'Away'}</Text>
            <Text style={styles.smallScore}>
              {Object.values(quarterScores).reduce((sum, quarter) => sum + quarter.away, 0)}
            </Text>
          </View>
        </View>

        {/* Current Quarter Scoring View */}
        <View style={styles.quarterScoringView}>
          <View style={styles.quarterHeader}>
            <Text style={styles.quarterTitle}>Quarter {currentPeriod} Scoring</Text>
          </View>

          {/* Quarter Scoreboard */}
          <View style={styles.quarterScoreboard}>
            <View style={styles.quarterTeamScore}>
              <Text style={styles.quarterTeamName}>{game.home_team?.name || 'Home'}</Text>
              <Text style={styles.quarterScore}>{getQuarterScore('home')}</Text>
            </View>

            <View style={styles.quarterGameInfo}>
              <Text style={styles.quarterLabel}>Q{currentPeriod}</Text>
            </View>

            <View style={styles.quarterTeamScore}>
              <Text style={styles.quarterTeamName}>{game.away_team?.name || 'Away'}</Text>
              <Text style={styles.quarterScore}>{getQuarterScore('away')}</Text>
            </View>
          </View>

          {/* Scoring Actions */}
          {game.status === 'in_progress' && isAdmin && (
            <>
              {/* Timeout Status Message */}
              {isTimeoutActive && (
                <View style={styles.timeoutWarning}>
                  <Text style={styles.timeoutWarningText}>⏱️ TIMEOUT ACTIVE - Scoring Disabled</Text>
                </View>
              )}

              {/* Home Team Actions */}
              <View style={[styles.teamSection, { backgroundColor: '#F0F9FF', borderLeftWidth: 4, borderLeftColor: '#4F46E5' }]}>
                <Text style={styles.sectionTitle}>🏠 {game.home_team?.name || 'Home Team'}</Text>
                <View style={styles.actionGrid}>
                  <TouchableOpacity
                    style={[styles.actionButton, styles.scoreButton, isTimeoutActive && styles.buttonDisabled]}
                    disabled={isTimeoutActive}
                    onPress={() => selectTeamAndPlayer('home', 'score')}
                  >
                    <Ionicons name="basketball-outline" size={24} color="#FFF" />
                    <Text style={styles.actionButtonText}>SCORE</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.actionButton, styles.foulButton, isTimeoutActive && styles.buttonDisabled]}
                    disabled={isTimeoutActive}
                    onPress={() => selectTeamAndPlayer('home', 'foul')}
                  >
                    <Ionicons name="flag-outline" size={24} color="#FFF" />
                    <Text style={styles.actionButtonText}>FOUL</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.actionButton, styles.violationButton, isTimeoutActive && styles.buttonDisabled]}
                    disabled={isTimeoutActive}
                    onPress={() => selectTeamAndPlayer('home', 'violation')}
                  >
                    <Ionicons name="warning-outline" size={20} color="#FFF" />
                    <Text style={styles.actionButtonText}>VIOL</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.actionButton, styles.timeoutButton]}
                    onPress={isTimeoutActive ? handleTimeoutRevoke : handleTimeoutStart}
                  >
                    <Ionicons name="time-outline" size={20} color="#FFF" />
                    <Text style={styles.actionButtonText}>{isTimeoutActive ? 'REVOKE' : 'TIMEOUT'}</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Away Team Actions */}
              <View style={[styles.teamSection, { backgroundColor: '#F0F9FF', borderLeftWidth: 4, borderLeftColor: '#4F46E5' }]}>
                <Text style={styles.sectionTitle}>🚀 {game.away_team?.name || 'Away Team'}</Text>
                <View style={styles.actionGrid}>
                  <TouchableOpacity
                    style={[styles.actionButton, styles.scoreButton, isTimeoutActive && styles.buttonDisabled]}
                    disabled={isTimeoutActive}
                    onPress={() => selectTeamAndPlayer('away', 'score')}
                  >
                    <Ionicons name="basketball-outline" size={20} color="#FFF" />
                    <Text style={styles.actionButtonText}>SCORE</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.actionButton, styles.foulButton, isTimeoutActive && styles.buttonDisabled]}
                    disabled={isTimeoutActive}
                    onPress={() => selectTeamAndPlayer('away', 'foul')}
                  >
                    <Ionicons name="flag-outline" size={20} color="#FFF" />
                    <Text style={styles.actionButtonText}>FOUL</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.actionButton, styles.violationButton, isTimeoutActive && styles.buttonDisabled]}
                    disabled={isTimeoutActive}
                    onPress={() => selectTeamAndPlayer('away', 'violation')}
                  >
                    <Ionicons name="warning-outline" size={20} color="#FFF" />
                    <Text style={styles.actionButtonText}>VIOL</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.actionButton, styles.timeoutButton]}
                    onPress={isTimeoutActive ? handleTimeoutRevoke : handleTimeoutStart}
                  >
                    <Ionicons name="time-outline" size={20} color="#FFF" />
                    <Text style={styles.actionButtonText}>{isTimeoutActive ? 'REVOKE' : 'TIMEOUT'}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </>
          )}
        </View>

        {/* Non-admin message */}
        {game.status === 'in_progress' && !isAdmin && (
          <View style={styles.viewerMessageContainer}>
            <Text style={styles.viewerMessage}>
              You can view the live scoring, but only admins can make changes.
            </Text>
          </View>
        )}

        {/* Old Scoreboard - keeping for reference but will be removed */}
        {/* <View style={styles.scoreboard}>
          <View style={styles.teamScore}>
            <Text style={styles.teamName}>{game.home_team?.name || 'Home'}</Text>
            <Text style={styles.score}>{scoreboard?.home_team?.points || 0}</Text>
            <Text style={styles.fouls}>Fouls: {scoreboard?.home_team?.fouls || 0}</Text>
          </View>

          <View style={styles.gameInfo}>
            <Text style={styles.period}>Q{currentPeriod}</Text>
            <Text style={styles.status}>{game.status}</Text>
          </View>

          <View style={styles.teamScore}>
            <Text style={styles.teamName}>{game.away_team?.name || 'Away'}</Text>
            <Text style={styles.score}>{scoreboard?.away_team?.points || 0}</Text>
            <Text style={styles.fouls}>Fouls: {scoreboard?.away_team?.fouls || 0}</Text>
          </View>
        </View> */}

        {/* Game Controls */}
        <View style={styles.gameControls}>
          {game.status === 'scheduled' && isAdmin && (
            <TouchableOpacity style={styles.startButton} onPress={startGame}>
              <Text style={styles.buttonText}>▶ Start Game</Text>
            </TouchableOpacity>
          )}

          {game.status === 'in_progress' && isAdmin && (
            <>
              <TouchableOpacity 
                style={styles.controlButton} 
                onPress={() => setCurrentPeriod(Math.max(1, currentPeriod - 1))}
              >
                <Text style={styles.buttonText}>◀ Previous Quarter</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.controlButton} 
                onPress={() => setCurrentPeriod(Math.min(4, currentPeriod + 1))}
              >
                <Text style={styles.buttonText}>Next Quarter ▶</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.endButton} onPress={endGame}>
                <Text style={[styles.buttonText, {fontSize: 18, fontWeight: 'bold'}]}>■ END GAME</Text>
              </TouchableOpacity>
            </>
          )}
        </View>

        {game.status === 'completed' && (
          <View style={styles.completedMessage}>
            <Text style={styles.completedText}>✓ Game Completed</Text>
          </View>
        )}
      </ScrollView>

      {/* Player Selection Modal */}
      <Modal
        visible={showPlayerModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowPlayerModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Select Player</Text>
              <TouchableOpacity onPress={() => {
                setShowPlayerModal(false);
                setSelectedTeam(null);
                setEventType(null);
              }}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>

            <FlatList
              data={selectedTeam === 'home' ? homeTeamPlayers : awayTeamPlayers}
              keyExtractor={(item) => item.id.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.playerItem}
                  onPress={() => selectPlayer(item)}
                >
                  <View style={styles.playerInfo}>
                    <Text style={styles.playerNumber}>#{item.jersey_number || '?'}</Text>
                    <Text style={styles.playerName}>{item.name || 'Unknown'}</Text>
                  </View>
                  <Text style={styles.playerPosition}>{item.position || '-'}</Text>
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                <Text style={styles.emptyText}>No players in roster</Text>
              }
            />
          </View>
        </View>
      </Modal>

      {/* Event Type Modal */}
      <Modal
        visible={showEventModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowEventModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Record Event</Text>
              <TouchableOpacity onPress={() => {
                setShowEventModal(false);
                setSelectedPlayer(null);
                setSelectedTeam(null);
                setEventType(null);
              }}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>

            {selectedPlayer && (
              <Text style={styles.selectedPlayerText}>
                #{selectedPlayer.jersey_number || '?'} {selectedPlayer.name || 'Unknown Player'}
              </Text>
            )}

            <ScrollView style={styles.eventOptions}>
              {/* Scoring Events */}
              {eventType === 'score' && (
                <View style={styles.eventSection}>
                  <Text style={styles.eventSectionTitle}>Scoring</Text>
                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('2PT', 'made')}
                  >
                    <Text style={styles.eventOptionText}>2-Point Made</Text>
                    <Text style={styles.eventPoints}>+2</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('2PT', 'miss')}
                  >
                    <Text style={styles.eventOptionText}>2-Point Miss</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('3PT', 'made')}
                  >
                    <Text style={styles.eventOptionText}>3-Point Made</Text>
                    <Text style={styles.eventPoints}>+3</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('3PT', 'miss')}
                  >
                    <Text style={styles.eventOptionText}>3-Point Miss</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FT', 'made')}
                  >
                    <Text style={styles.eventOptionText}>Free Throw Made</Text>
                    <Text style={styles.eventPoints}>+1</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FT', 'miss')}
                  >
                    <Text style={styles.eventOptionText}>Free Throw Miss</Text>
                  </TouchableOpacity>
                </View>
              )}

              {/* Foul Events */}
              {eventType === 'foul' && (
                <View style={styles.eventSection}>
                  <Text style={styles.eventSectionTitle}>Common Personal Fouls (Contact)</Text>
                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_BLOCKING')}
                  >
                    <Text style={styles.eventOptionText}>Blocking</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_CHARGING')}
                  >
                    <Text style={styles.eventOptionText}>Charging</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_HOLDING')}
                  >
                    <Text style={styles.eventOptionText}>Holding</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_PUSHING')}
                  >
                    <Text style={styles.eventOptionText}>Pushing</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_HAND_CHECKING')}
                  >
                    <Text style={styles.eventOptionText}>Illegal Use of Hands/Hand-Checking</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_ILLEGAL_SCREEN')}
                  >
                    <Text style={styles.eventOptionText}>Illegal Screen (Moving Screen)</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_ELBOWING')}
                  >
                    <Text style={styles.eventOptionText}>Elbowing</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('FOUL_SHOOTING')}
                  >
                    <Text style={styles.eventOptionText}>Shooting Foul</Text>
                  </TouchableOpacity>
                </View>
              )}

              {/* Violation Events */}
              {eventType === 'violation' && (
                <View style={styles.eventSection}>
                  <Text style={styles.eventSectionTitle}>Violations (Not Fouls, but related)</Text>
                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('VIOLATION_TRAVELING')}
                  >
                    <Text style={styles.eventOptionText}>Traveling</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('VIOLATION_DOUBLE_DRIBBLE')}
                  >
                    <Text style={styles.eventOptionText}>Double Dribble</Text>
                  </TouchableOpacity>
                </View>
              )}

              {/* Other Events - only for score */}
              {eventType === 'score' && (
                <View style={styles.eventSection}>
                  <Text style={styles.eventSectionTitle}>Other</Text>
                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('AST')}
                  >
                    <Text style={styles.eventOptionText}>Assist</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('REB')}
                  >
                    <Text style={styles.eventOptionText}>Rebound</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={styles.eventOption}
                    onPress={() => recordEvent('SUB')}
                  >
                    <Text style={styles.eventOptionText}>Substitution</Text>
                  </TouchableOpacity>
                </View>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BACKGROUND,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BACKGROUND,
  },
  loadingText: {
    marginTop: SPACING.md,
    color: COLORS.TEXT_SECONDARY,
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.lg,
  },
  errorText: {
    fontSize: 18,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: SPACING.lg,
  },
  backButton: {
    backgroundColor: COLORS.PRIMARY,
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  backText: {
    color: COLORS.PRIMARY,
    fontSize: 16,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.TEXT_PRIMARY,
  },
  refreshText: {
    color: COLORS.PRIMARY,
    fontSize: 24,
  },
  content: {
    flex: 1,
  },
  scoreboard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
    padding: SPACING.md,
    margin: SPACING.sm,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#F59E0B',
  },
  teamScore: {
    flex: 1,
    alignItems: 'center',
  },
  teamName: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: SPACING.xs,
  },
  score: {
    color: COLORS.ACCENT,
    fontSize: 48,
    fontWeight: '800',
  },
  fouls: {
    color: '#999',
    fontSize: 12,
    marginTop: SPACING.xs,
  },
  gameInfo: {
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
  },
  period: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: '700',
    marginBottom: SPACING.xs,
  },
  status: {
    color: COLORS.SUCCESS,
    fontSize: 12,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  gameControls: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    padding: SPACING.md,
    gap: SPACING.sm,
  },
  startButton: {
    backgroundColor: COLORS.SUCCESS,
    paddingHorizontal: SPACING.xl,
    paddingVertical: SPACING.md,
    borderRadius: 8,
    flex: 1,
    minWidth: '100%',
  },
  controlButton: {
    backgroundColor: COLORS.PRIMARY,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: 8,
    flex: 1,
    minWidth: '45%',
  },
  endButton: {
    backgroundColor: COLORS.DANGER,
    paddingHorizontal: SPACING.xl,
    paddingVertical: SPACING.md,
    borderRadius: 8,
    flex: 1,
    minWidth: '100%',
    marginTop: SPACING.sm,
    borderWidth: 2,
    borderColor: '#dc2626',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  teamSection: {
    margin: SPACING.sm,
    padding: SPACING.sm,
    backgroundColor: '#FFF',
    borderRadius: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.TEXT_PRIMARY,
    marginBottom: SPACING.md,
  },
  actionGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: SPACING.xs,
  },
  actionButton: {
    alignItems: 'center',
    padding: SPACING.xs,
    borderRadius: 6,
    flex: 1,
    minWidth: 60,
  },
  scoreButton: {
    backgroundColor: '#4CAF50',
  },
  foulButton: {
    backgroundColor: '#ff4444',
  },
  violationButton: {
    backgroundColor: '#ff9900',
  },
  timeoutButton: {
    backgroundColor: '#2196F3',
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  timeoutWarning: {
    backgroundColor: '#FF6B6B',
    padding: SPACING.md,
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    alignItems: 'center',
  },
  timeoutWarningText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFF',
  },
  actionButtonText: {
    fontSize: 8,
    fontWeight: '600',
    color: '#FFF',
    marginTop: 2,
  },
  recentEvents: {
    margin: SPACING.sm,
    padding: SPACING.sm,
    backgroundColor: '#FFF9C4',
    borderLeftWidth: 4,
    borderLeftColor: '#FBBF24',
    borderRadius: 12,
  },
  eventCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: SPACING.md,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
  },
  eventType: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.TEXT_PRIMARY,
  },
  eventPeriod: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
  },
  noEvents: {
    textAlign: 'center',
    color: COLORS.TEXT_SECONDARY,
    padding: SPACING.lg,
  },
  completedMessage: {
    margin: SPACING.md,
    padding: SPACING.xl,
    backgroundColor: COLORS.SUCCESS,
    borderRadius: 12,
    alignItems: 'center',
  },
  completedText: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: '700',
  },
  // Small total scoreboard styles
  smallTotalScoreboard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    margin: SPACING.md,
    padding: SPACING.md,
    backgroundColor: '#FFF',
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  smallTeamScore: {
    flex: 1,
    alignItems: 'center',
  },
  smallTeamName: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY,
    marginBottom: SPACING.xs,
  },
  smallScore: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.PRIMARY,
  },
  smallGameInfo: {
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
  },
  smallScoreLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY,
    textTransform: 'uppercase',
  },
  // Quarter scoring view styles
  quarterScoringView: {
    margin: SPACING.md,
    backgroundColor: '#FFF',
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  quarterHeader: {
    alignItems: 'center',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  quarterTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.PRIMARY,
  },
  totalTeamScore: {
    flex: 1,
    alignItems: 'center',
  },
  totalScore: {
    fontSize: 48,
    fontWeight: '800',
    color: COLORS.PRIMARY,
    marginTop: SPACING.xs,
  },
  totalGameInfo: {
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
  },
  totalScoreLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY,
    marginBottom: SPACING.xs,
  },
  currentQuarter: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginTop: SPACING.xs,
  },
  quarterScoreSection: {
    margin: SPACING.md,
    padding: SPACING.md,
    backgroundColor: '#FFF',
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  quarterScoreboard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: SPACING.md,
  },
  quarterTeamScore: {
    flex: 1,
    alignItems: 'center',
  },
  quarterTeamName: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY,
    marginBottom: SPACING.sm,
  },
  quarterScore: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.TEXT_PRIMARY,
    minWidth: 40,
    textAlign: 'center',
  },
  quarterGameInfo: {
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
  },
  quarterLabel: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.PRIMARY,
  },
  viewerMessageContainer: {
    margin: SPACING.md,
    padding: SPACING.lg,
    backgroundColor: '#FFF3CD',
    borderRadius: 12,
    alignItems: 'center',
  },
  viewerMessage: {
    fontSize: 16,
    color: '#856404',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.TEXT_PRIMARY,
  },
  closeButton: {
    fontSize: 28,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '300',
  },
  selectedPlayerText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    textAlign: 'center',
    padding: SPACING.md,
    backgroundColor: '#F5F5F5',
  },
  playerItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  playerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  playerNumber: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginRight: SPACING.sm,
  },
  playerName: {
    fontSize: 16,
    color: COLORS.TEXT_PRIMARY,
  },
  playerPosition: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '600',
  },
  emptyText: {
    textAlign: 'center',
    color: COLORS.TEXT_SECONDARY,
    padding: SPACING.xl,
  },
  eventOptions: {
    padding: SPACING.md,
  },
  eventSection: {
    marginBottom: SPACING.lg,
  },
  eventSectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.TEXT_PRIMARY,
    marginBottom: SPACING.sm,
  },
  eventOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
    backgroundColor: '#F9F9F9',
    borderRadius: 8,
    marginBottom: SPACING.xs,
  },
  eventOptionText: {
    fontSize: 16,
    color: COLORS.TEXT_PRIMARY,
  },
  eventPoints: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.SUCCESS,
  },
});

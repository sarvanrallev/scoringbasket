import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { gamesAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function MatchDetailScreen() {
  const router = useRouter();
  const { gameId } = useLocalSearchParams();
  const [game, setGame] = useState(null);
  const [loading, setLoading] = useState(true);
  const [starting, setStarting] = useState(false);
  const [events, setEvents] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    loadGameDetails();
  }, [gameId]);

  // Refresh data when screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      loadGameDetails();
    }, [gameId])
  );

  const loadGameDetails = async () => {
    setLoading(true);
    try {
      const response = await gamesAPI.getGame(gameId);
      setGame(response);
      
      // Load current user
      const userData = await AsyncStorage.getItem('user_data');
      if (userData) {
        const user = JSON.parse(userData);
        
        // Check if user is admin (game creator or team admin)
        const isGameCreator = response.created_by && Number.parseInt(response.created_by) === Number.parseInt(user.id);
        const isHomeTeamAdmin = response.home_team?.owner_id && Number.parseInt(response.home_team.owner_id) === Number.parseInt(user.id);
        const isAwayTeamAdmin = response.away_team?.owner_id && Number.parseInt(response.away_team.owner_id) === Number.parseInt(user.id);
        
        setIsAdmin(isGameCreator || isHomeTeamAdmin || isAwayTeamAdmin);
      }
      
      // Load events
      try {
        const eventsResponse = await gamesAPI.getGameEvents(gameId);
        setEvents(eventsResponse || []);
      } catch (eventsError) {
        console.warn('Error loading events:', eventsError);
        setEvents([]);
      }
    } catch (error) {
      console.error('Error loading game details:', error);
      console.error('Game ID:', gameId);
      console.error('Error response:', error.response?.data);
      const errorMsg = error.response?.data?.detail || 'Failed to load game details';
      Alert.alert('Error', errorMsg);
      setTimeout(() => router.back(), 1000);
    } finally {
      setLoading(false);
    }
  };

  const handleStartMatch = async () => {
    Alert.alert(
      'Start Match',
      'Are you sure you want to start this match?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Start Match',
          onPress: async () => {
            setStarting(true);
            try {
              await gamesAPI.updateGame(gameId, { status: 'in_progress' });
              // Refresh game details
              await loadGameDetails();
              Alert.alert('Success', 'Match started successfully!');
            } catch (error) {
              console.error('Error starting match:', error);
              Alert.alert('Error', 'Failed to start match');
            } finally {
              setStarting(false);
            }
          }
        }
      ]
    );
  };

  const handleStartScoring = () => {
    router.push(`/live-scoring?gameId=${gameId}&start=true`);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'scheduled': return COLORS.SECONDARY;
      case 'in_progress': return '#FFA500'; // Orange
      case 'completed': return COLORS.SUCCESS || '#4CAF50';
      case 'cancelled': return COLORS.ERROR || '#F44336';
      default: return COLORS.TEXT_LIGHT;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'scheduled': return 'Scheduled';
      case 'in_progress': return 'In Progress';
      case 'completed': return 'Completed';
      case 'cancelled': return 'Cancelled';
      default: return status;
    }
  };

  const getScoreColor = (score1, score2) => {
    if (score1 > score2) return COLORS.SUCCESS;
    if (score1 < score2) return COLORS.DANGER;
    return COLORS.WARNING;
  };

  const getEventDisplayName = (eventType) => {
    const eventNames = {
      '2PT': '2PT',
      '3PT': '3PT',
      'FT': 'FT',
      'AST': 'AST',
      'REB': 'REB',
      'FLS': 'FOUL',
      'SUB': 'SUB',
      'TO': 'TIMEOUT',
      'PERIOD_START': 'Period Start',
      'PERIOD_END': 'Period End',
      'FOUL_BLOCKING': 'BLOCK FOUL',
      'FOUL_CHARGING': 'CHARGE FOUL',
      'FOUL_HOLDING': 'HOLD FOUL',
      'FOUL_PUSHING': 'PUSH FOUL',
      'FOUL_PERSONAL': 'PERSONAL FOUL',
      'FOUL_TECHNICAL': 'TECH FOUL',
      'FOUL_FLAGRANT': 'FLAGRANT FOUL',
      'VIOLATION_TRAVELING': 'TRAVELING',
      'VIOLATION_DOUBLE_DRIBBLE': 'DOUBLE DRIBBLE',
      'VIOLATION_OVER_AND_BACK': 'OVER & BACK',
      'VIOLATION_WALKING': 'WALKING',
      'VIOLATION_CARRY': 'CARRYING'
    };
    return eventNames[eventType] || eventType;
  };

  const getEventColor = (eventType) => {
    // Color coding for different event types
    if (eventType === '2PT' || eventType === '3PT') {
      return COLORS.SECONDARY; // Blue
    } else if (eventType === 'FT') {
      return COLORS.ACCENT; // Orange/Gold
    } else if (eventType.includes('FOUL')) {
      return '#ff4444'; // Red
    } else if (eventType.includes('VIOLATION')) {
      return '#ff9900'; // Orange
    } else if (eventType === 'REB') {
      return '#4CAF50'; // Green
    } else if (eventType === 'AST') {
      return '#9C27B0'; // Purple
    }
    return COLORS.TEXT_PRIMARY; // Default
  };

  const formatEventTime = (timestamp, location) => {
    // Format timestamp to local timezone based on location
    if (!timestamp) return '--:--';
    
    const minutes = Math.floor(timestamp / 60);
    const seconds = (timestamp % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  };

  // Get quarter-level scores from events
  const getQuarterScores = () => {
    if (!game || !events || events.length === 0) {
      return {
        Q1: { home: 0, away: 0 },
        Q2: { home: 0, away: 0 },
        Q3: { home: 0, away: 0 },
        Q4: { home: 0, away: 0 }
      };
    }

    const quarterScores = {
      Q1: { home: 0, away: 0 },
      Q2: { home: 0, away: 0 },
      Q3: { home: 0, away: 0 },
      Q4: { home: 0, away: 0 }
    };

    events.forEach(event => {
      if ((event.event_type === '2PT' || event.event_type === '3PT' || event.event_type === 'FT') && event.outcome === 'made') {
        let points = 1; // Default to 1 point (FT)
        if (event.event_type === '2PT') {
          points = 2;
        } else if (event.event_type === '3PT') {
          points = 3;
        }
        const quarter = `Q${event.period}`;
        if (event.team_id === game.home_team_id) {
          quarterScores[quarter].home += points;
        } else {
          quarterScores[quarter].away += points;
        }
      }
    });

    return quarterScores;
  };

  const getPlayerName = (userId) => {
    if (!game) return 'Unknown Player';
    
    const allPlayers = [...(game.home_players || []), ...(game.away_players || [])];
    const player = allPlayers.find(p => p.user_id === userId);
    return player ? player.name : 'Unknown Player';
  };

  // Get team-level stats (fouls and points)
  const getTeamStats = (teamId) => {
    if (!events) return { fouls: 0, violations: 0, points: 0 };

    let fouls = 0;
    let violations = 0;
    let points = 0;

    events.forEach(event => {
      if (event.team_id === teamId) {
        if (event.event_type.includes('FOUL')) {
          fouls++;
        } else if (event.event_type.includes('VIOLATION')) {
          violations++;
        }
        
        if ((event.event_type === '2PT' || event.event_type === '3PT' || event.event_type === 'FT') && event.outcome === 'made') {
          if (event.event_type === '2PT') {
            points += 2;
          } else if (event.event_type === '3PT') {
            points += 3;
          } else if (event.event_type === 'FT') {
            points += 1;
          }
        }
      }
    });

    return { fouls, violations, points };
  };

  // Get individual player stats (points and fouls)
  const getPlayerGameStats = (playerId) => {
    if (!events) return { points: 0, fouls: 0 };

    let points = 0;
    let fouls = 0;

    events.forEach(event => {
      if (event.user_id === playerId) {
        if ((event.event_type === '2PT' || event.event_type === '3PT' || event.event_type === 'FT') && event.outcome === 'made') {
          if (event.event_type === '2PT') {
            points += 2;
          } else if (event.event_type === '3PT') {
            points += 3;
          } else if (event.event_type === 'FT') {
            points += 1;
          }
        }
        
        if (event.event_type.includes('FOUL')) {
          fouls++;
        }
      }
    });

    return { points, fouls };
  };

  // Format match date for title
  const formatMatchDate = () => {
    if (!game || !game.match_date) return 'Match';
    
    const date = new Date(game.match_date);
    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  if (!game) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>Game not found</Text>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={styles.headerBackButton}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Match Details</Text>
          <View style={{ width: 50 }} />
        </View>

        {/* Match Status */}
        <View style={styles.statusContainer}>
          <Text style={[styles.statusText, { color: getStatusColor(game.status) }]}>
            {getStatusText(game.status)}
          </Text>
        </View>

        {/* Game Title */}
        <View style={styles.gameTitleContainer}>
          <Text style={styles.gameTitle}>{game.title || formatMatchDate()}</Text>
          {game.location && <Text style={styles.gameLocation}>📍 {game.location}</Text>}
        </View>

        {/* Start Scoring Button - Positioned at Top */}
        {game.status === 'in_progress' && isAdmin && (
          <View style={styles.scoringButtonContainer}>
            <TouchableOpacity
              style={styles.scoringButton}
              onPress={handleStartScoring}
            >
              <Text style={styles.scoringButtonText}>Start Scoring</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Teams with Stats */}
        <View style={styles.teamsContainer}>
          <View style={styles.teamCard}>
            <Text style={styles.teamBadge}>🏠 HOME</Text>
            <Text style={styles.teamName}>{game.home_team?.name || 'Home Team'}</Text>
            <Text style={styles.teamCity}>{game.home_team?.city || ''}</Text>
            <Text style={[styles.score, { color: getScoreColor(game.home_score, game.away_score) }]}>{game.home_score || 0}</Text>
            
            {/* Home Team Stats */}
            {(() => {
              const homeStats = getTeamStats(game.home_team_id);
              return (
                <View style={styles.teamStatsRow}>
                  <View style={styles.statItem}>
                    <Text style={styles.statValue}>{homeStats.fouls}</Text>
                    <Text style={styles.statLabel}>Fouls</Text>
                  </View>
                </View>
              );
            })()}
            
            {/* Home Team Player Stats */}
            {(() => {
              const homePlayers = game.home_players || [];
              const playerStatsText = homePlayers
                .map(player => {
                  const stats = getPlayerGameStats(player.user_id);
                  // Only show players with points or fouls > 0
                  if (stats.points > 0 || stats.fouls > 0) {
                    return `${player.name}: ${stats.points}pts, ${stats.fouls}f`;
                  }
                  return null;
                })
                .filter(text => text !== null)
                .join('  •  ');
              
              return playerStatsText ? (
                <Text style={styles.playerStatsText}>{playerStatsText}</Text>
              ) : null;
            })()}
          </View>

          <View style={styles.vsContainer}>
            <Text style={styles.vs}>⚡</Text>
          </View>

          <View style={styles.teamCard}>
            <Text style={styles.teamBadge}>🚀 AWAY</Text>
            <Text style={styles.teamName}>{game.away_team?.name || 'Away Team'}</Text>
            <Text style={styles.teamCity}>{game.away_team?.city || ''}</Text>
            <Text style={[styles.score, { color: getScoreColor(game.away_score, game.home_score) }]}>{game.away_score || 0}</Text>
            
            {/* Away Team Stats */}
            {(() => {
              const awayStats = getTeamStats(game.away_team_id);
              return (
                <View style={styles.teamStatsRow}>
                  <View style={styles.statItem}>
                    <Text style={styles.statValue}>{awayStats.fouls}</Text>
                    <Text style={styles.statLabel}>Fouls</Text>
                  </View>
                </View>
              );
            })()}
            
            {/* Away Team Player Stats */}
            {(() => {
              const awayPlayers = game.away_players || [];
              const playerStatsText = awayPlayers
                .map(player => {
                  const stats = getPlayerGameStats(player.user_id);
                  // Only show players with points or fouls > 0
                  if (stats.points > 0 || stats.fouls > 0) {
                    return `${player.name}: ${stats.points}pts, ${stats.fouls}f`;
                  }
                  return null;
                })
                .filter(text => text !== null)
                .join('  •  ');
              
              return playerStatsText ? (
                <Text style={styles.playerStatsText}>{playerStatsText}</Text>
              ) : null;
            })()}
          </View>
        </View>

        {/* Quarter Scores */}
        {events && events.length > 0 && (
          <View style={styles.quarterScoresContainer}>
            <Text style={styles.quarterScoresTitle}>📊 Quarter Breakdown</Text>
            <View style={styles.quarterScoresGrid}>
              {['Q1', 'Q2', 'Q3', 'Q4'].map((quarter, idx) => {
                const scores = getQuarterScores();
                const homeQ = scores[quarter].home;
                const awayQ = scores[quarter].away;
                const quarterColors = ['#3b82f6', '#a855f7', '#f97316', '#ef4444'];
                const quarterEmojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
                return (
                  <View key={quarter} style={[styles.quarterScoreCard, { backgroundColor: quarterColors[idx], borderColor: quarterColors[idx] }]}>
                    <Text style={[styles.quarterLabel, { color: '#FFFFFF', fontSize: 14 }]}>{quarterEmojis[idx]} {quarter}</Text>
                    <Text style={[styles.quarterScore, { color: '#FFFFFF', fontSize: 14, fontWeight: 'bold' }]}>{homeQ}-{awayQ}</Text>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {/* Match Info */}
        <View style={styles.infoContainer}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Title:</Text>
            <Text style={styles.infoValue}>{game.title || 'No title'}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Date:</Text>
            <Text style={styles.infoValue}>
              {game.match_date ? new Date(game.match_date).toLocaleDateString() : 'Not set'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Time:</Text>
            <Text style={styles.infoValue}>
              {game.match_date ? new Date(game.match_date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Not set'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Location:</Text>
            <Text style={styles.infoValue}>{game.location || 'Not set'}</Text>
          </View>
        </View>

        {/* Players - Two Column Layout */}
        {(game.home_players || game.away_players) && (
          <View style={styles.playersContainer}>
            <Text style={styles.sectionTitle}>Players</Text>
            <View style={styles.playersColumnContainer}>
              {/* Home Team Players */}
              <View style={styles.playerColumn}>
                <Text style={styles.playerColumnHeader}>{game.home_team?.name || 'Home'}</Text>
                {game.home_players && game.home_players.length > 0 ? (
                  game.home_players.map((player) => (
                    <TouchableOpacity 
                      key={player.user_id || player.name} 
                      style={styles.playerButton}
                      onPress={() => player.user_id && router.push(`/player-profile?userId=${player.user_id}`)}
                    >
                      <Text style={styles.playerNameButton}>
                        {player.name}
                        {player.jersey_number && ` #${player.jersey_number}`}
                      </Text>
                    </TouchableOpacity>
                  ))
                ) : (
                  <Text style={styles.noPlayersText}>No players</Text>
                )}
              </View>

              {/* Away Team Players */}
              <View style={styles.playerColumn}>
                <Text style={styles.playerColumnHeader}>{game.away_team?.name || 'Away'}</Text>
                {game.away_players && game.away_players.length > 0 ? (
                  game.away_players.map((player) => (
                    <TouchableOpacity 
                      key={player.user_id || player.name} 
                      style={styles.playerButton}
                      onPress={() => player.user_id && router.push(`/player-profile?userId=${player.user_id}`)}
                    >
                      <Text style={styles.playerNameButton}>
                        {player.name}
                        {player.jersey_number && ` #${player.jersey_number}`}
                      </Text>
                    </TouchableOpacity>
                  ))
                ) : (
                  <Text style={styles.noPlayersText}>No players</Text>
                )}
              </View>
            </View>
          </View>
        )}

        {/* Events Commentary - Vertical Scroll */}
        {events && events.length > 0 && (
          <View style={styles.eventsContainer}>
            <Text style={styles.sectionTitle}>📊 Game Commentary</Text>
            <ScrollView 
              showsVerticalScrollIndicator={true}
              scrollEventThrottle={16}
              style={styles.commentaryScrollView}
              nestedScrollEnabled={true}
            >
              {[...events].sort((a, b) => a.id - b.id).map((item, idx) => {
                const getEventEmoji = (type) => {
                  if (type === '2PT' || type === '3PT') return '🏀';
                  if (type === 'FT') return '🎯';
                  if (type === 'AST') return '🔄';
                  if (type.includes('FOUL') || type.includes('VIOLATION')) return '🛑';
                  if (type === 'REB') return '📦';
                  return '⚽';
                };
                return (
                  <View key={item.id} style={[styles.commentaryLine, { backgroundColor: idx % 2 === 0 ? '#F9FAFB' : '#FFFFFF' }]}>
                    <Text style={[styles.commentaryText, { color: getEventColor(item.event_type) }]}>
                      {getEventEmoji(item.event_type)}
                    </Text>
                    <View style={styles.commentaryLineContent}>
                      <Text style={styles.commentaryText}>
                        <Text style={styles.commentaryTime}>{`Q${item.period} ${formatEventTime(item.timestamp, game.location)}`}</Text>
                        <Text style={styles.commentaryTeam}> • {item.team_id === game.home_team_id ? game.home_team?.name : game.away_team?.name}</Text>
                      </Text>
                      <Text style={[styles.commentaryEvent, { color: getEventColor(item.event_type), fontSize: 13, marginTop: 2 }]}>
                        {getEventDisplayName(item.event_type)}
                      </Text>
                      {item.user_id && <Text style={[styles.commentaryDetail, { fontSize: 11, marginTop: 1 }]}>{getPlayerName(item.user_id)}</Text>}
                    </View>
                  </View>
                );
              })}
            </ScrollView>
            {events.length === 0 && (
              <Text style={styles.noEvents}>No events recorded yet</Text>
            )}
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          {game.status === 'scheduled' && isAdmin && (
            <TouchableOpacity
              style={[styles.actionButton, styles.startButton, starting && styles.buttonDisabled]}
              onPress={handleStartMatch}
              disabled={starting}
            >
              {starting ? (
                <ActivityIndicator color={COLORS.BG_LIGHT} />
              ) : (
                <Text style={styles.startButtonText}>Start Match</Text>
              )}
            </TouchableOpacity>
          )}

          {game.status === 'completed' && (
            <Text style={styles.completedMessage}>
              Game Completed - Final Score: {game.home_score} - {game.away_score}
            </Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA'
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BG_LIGHT
  },
  scrollView: {
    flex: 1,
    backgroundColor: '#FAFAFA'
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    backgroundColor: COLORS.BG_LIGHT,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  headerBackButton: {
    fontSize: 16,
    color: COLORS.SECONDARY
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK
  },
  statusContainer: {
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: SPACING.md
  },
  statusText: {
    fontSize: 16,
    fontWeight: 'bold'
  },
  gameTitleContainer: {
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: SPACING.md,
    marginVertical: 4,
    backgroundColor: '#F5F5F5',
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0'
  },
  gameTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK,
    marginBottom: 2
  },
  gameLocation: {
    fontSize: 12,
    color: COLORS.TEXT_LIGHT
  },
  teamsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    marginHorizontal: SPACING.md,
    marginVertical: 6,
    backgroundColor: '#F0F4FF',
    borderRadius: 8,
    borderWidth: 2,
    borderColor: COLORS.SECONDARY,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4
  },
  teamCard: {
    flex: 1,
    alignItems: 'center'
  },
  teamBadge: {
    fontSize: 11,
    fontWeight: 'bold',
    color: COLORS.SECONDARY,
    marginBottom: 4,
    backgroundColor: '#E3F2FD',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4
  },
  teamName: {
    fontSize: 13,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK,
    textAlign: 'center',
    marginBottom: 2
  },
  teamCity: {
    fontSize: 10,
    color: COLORS.TEXT_LIGHT,
    textAlign: 'center',
    marginBottom: 4
  },
  teamStatsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: SPACING.sm,
    marginTop: 6,
    paddingTop: 6,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0'
  },
  statItem: {
    alignItems: 'center'
  },
  statValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.SECONDARY
  },
  statLabel: {
    fontSize: 10,
    color: COLORS.TEXT_LIGHT,
    marginTop: 2
  },
  playerStatsText: {
    fontSize: 11,
    color: COLORS.TEXT_LIGHT,
    marginTop: 8,
    paddingHorizontal: SPACING.sm,
    textAlign: 'center',
    fontWeight: '500'
  },
  score: {
    fontSize: 36,
    fontWeight: '900',
    color: COLORS.SECONDARY,
    marginTop: 2
  },
  vsContainer: {
    marginHorizontal: SPACING.sm
  },
  vs: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.DANGER
  },
  quarterScoresContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    marginVertical: 6,
    backgroundColor: '#FCE4EC',
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.DANGER
  },
  quarterScoresTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK,
    marginBottom: 6
  },
  quarterScoresGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 6
  },
  quarterScoreCard: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 8,
    padding: SPACING.sm,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    borderWidth: 2
  },
  quarterLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.SECONDARY,
    marginBottom: 4
  },
  quarterScore: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.TEXT_DARK
  },
  infoContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    marginVertical: 6,
    backgroundColor: '#E8F5E9',
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.SUCCESS
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 8,
    marginVertical: 2,
    borderRadius: 6,
    backgroundColor: '#FFFFFF'
  },
  infoLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK
  },
  infoValue: {
    fontSize: 12,
    color: COLORS.TEXT
  },
  playersContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    marginVertical: 6,
    backgroundColor: '#E3F2FD',
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.SECONDARY
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK,
    marginBottom: 6
  },
  playersColumnContainer: {
    flexDirection: 'row',
    gap: SPACING.md
  },
  playerColumn: {
    flex: 1,
    backgroundColor: '#F0F9FF',
    borderRadius: 8,
    padding: SPACING.sm,
    borderWidth: 1,
    borderColor: '#B3E5FC',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2
  },
  playerColumnHeader: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.SECONDARY,
    marginBottom: SPACING.sm,
    paddingBottom: SPACING.xs,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  playerButton: {
    backgroundColor: '#E3F2FD',
    borderRadius: 6,
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    marginBottom: SPACING.xs,
    borderWidth: 1,
    borderColor: COLORS.SECONDARY,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 1
  },
  playerNameButton: {
    fontSize: 12,
    color: COLORS.SECONDARY,
    fontWeight: '600'
  },
  noPlayersText: {
    fontSize: 12,
    color: COLORS.TEXT_LIGHT,
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: SPACING.sm
  },
  teamPlayers: {
    marginBottom: SPACING.md
  },
  teamLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.SECONDARY,
    marginBottom: SPACING.sm
  },
  playerName: {
    fontSize: 14,
    color: COLORS.TEXT,
    marginLeft: SPACING.md,
    marginBottom: SPACING.xs
  },
  playerItem: {
    paddingVertical: SPACING.xs,
    paddingHorizontal: SPACING.sm,
    borderRadius: 4,
    marginBottom: SPACING.xs
  },
  actionsContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    marginVertical: 6,
    backgroundColor: '#FFF9C4',
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#FBC02D'
  },
  actionButton: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: SPACING.sm,
    flex: 1,
    marginHorizontal: SPACING.xs
  },
  startButton: {
    backgroundColor: COLORS.SECONDARY
  },
  startButtonText: {
    color: COLORS.BG_LIGHT,
    fontSize: 14,
    fontWeight: 'bold'
  },
  endButton: {
    backgroundColor: '#4CAF50'
  },
  endButtonText: {
    color: COLORS.BG_LIGHT,
    fontSize: 14,
    fontWeight: 'bold'
  },
  buttonDisabled: {
    opacity: 0.6
  },
  errorText: {
    fontSize: 12,
    color: COLORS.ERROR || '#F44336',
    marginBottom: SPACING.xs
  },
  backButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: 8
  },
  backButtonText: {
    color: COLORS.BG_LIGHT,
    fontSize: 14
  },
  scoringButtonContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    alignItems: 'center'
  },
  scoringButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    borderRadius: 20,
    minWidth: 160,
  },
  scoringButtonText: {
    color: COLORS.BG_LIGHT,
    fontSize: 14,
    fontWeight: 'bold'
  },
  eventsContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    marginVertical: 6,
    backgroundColor: '#F3E5F5',
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#9C27B0'
  },
  commentaryScrollView: {
    flexGrow: 0
  },
  commentaryScrollContent: {
    paddingRight: SPACING.md,
  },
  commentaryCard: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 8,
    padding: SPACING.md,
    marginRight: SPACING.sm,
    marginVertical: SPACING.xs,
    minWidth: 140,
    maxWidth: 160,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    borderWidth: 1,
    borderColor: '#E0E0E0'
  },
  commentaryCardEmoji: {
    fontSize: 24,
    marginBottom: 6
  },
  commentaryCardTime: {
    fontSize: 11,
    fontWeight: '700',
    color: '#666',
    marginBottom: 4,
    textAlign: 'center'
  },
  commentaryCardTeam: {
    fontSize: 10,
    fontWeight: '600',
    color: COLORS.SECONDARY,
    marginBottom: 4,
    textAlign: 'center'
  },
  commentaryCardEvent: {
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 4,
    textAlign: 'center'
  },
  commentaryCardPlayer: {
    fontSize: 10,
    color: COLORS.TEXT_LIGHT,
    textAlign: 'center'
  },
  commentaryList: {
    maxHeight: 400,
  },
  commentaryLine: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingVertical: 6,
    paddingHorizontal: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    gap: 8
  },
  commentaryLineContent: {
    flex: 1
  },
  commentaryText: {
    fontSize: 11,
    lineHeight: 16,
    color: COLORS.TEXT_PRIMARY,
  },
  commentaryTime: {
    fontSize: 10,
    fontWeight: '700',
    color: '#666',
  },
  commentaryTeam: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.SECONDARY,
  },
  commentaryEvent: {
    fontSize: 12,
    fontWeight: '700',
  },
  commentaryDetail: {
    fontSize: 10,
    color: COLORS.TEXT_LIGHT,
  },
  eventIconButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 2
  },
  eventIconText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  eventsScroll: {
    marginHorizontal: -SPACING.md,
    paddingHorizontal: SPACING.md,
  },
  eventCommentary: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 8,
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs,
    marginRight: SPACING.sm,
    marginBottom: SPACING.sm,
    alignItems: 'center',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    minWidth: 120,
  },
  eventTime: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.TEXT_DARK,
    marginBottom: 2,
  },
  eventTeamName: {
    fontSize: 10,
    fontWeight: '600',
    color: COLORS.SECONDARY,
    marginBottom: 2,
  },
  eventTypeTag: {
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 2,
  },
  eventPlayer: {
    fontSize: 9,
    color: COLORS.TEXT_LIGHT,
    marginBottom: 1,
  },
  eventOutcome: {
    fontSize: 9,
    fontWeight: '600',
    color: COLORS.PRIMARY,
  },
  eventItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 8,
    marginBottom: SPACING.sm,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  eventInfo: {
    flex: 1,
  },
  eventType: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.TEXT_DARK,
  },
  eventDetails: {
    fontSize: 14,
    color: COLORS.TEXT_LIGHT,
    marginTop: SPACING.xs,
  },
  noEvents: {
    textAlign: 'center',
    color: COLORS.TEXT_LIGHT,
    padding: SPACING.lg,
    fontStyle: 'italic',
  },
  completedMessage: {
    textAlign: 'center',
    fontSize: 16,
    color: COLORS.SUCCESS,
    fontWeight: '600',
    padding: SPACING.md,
    backgroundColor: '#E8F5E9',
    borderRadius: 8,
  },
  matchStatsContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 8,
    marginVertical: 6,
    backgroundColor: '#FFF3E0',
    marginHorizontal: SPACING.md,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.WARNING
  },
  matchStatsTable: {
    backgroundColor: '#FFEBEE',
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#FFCDD2',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2
  },
  matchStatsHeaderRow: {
    flexDirection: 'row',
    backgroundColor: COLORS.SECONDARY,
    paddingVertical: SPACING.xs,
    paddingHorizontal: SPACING.sm,
    borderBottomWidth: 2,
    borderBottomColor: '#E0E0E0'
  },
  matchStatsHeader: {
    fontSize: 11,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  matchStatsRow: {
    flexDirection: 'row',
    paddingVertical: SPACING.xs,
    paddingHorizontal: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    alignItems: 'center'
  },
  matchStatsCell: {
    fontSize: 11,
    color: COLORS.TEXT_DARK,
    paddingVertical: SPACING.xs
  },
  matchStatsTotalRow: {
    flexDirection: 'row',
    paddingVertical: SPACING.xs,
    paddingHorizontal: SPACING.sm,
    backgroundColor: '#F5F5F5',
    borderTopWidth: 2,
    borderTopColor: COLORS.SECONDARY,
    alignItems: 'center'
  },
  matchStatsTotal: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.SECONDARY,
    paddingVertical: SPACING.xs
  }
});
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Animated
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRouter } from 'expo-router';
import { useFocusEffect } from '@react-navigation/native';
import { gamesAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function HomeScreen() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [upcomingGames, setUpcomingGames] = useState([]);
  const [liveTeamGames, setLiveTeamGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [topScorers, setTopScorers] = useState([]);
  const [stats, setStats] = useState({
    totalGames: 0,
    totalWins: 0,
    winRatio: 0,
    totalAssists: 0,
    uniqueTeams: 0
  });
  const [weekHighlightsData, setWeekHighlightsData] = useState(null);
  
  // Animation refs
  const bounceAnim = useRef(new Animated.Value(0)).current;
  const hasAnimated = useRef(false);
  const card1Anim = useRef(new Animated.Value(0)).current;
  const card2Anim = useRef(new Animated.Value(0)).current;
  const card3Anim = useRef(new Animated.Value(0)).current;
  const emoji1Anim = useRef(new Animated.Value(0)).current;
  const emoji2Anim = useRef(new Animated.Value(0)).current;
  const emoji3Anim = useRef(new Animated.Value(0)).current;
  const cardEmoji1_1 = useRef(new Animated.Value(0)).current;
  const cardEmoji1_2 = useRef(new Animated.Value(0)).current;
  const cardEmoji1_3 = useRef(new Animated.Value(0)).current;
  const cardEmoji1_4 = useRef(new Animated.Value(0)).current;
  const cardEmoji2_1 = useRef(new Animated.Value(0)).current;
  const cardEmoji2_2 = useRef(new Animated.Value(0)).current;
  const cardEmoji2_3 = useRef(new Animated.Value(0)).current;
  const cardEmoji3_1 = useRef(new Animated.Value(0)).current;
  const cardEmoji3_2 = useRef(new Animated.Value(0)).current;
  const cardEmoji3_3 = useRef(new Animated.Value(0)).current;
  const highlightsAnimated = useRef(false);

  useEffect(() => {
    loadUserData();
    loadHomeData();
  }, []);

  // Trigger animation when user loads
  useEffect(() => {
    if (user && !hasAnimated.current) {
      hasAnimated.current = true;
      startDunkAnimation();
    }
  }, [user]);

  // Trigger highlights animation when data loads
  useEffect(() => {
    if (weekHighlightsData && !highlightsAnimated.current) {
      highlightsAnimated.current = true;
      animateHighlights();
    }
  }, [weekHighlightsData]);

  // Refresh data when screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      loadHomeData();
    }, [])
  );

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user_data');
      if (userData) {
        setUser(JSON.parse(userData));
      }
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const startDunkAnimation = () => {
    Animated.sequence([
      // Drop from top
      Animated.timing(bounceAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true
      }),
      // Bounce back
      Animated.timing(bounceAnim, {
        toValue: 0.8,
        duration: 200,
        useNativeDriver: true
      })
    ]).start();
  };

  const animateHighlights = () => {
    // Reset all animations
    card1Anim.setValue(0);
    card2Anim.setValue(0);
    card3Anim.setValue(0);
    emoji1Anim.setValue(0);
    emoji2Anim.setValue(0);
    emoji3Anim.setValue(0);
    cardEmoji1_1.setValue(0);
    cardEmoji1_2.setValue(0);
    cardEmoji1_3.setValue(0);
    cardEmoji1_4.setValue(0);
    cardEmoji2_1.setValue(0);
    cardEmoji2_2.setValue(0);
    cardEmoji2_3.setValue(0);
    cardEmoji3_1.setValue(0);
    cardEmoji3_2.setValue(0);
    cardEmoji3_3.setValue(0);

    // Card 1: Left-slide + rotation + scale
    const card1Animation = Animated.timing(card1Anim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true
    });

    // Card 2: Bottom-slide + bounce effect
    const card2Animation = Animated.timing(card2Anim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true
    });

    // Card 3: Right-slide + rotation + scale
    const card3Animation = Animated.timing(card3Anim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true
    });

    // Emoji 1: Spin animation (synced with card 1)
    const emoji1Animation = Animated.timing(emoji1Anim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true
    });

    // Emoji 2: Bounce/pulse animation (synced with card 2)
    const emoji2Animation = Animated.timing(emoji2Anim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true
    });

    // Emoji 3: Flip animation (synced with card 3)
    const emoji3Animation = Animated.timing(emoji3Anim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true
    });

    // Stagger animations with 100ms delay between each card
    Animated.stagger(100, [
      card1Animation,
      card2Animation,
      card3Animation
    ]).start();

    // Start emoji animations with slight delay
    setTimeout(() => {
      Animated.stagger(100, [
        emoji1Animation,
        emoji2Animation,
        emoji3Animation
      ]).start();
    }, 100);

    // Card item emojis animations - start 200ms after cards begin
    setTimeout(() => {
      const cardItemAnimations = [
        // Card 1 emojis (bounce effect)
        Animated.timing(cardEmoji1_1, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardEmoji1_2, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardEmoji1_3, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardEmoji1_4, { toValue: 1, duration: 400, useNativeDriver: true }),
        // Card 2 emojis (spin effect)
        Animated.timing(cardEmoji2_1, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardEmoji2_2, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardEmoji2_3, { toValue: 1, duration: 400, useNativeDriver: true }),
        // Card 3 emojis (scale effect)
        Animated.timing(cardEmoji3_1, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardEmoji3_2, { toValue: 1, duration: 400, useNativeDriver: true }),
        Animated.timing(cardEmoji3_3, { toValue: 1, duration: 400, useNativeDriver: true }),
      ];
      Animated.stagger(50, cardItemAnimations).start();
    }, 200);
  };

  const calculateStats = (games) => {
    if (!games || games.length === 0) {
      setStats({ totalGames: 0, totalWins: 0, winRatio: 0, totalAssists: 0, uniqueTeams: 0 });
      return;
    }
    
    // Count ALL games (not just completed)
    const allGames = games;
    const completed = games.filter(g => g.status === 'completed');
    const wins = completed.filter(g => {
      const homeWins = g.home_score > g.away_score;
      const isHome = g.home_team?.id === user?.team_id;
      return isHome ? homeWins : !homeWins;
    }).length;
    
    // Count unique teams
    const uniqueTeamIds = new Set(games.map(g => g.home_team?.id).filter(Boolean));
    const uniqueTeamsCount = uniqueTeamIds.size;
    
    setStats({
      totalGames: allGames.length,
      totalWins: wins,
      winRatio: completed.length > 0 ? Math.round((wins / completed.length) * 100) : 0,
      totalAssists: 0,
      uniqueTeams: uniqueTeamsCount
    });
  };

  const calculateWeekHighlights = (games, allGameStats) => {
    if (!games || games.length === 0) {
      return null;
    }

    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weekGames = games.filter(g => {
      const gameDate = new Date(g.scheduled_at || g.created_at);
      return gameDate >= sevenDaysAgo && gameDate <= now;
    });

    if (weekGames.length === 0) {
      return null;
    }

    // Initialize tracking objects
    let topPlayer = null;
    let topTeam = null;
    let highestScoringGame = null;
    let highestScoringTeam = null;
    let threePointLeader = null;
    let twoPointLeader = null;
    let mostAssistsPlayer = null;
    let mostFoulsPlayer = null;
    let mostViolationsPlayer = null;
    let lowestScoringTeam = null;

    const playerStats = {};
    const teamStats = {};
    let maxCombinedScore = 0;

    // Process each game's stats
    weekGames.forEach(game => {
      if (allGameStats[game.id]) {
        const stats = allGameStats[game.id];
        const combinedScore = (game.home_score || 0) + (game.away_score || 0);
        
        // Track highest scoring game
        if (combinedScore > maxCombinedScore) {
          maxCombinedScore = combinedScore;
          highestScoringGame = {
            id: game.id,
            homeTeam: game.home_team?.name || 'Unknown',
            awayTeam: game.away_team?.name || 'Unknown',
            homeScore: game.home_score,
            awayScore: game.away_score,
            totalScore: combinedScore
          };
        }

        // Process home team scorers
        if (stats.home_team_top_scorers && Array.isArray(stats.home_team_top_scorers)) {
          stats.home_team_top_scorers.forEach(scorer => {
            const name = scorer.name || 'Unknown';
            const points = scorer.points || 0;
            const assists = scorer.assists || 0;
            const fouls = scorer.fouls || 0;
            const violations = scorer.violations || 0;
            const threePointers = scorer.three_pointers_made || 0;
            const twoPointers = scorer.two_pointers_made || 0;
            const teamName = game.home_team?.name || 'Unknown';

            if (!playerStats[name]) {
              playerStats[name] = {
                name,
                team: teamName,
                points: 0,
                assists: 0,
                fouls: 0,
                violations: 0,
                threePointers: 0,
                twoPointers: 0
              };
            }
            playerStats[name].points += points;
            playerStats[name].assists += assists;
            playerStats[name].fouls += fouls;
            playerStats[name].violations += violations;
            playerStats[name].threePointers += threePointers;
            playerStats[name].twoPointers += twoPointers;
          });
        }

        // Process away team scorers
        if (stats.away_team_top_scorers && Array.isArray(stats.away_team_top_scorers)) {
          stats.away_team_top_scorers.forEach(scorer => {
            const name = scorer.name || 'Unknown';
            const points = scorer.points || 0;
            const assists = scorer.assists || 0;
            const fouls = scorer.fouls || 0;
            const violations = scorer.violations || 0;
            const threePointers = scorer.three_pointers_made || 0;
            const twoPointers = scorer.two_pointers_made || 0;
            const teamName = game.away_team?.name || 'Unknown';

            if (!playerStats[name]) {
              playerStats[name] = {
                name,
                team: teamName,
                points: 0,
                assists: 0,
                fouls: 0,
                violations: 0,
                threePointers: 0,
                twoPointers: 0
              };
            }
            playerStats[name].points += points;
            playerStats[name].assists += assists;
            playerStats[name].fouls += fouls;
            playerStats[name].violations += violations;
            playerStats[name].threePointers += threePointers;
            playerStats[name].twoPointers += twoPointers;
          });
        }

        // Track team stats
        const homeTeamName = game.home_team?.name || 'Unknown';
        const awayTeamName = game.away_team?.name || 'Unknown';
        const homeScore = game.home_score || 0;
        const awayScore = game.away_score || 0;

        if (!teamStats[homeTeamName]) {
          teamStats[homeTeamName] = { name: homeTeamName, wins: 0, totalPoints: 0 };
        }
        if (!teamStats[awayTeamName]) {
          teamStats[awayTeamName] = { name: awayTeamName, wins: 0, totalPoints: 0 };
        }

        teamStats[homeTeamName].totalPoints += homeScore;
        teamStats[awayTeamName].totalPoints += awayScore;

        if (game.status === 'completed') {
          if (homeScore > awayScore) {
            teamStats[homeTeamName].wins += 1;
          } else if (awayScore > homeScore) {
            teamStats[awayTeamName].wins += 1;
          }
        }
      }
    });

    // Extract top metrics from aggregated data
    const playerArray = Object.values(playerStats);
    const teamArray = Object.values(teamStats);

    // Top Player (highest points)
    if (playerArray.length > 0) {
      topPlayer = playerArray.reduce((prev, current) => 
        (prev.points > current.points) ? prev : current
      );
    }

    // Top Team (most wins)
    if (teamArray.length > 0) {
      topTeam = teamArray.reduce((prev, current) => 
        (prev.wins > current.wins) ? prev : current
      );
    }

    // Highest Scoring Team (most total points)
    if (teamArray.length > 0) {
      highestScoringTeam = teamArray.reduce((prev, current) => 
        (prev.totalPoints > current.totalPoints) ? prev : current
      );
    }

    // Lowest Scoring Team
    if (teamArray.length > 0) {
      lowestScoringTeam = teamArray.reduce((prev, current) => 
        (prev.totalPoints < current.totalPoints) ? prev : current
      );
    }

    // 3-Point Leader
    if (playerArray.length > 0) {
      threePointLeader = playerArray.reduce((prev, current) => 
        (prev.threePointers > current.threePointers) ? prev : current
      );
    }

    // 2-Point Leader
    if (playerArray.length > 0) {
      twoPointLeader = playerArray.reduce((prev, current) => 
        (prev.twoPointers > current.twoPointers) ? prev : current
      );
    }

    // Most Assists
    if (playerArray.length > 0) {
      mostAssistsPlayer = playerArray.reduce((prev, current) => 
        (prev.assists > current.assists) ? prev : current
      );
    }

    // Most Fouls
    if (playerArray.length > 0) {
      mostFoulsPlayer = playerArray.reduce((prev, current) => 
        (prev.fouls > current.fouls) ? prev : current
      );
    }

    // Most Violations
    if (playerArray.length > 0) {
      mostViolationsPlayer = playerArray.reduce((prev, current) => 
        (prev.violations > current.violations) ? prev : current
      );
    }

    return {
      topPlayer,
      topTeam,
      highestScoringGame,
      highestScoringTeam,
      threePointLeader,
      twoPointLeader,
      mostAssistsPlayer,
      mostFoulsPlayer,
      mostViolationsPlayer,
      lowestScoringTeam
    };
  };

  const loadHomeData = async () => {
    setLoading(true);
    try {
      // Fetch games separately to handle errors individually
      let scheduledGames = [];
      let teamLiveGames = [];
      let allUserGames = [];
      let topScorersData = [];

      try {
        const scheduledRes = await gamesAPI.getGames({ status: 'scheduled' });
        scheduledGames = Array.isArray(scheduledRes) ? scheduledRes.slice(0, 5) : (scheduledRes?.matches || []).slice(0, 5);
      } catch (error) {
        console.warn('Error loading scheduled matches:', error);
      }

      // Fetch ALL games for stats calculation
      try {
        const allGamesRes = await gamesAPI.getGames();
        allUserGames = Array.isArray(allGamesRes) ? allGamesRes : (allGamesRes?.matches || []);
      } catch (error) {
        console.warn('Error loading all games:', error);
      }

      // Fetch live games where user is a team member (only if authenticated)
      try {
        // Check if user is authenticated by checking AsyncStorage
        const userData = await AsyncStorage.getItem('user_data');
        const token = await AsyncStorage.getItem('access_token');
        
        if (userData && token) {
          // User is authenticated, fetch live games
          const liveTeamRes = await gamesAPI.getMyLiveGames();
          teamLiveGames = Array.isArray(liveTeamRes) ? liveTeamRes : (liveTeamRes?.matches || []);
        } else {
          // User not authenticated, skip live games fetch
          console.log('User not authenticated, skipping live games fetch');
          teamLiveGames = [];
        }
      } catch (error) {
        // Handle 401 Unauthorized silently (expected if token expired)
        if (error.response?.status === 401) {
          console.log('User authentication expired or invalid, skipping live games');
          teamLiveGames = [];
        } else {
          console.warn('Error loading live team games:', error);
          teamLiveGames = [];
        }
      }

      // Fetch real top scorers from game stats
      let userTotalAssists = 0;
      const allGameStats = {}; // Store stats for all games
      try {
        if (allUserGames && allUserGames.length > 0) {
          // Aggregate player points from all games
          const playerPoints = {};
          
          // Fetch stats for each game
          for (const game of allUserGames) {
            try {
              const gameStats = await gamesAPI.getGameStats(game.id);
              allGameStats[game.id] = gameStats; // Store stats
              
              if (gameStats) {
                // Process home team scorers
                if (gameStats.home_team_top_scorers && Array.isArray(gameStats.home_team_top_scorers)) {
                  gameStats.home_team_top_scorers.forEach(scorer => {
                    const playerName = scorer.name || 'Unknown Player';
                    const points = scorer.points || 0;
                    const assists = scorer.assists || 0;
                    const teamName = game.home_team?.name || 'Unknown Team';
                    
                    // Track user's assists if this is the user
                    if (playerName.toLowerCase() === user?.username?.toLowerCase()) {
                      userTotalAssists += assists;
                    }
                    
                    if (!playerPoints[playerName]) {
                      playerPoints[playerName] = {
                        name: playerName,
                        points: 0,
                        team: teamName,
                        gamesPlayed: 0
                      };
                    }
                    playerPoints[playerName].points += points;
                    playerPoints[playerName].gamesPlayed += 1;
                  });
                }
                
                // Process away team scorers
                if (gameStats.away_team_top_scorers && Array.isArray(gameStats.away_team_top_scorers)) {
                  gameStats.away_team_top_scorers.forEach(scorer => {
                    const playerName = scorer.name || 'Unknown Player';
                    const points = scorer.points || 0;
                    const assists = scorer.assists || 0;
                    const teamName = game.away_team?.name || 'Unknown Team';
                    
                    // Track user's assists if this is the user
                    if (playerName.toLowerCase() === user?.username?.toLowerCase()) {
                      userTotalAssists += assists;
                    }
                    
                    if (!playerPoints[playerName]) {
                      playerPoints[playerName] = {
                        name: playerName,
                        points: 0,
                        team: teamName,
                        gamesPlayed: 0
                      };
                    }
                    playerPoints[playerName].points += points;
                    playerPoints[playerName].gamesPlayed += 1;
                  });
                }
              }
            } catch (err) {
              console.warn(`Error fetching stats for game ${game.id}:`, err);
            }
          }
          
          // Convert to array, sort by points, and take top 5
          topScorersData = Object.values(playerPoints)
            .sort((a, b) => b.points - a.points)
            .slice(0, 5);
          
          console.log('Top Scorers Data:', topScorersData);
        }
      } catch (error) {
        console.warn('Error loading top scorers:', error);
        // Fallback to empty array
        topScorersData = [];
      }
      
      // Update assists in stats
      setStats(prevStats => ({
        ...prevStats,
        totalAssists: userTotalAssists
      }));

      setUpcomingGames(scheduledGames);
      setLiveTeamGames(teamLiveGames);
      // Calculate stats from ALL games
      calculateStats(allUserGames);
      
      // Calculate week highlights data
      const highlightsData = calculateWeekHighlights(allUserGames, allGameStats);
      setWeekHighlightsData(highlightsData);
      
      // Set real top scorers data
      setTopScorers(topScorersData.length > 0 ? topScorersData : []);
    } catch (error) {
      console.error('Error loading home data:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadHomeData();
    setRefreshing(false);
  };

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          await AsyncStorage.removeItem('auth_token');
          await AsyncStorage.removeItem('user_data');
          router.replace('/login');
        }
      }
    ]);
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Animated Header with Dunk Animation */}
        <Animated.View
          style={[
            styles.header,
            {
              transform: [
                {
                  translateY: bounceAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-30, 0]
                  })
                }
              ],
              opacity: bounceAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0.7, 1]
              })
            }
          ]}
        >
          <View>
            <Text style={styles.greeting}>🏀 {user?.username || 'Athlete'}!</Text>
            <Text style={styles.subtext}>Ready to score?</Text>
          </View>
        </Animated.View>

        {/* Live Games Section */}
        {liveTeamGames.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>🔴 Live Games</Text>
              <TouchableOpacity onPress={() => router.push('/games')}>
                <Text style={styles.seeAll}>See All</Text>
              </TouchableOpacity>
            </View>

            {liveTeamGames.map((game) => (
              <TouchableOpacity
                key={game.id}
                style={[styles.gameCard, styles.liveGameCard]}
                onPress={() => router.push(`/match-detail?gameId=${game.id}`)}
              >
                <View style={styles.liveIndicator}>
                  <View style={styles.liveDot} />
                  <Text style={styles.liveText}>LIVE</Text>
                </View>
                <View style={styles.gameInfo}>
                  <Text style={styles.teamName}>{game.home_team?.name || 'Team A'}</Text>
                  <Text style={styles.liveScore}>
                    {game.home_score || 0} - {game.away_score || 0}
                  </Text>
                  <Text style={styles.teamName}>{game.away_team?.name || 'Team B'}</Text>
                </View>
                <TouchableOpacity 
                  style={styles.scoreButton}
                  onPress={() => router.push(`/match-detail?gameId=${game.id}`)}
                >
                  <Text style={styles.scoreButtonText}>Details →</Text>
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Upcoming Games Section */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>⏱️ Upcoming Games</Text>
            <TouchableOpacity onPress={() => router.push('/games?filter=scheduled')}>
              <Text style={styles.seeAll}>See All</Text>
            </TouchableOpacity>
          </View>

          {upcomingGames.length > 0 ? (
            <ScrollView 
              style={styles.upcomingGamesScroll}
              scrollEnabled={true}
              showsVerticalScrollIndicator={false}
            >
              {upcomingGames.slice(0, 2).map((game) => (
                <TouchableOpacity
                  key={game.id}
                  style={styles.gameCard}
                  onPress={() => router.push('/games?filter=scheduled')}
                >
                  <View style={styles.gameStatusBadge}>
                    <Text style={styles.gameStatusText}>⏱️ Scheduled</Text>
                  </View>
                  <View style={styles.gameInfo}>
                    <Text style={styles.teamName}>{game.home_team?.name || 'Team A'}</Text>
                    <Text style={styles.vs}>vs</Text>
                    <Text style={styles.teamName}>{game.away_team?.name || 'Team B'}</Text>
                  </View>
                  <Text style={styles.gameTime}>
                    {new Date(game.match_date).toLocaleDateString()}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          ) : (
            <Text style={styles.emptyText}>No upcoming games</Text>
          )}
        </View>

        {/* Current Week Streak Section */}
        <View style={styles.weekStreakSection}>
          <Text style={styles.weekStreakTitle}>🏆 This Week's League Highlights</Text>
          
          {weekHighlightsData ? (
            <>
              {/* Card 1: MVP & Team Leaders (2x2 grid) */}
              <View style={styles.highlightsTitleContainer}>
                <Animated.Text style={[
                  styles.highlightsSectionTitle1,
                  {
                    transform: [
                      {
                        rotate: emoji1Anim.interpolate({
                          inputRange: [0, 1],
                          outputRange: ['0deg', '360deg']
                        })
                      },
                      {
                        scale: emoji1Anim.interpolate({
                          inputRange: [0, 0.5, 1],
                          outputRange: [0, 1.2, 1]
                        })
                      }
                    ]
                  }
                ]}>🌟</Animated.Text>
                <Text style={styles.highlightsTitleText}>MVP & Team Leaders</Text>
              </View>
              <Animated.View style={[
                styles.highlightsCardContainer,
                {
                  opacity: card1Anim,
                  transform: [
                    {
                      translateX: card1Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [-100, 0]
                      })
                    },
                    {
                      rotate: card1Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ['-15deg', '0deg']
                      })
                    },
                    {
                      scale: card1Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0.8, 1]
                      })
                    }
                  ]
                }
              ]}>
              <View style={styles.highlightsCard1}>
                {/* Top Player */}
                {weekHighlightsData.topPlayer && (
                  <View style={[styles.highlightItem, { flex: 1, marginRight: 6 }]}>
                    <Animated.Text style={[
                      styles.highlightEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji1_1.interpolate({
                              inputRange: [0, 0.5, 1],
                              outputRange: [0.5, 1.2, 1]
                            })
                          },
                          {
                            rotate: cardEmoji1_1.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '360deg']
                            })
                          }
                        ]
                      }
                    ]}>🏆</Animated.Text>
                    <Text style={styles.highlightLabel}>Top Player</Text>
                    <Text style={styles.highlightName}>{weekHighlightsData.topPlayer.name}</Text>
                    <Text style={styles.highlightValue}>{weekHighlightsData.topPlayer.points} pts</Text>
                    <Text style={styles.highlightTeam}>{weekHighlightsData.topPlayer.team}</Text>
                  </View>
                )}
                
                {/* Top Team */}
                {weekHighlightsData.topTeam && (
                  <View style={[styles.highlightItem, { flex: 1 }]}>
                    <Animated.Text style={[
                      styles.highlightEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji1_2.interpolate({
                              inputRange: [0, 0.3, 0.6, 1],
                              outputRange: [0.8, 1.3, 1.1, 1]
                            })
                          }
                        ]
                      }
                    ]}>👥</Animated.Text>
                    <Text style={styles.highlightLabel}>Top Team</Text>
                    <Text style={styles.highlightName}>{weekHighlightsData.topTeam.name}</Text>
                    <Text style={styles.highlightValue}>{weekHighlightsData.topTeam.wins} wins</Text>
                    <Text style={styles.highlightTeam}>-</Text>
                  </View>
                )}
              </View>

              <View style={styles.highlightsCard1Row2}>
                {/* Highest Scoring Game */}
                {weekHighlightsData.highestScoringGame && (
                  <View style={[styles.highlightItem, { flex: 1, marginRight: 6 }]}>
                    <Animated.Text style={[
                      styles.highlightEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji1_3.interpolate({
                              inputRange: [0, 0.5, 1],
                              outputRange: [0.6, 1.4, 1]
                            })
                          },
                          {
                            rotate: cardEmoji1_3.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '-20deg']
                            })
                          }
                        ]
                      }
                    ]}>💥</Animated.Text>
                    <Text style={styles.highlightLabel}>Highest Point Game</Text>
                    <Text style={styles.highlightName}>{weekHighlightsData.highestScoringGame.totalScore} pts</Text>
                    <Text style={styles.highlightValue}>{weekHighlightsData.highestScoringGame.homeScore}-{weekHighlightsData.highestScoringGame.awayScore}</Text>
                    <Text style={styles.highlightTeam} numberOfLines={1}>{weekHighlightsData.highestScoringGame.homeTeam}</Text>
                  </View>
                )}
                
                {/* Highest Scoring Team */}
                {weekHighlightsData.highestScoringTeam && (
                  <View style={[styles.highlightItem, { flex: 1 }]}>
                    <Animated.Text style={[
                      styles.highlightEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji1_4.interpolate({
                              inputRange: [0, 0.3, 0.6, 1],
                              outputRange: [0.8, 1.4, 1.2, 1]
                            })
                          },
                          {
                            rotate: cardEmoji1_4.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '360deg']
                            })
                          }
                        ]
                      }
                    ]}>🔥</Animated.Text>
                    <Text style={styles.highlightLabel}>Highest Scoring Team</Text>
                    <Text style={styles.highlightName}>{weekHighlightsData.highestScoringTeam.name}</Text>
                    <Text style={styles.highlightValue}>{weekHighlightsData.highestScoringTeam.totalPoints} pts</Text>
                    <Text style={styles.highlightTeam}>-</Text>
                  </View>
                )}
              </View>
              </Animated.View>

              {/* Card 2: Scoring Leaders (3 columns) */}
              <View style={styles.highlightsTitleContainer}>
                <Animated.Text style={[
                  styles.highlightsSectionTitle2,
                  {
                    transform: [
                      {
                        scale: emoji2Anim.interpolate({
                          inputRange: [0, 0.25, 0.5, 0.75, 1],
                          outputRange: [1, 1.3, 1, 1.3, 1]
                        })
                      }
                    ]
                  }
                ]}>🎯</Animated.Text>
                <Text style={styles.highlightsTitleText2}>Scoring Leaders</Text>
              </View>
              <Animated.View style={[
                styles.highlightsCardContainer,
                {
                  opacity: card2Anim,
                  transform: [
                    {
                      translateY: card2Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [100, 0]
                      })
                    },
                    {
                      scale: card2Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0.8, 1]
                      })
                    }
                  ]
                }
              ]}>
              <View style={styles.highlightsCard2}>
                {weekHighlightsData.threePointLeader && (
                  <View style={styles.highlightSmallItem}>
                    <Animated.Text style={[
                      styles.highlightSmallEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji2_1.interpolate({
                              inputRange: [0, 0.5, 1],
                              outputRange: [0.6, 1.3, 1]
                            })
                          },
                          {
                            rotate: cardEmoji2_1.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '360deg']
                            })
                          }
                        ]
                      }
                    ]}>🎯</Animated.Text>
                    <Text style={styles.highlightSmallLabel}>3-Point Leader</Text>
                    <Text style={styles.highlightSmallName}>{weekHighlightsData.threePointLeader.name}</Text>
                    <Text style={styles.highlightSmallValue}>{weekHighlightsData.threePointLeader.threePointers}</Text>
                  </View>
                )}

                {weekHighlightsData.twoPointLeader && (
                  <View style={styles.highlightSmallItem}>
                    <Animated.Text style={[
                      styles.highlightSmallEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji2_2.interpolate({
                              inputRange: [0, 0.3, 0.6, 1],
                              outputRange: [0.8, 1.4, 1.2, 1]
                            })
                          },
                          {
                            rotate: cardEmoji2_2.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '-30deg']
                            })
                          }
                        ]
                      }
                    ]}>🏀</Animated.Text>
                    <Text style={styles.highlightSmallLabel}>2-Point Leader</Text>
                    <Text style={styles.highlightSmallName}>{weekHighlightsData.twoPointLeader.name}</Text>
                    <Text style={styles.highlightSmallValue}>{weekHighlightsData.twoPointLeader.twoPointers}</Text>
                  </View>
                )}

                {weekHighlightsData.mostAssistsPlayer && (
                  <View style={styles.highlightSmallItem}>
                    <Animated.Text style={[
                      styles.highlightSmallEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji2_3.interpolate({
                              inputRange: [0, 0.5, 1],
                              outputRange: [0.8, 1.3, 1]
                            })
                          },
                          {
                            rotate: cardEmoji2_3.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['-20deg', '20deg']
                            })
                          }
                        ]
                      }
                    ]}>🎪</Animated.Text>
                    <Text style={styles.highlightSmallLabel}>Assists Leader</Text>
                    <Text style={styles.highlightSmallName}>{weekHighlightsData.mostAssistsPlayer.name}</Text>
                    <Text style={styles.highlightSmallValue}>{weekHighlightsData.mostAssistsPlayer.assists}</Text>
                  </View>
                )}
              </View>
              </Animated.View>

              {/* Card 3: Defensive & Lowest Performers (3 columns) - Teal Theme */}
              <View style={styles.highlightsTitleContainer}>
                <Animated.Text style={[
                  styles.highlightsSectionTitle3,
                  {
                    transform: [
                      {
                        rotateY: emoji3Anim.interpolate({
                          inputRange: [0, 1],
                          outputRange: ['0deg', '360deg']
                        })
                      },
                      {
                        scale: emoji3Anim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [1, 1.1]
                        })
                      }
                    ]
                  }
                ]}>🛡️</Animated.Text>
                <Text style={styles.highlightsTitleText3}>Defensive Stats & Lowest Performers</Text>
              </View>
              <Animated.View style={[
                styles.highlightsCardContainer,
                {
                  opacity: card3Anim,
                  transform: [
                    {
                      translateX: card3Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [100, 0]
                      })
                    },
                    {
                      rotate: card3Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ['15deg', '0deg']
                      })
                    },
                    {
                      scale: card3Anim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0.8, 1]
                      })
                    }
                  ]
                }
              ]}>
              <View style={styles.highlightsCard3}>
                {weekHighlightsData.mostFoulsPlayer && (
                  <View style={styles.highlightSmallItemCard3}>
                    <Animated.Text style={[
                      styles.highlightSmallEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji3_1.interpolate({
                              inputRange: [0, 0.5, 1],
                              outputRange: [0.7, 1.4, 1]
                            })
                          },
                          {
                            rotate: cardEmoji3_1.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '-30deg']
                            })
                          }
                        ]
                      }
                    ]}>⚠️</Animated.Text>
                    <Text style={styles.highlightSmallLabel}>Most Fouls</Text>
                    <Text style={styles.highlightSmallNameCard3}>{weekHighlightsData.mostFoulsPlayer.name}</Text>
                    <Text style={styles.highlightSmallValueCard3}>{weekHighlightsData.mostFoulsPlayer.fouls}</Text>
                  </View>
                )}

                {weekHighlightsData.mostViolationsPlayer && (
                  <View style={styles.highlightSmallItemCard3}>
                    <Animated.Text style={[
                      styles.highlightSmallEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji3_2.interpolate({
                              inputRange: [0, 0.3, 0.6, 1],
                              outputRange: [0.8, 1.3, 1.1, 1]
                            })
                          },
                          {
                            rotate: cardEmoji3_2.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '360deg']
                            })
                          }
                        ]
                      }
                    ]}>🚫</Animated.Text>
                    <Text style={styles.highlightSmallLabel}>Most Violations</Text>
                    <Text style={styles.highlightSmallNameCard3}>{weekHighlightsData.mostViolationsPlayer.name}</Text>
                    <Text style={styles.highlightSmallValueCard3}>{weekHighlightsData.mostViolationsPlayer.violations}</Text>
                  </View>
                )}

                {weekHighlightsData.lowestScoringTeam && (
                  <View style={styles.highlightSmallItemCard3}>
                    <Animated.Text style={[
                      styles.highlightSmallEmoji,
                      {
                        transform: [
                          {
                            scale: cardEmoji3_3.interpolate({
                              inputRange: [0, 0.5, 1],
                              outputRange: [0.9, 1.2, 1]
                            })
                          },
                          {
                            rotate: cardEmoji3_3.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', '-20deg']
                            })
                          }
                        ]
                      }
                    ]}>📉</Animated.Text>
                    <Text style={styles.highlightSmallLabel}>Lowest Team</Text>
                    <Text style={styles.highlightSmallNameCard3}>{weekHighlightsData.lowestScoringTeam.name}</Text>
                    <Text style={styles.highlightSmallValueCard3}>{weekHighlightsData.lowestScoringTeam.totalPoints} pts</Text>
                  </View>
                )}
              </View>
              </Animated.View>
            </>
          ) : (
            <View style={styles.noDataContainer}>
              <Text style={styles.noDataText}>No games this week</Text>
            </View>
          )}
        </View>

        {/* League Leaders Section - Top 5 */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>⭐ League Leaders (Top 5)</Text>
          {topScorers.slice(0, 5).map((scorer) => (
            <View key={scorer.name} style={styles.leaderCard}>
              <View style={styles.leaderRank}>
                <Text style={styles.leaderRankText}>#{topScorers.indexOf(scorer) + 1}</Text>
              </View>
              <View style={styles.leaderInfo}>
                <Text style={styles.leaderName}>{scorer.name}</Text>
                <Text style={styles.leaderTeam}>{scorer.team}</Text>
              </View>
              <View style={styles.leaderPoints}>
                <Text style={styles.leaderPointsText}>{scorer.points}pts</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Basketball Insights Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>🎯 Basketball Insights</Text>
          
          {/* Tip 1 */}
          <View style={styles.insightCard}>
            <View style={[styles.insightIcon, { backgroundColor: '#81C784' }]}>
              <Text style={styles.insightIconText}>💡</Text>
            </View>
            <View style={styles.insightContent}>
              <Text style={styles.insightTitle}>Master Your Defense</Text>
              <Text style={styles.insightText}>Strong defense wins games. Focus on positioning and anticipation.</Text>
            </View>
          </View>

          {/* Tip 2 */}
          <View style={styles.insightCard}>
            <View style={[styles.insightIcon, { backgroundColor: '#64B5F6' }]}>
              <Text style={styles.insightIconText}>🏃</Text>
            </View>
            <View style={styles.insightContent}>
              <Text style={styles.insightTitle}>Conditioning Matters</Text>
              <Text style={styles.insightText}>Stay fit and train regularly for better performance on court.</Text>
            </View>
          </View>

          {/* Tip 3 */}
          <View style={styles.insightCard}>
            <View style={[styles.insightIcon, { backgroundColor: '#FFB74D' }]}>
              <Text style={styles.insightIconText}>👥</Text>
            </View>
            <View style={styles.insightContent}>
              <Text style={styles.insightTitle}>Team Chemistry</Text>
              <Text style={styles.insightText}>Practice together to build chemistry and improve coordination.</Text>
            </View>
          </View>

          {/* Tip 4 */}
          <View style={styles.insightCard}>
            <View style={[styles.insightIcon, { backgroundColor: '#CE93D8' }]}>
              <Text style={styles.insightIconText}>📊</Text>
            </View>
            <View style={styles.insightContent}>
              <Text style={styles.insightTitle}>Track Your Stats</Text>
              <Text style={styles.insightText}>Monitor your performance data to identify improvement areas.</Text>
            </View>
          </View>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BG_LIGHT
  },
  scrollContent: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
    paddingVertical: SPACING.xs
  },
  greeting: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  subtext: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY
  },
  logoutButton: {
    backgroundColor: COLORS.ACCENT,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: 6
  },
  logoutText: {
    color: COLORS.BG_LIGHT,
    fontSize: 11,
    fontWeight: '600'
  },
  section: {
    marginBottom: SPACING.sm
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.xs,
    paddingHorizontal: SPACING.xs
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: SPACING.sm,
    paddingHorizontal: SPACING.xs
  },
  seeAll: {
    color: COLORS.SECONDARY,
    fontSize: 11,
    fontWeight: '500'
  },
  upcomingGamesScroll: {
    maxHeight: 200,
    paddingHorizontal: SPACING.xs
  },
  gameCard: {
    backgroundColor: '#E3F2FD',
    padding: SPACING.xs,
    borderRadius: 6,
    marginBottom: 3,
    borderLeftWidth: 3,
    borderLeftColor: COLORS.SECONDARY
  },
  gameStatusBadge: {
    marginBottom: 4,
    paddingVertical: 2,
    paddingHorizontal: 4,
    backgroundColor: 'rgba(0,0,0,0.05)',
    borderRadius: 4
  },
  gameStatusText: {
    fontSize: 10,
    fontWeight: '600',
    color: COLORS.PRIMARY
  },
  liveGameCard: {
    borderLeftColor: '#FF3B30',
    backgroundColor: '#FFF5F5',
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 3,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#FF3B30',
    marginRight: SPACING.xs,
  },
  liveText: {
    color: '#FF3B30',
    fontSize: 9,
    fontWeight: '700',
  },
  liveScore: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginVertical: 1,
  },
  scoreButton: {
    backgroundColor: '#FF3B30',
    paddingVertical: 4,
    paddingHorizontal: SPACING.xs,
    borderRadius: 4,
    alignItems: 'center',
    marginTop: 3,
  },
  scoreButtonText: {
    color: '#FFF',
    fontSize: 11,
    fontWeight: '600',
  },
  gameInfo: {
    alignItems: 'center',
    marginBottom: 3
  },
  teamName: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.PRIMARY
  },
  vs: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    marginVertical: 1
  },
  gameTime: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY
  },
  // Stats Section Styles - SIMPLE 3x2 GRID
  statsSection: {
    marginBottom: SPACING.md,
    paddingVertical: SPACING.sm
  },
  statsSectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginBottom: SPACING.sm,
    paddingHorizontal: SPACING.xs
  },
  statsRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8
  },
  statCard: {
    flex: 1,
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 100
  },
  statCardGreen: {
    backgroundColor: '#81C784'
  },
  statCardBlue: {
    backgroundColor: '#64B5F6'
  },
  statCardOrange: {
    backgroundColor: '#FFB74D'
  },
  statCardPurple: {
    backgroundColor: '#CE93D8'
  },
  statCardEmoji: {
    fontSize: 28,
    marginBottom: 6
  },
  statCardLabel: {
    fontSize: 12,
    color: '#FFF',
    fontWeight: '600',
    textAlign: 'center'
  },
  statCardValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#FFF',
    marginVertical: 4
  },
  statCardName: {
    fontSize: 10,
    color: '#FFF',
    textAlign: 'center',
    fontWeight: '500'
  },
  // Leader Card Styles
  leaderCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 6,
    padding: SPACING.sm,
    marginBottom: 6,
    gap: 10
  },
  leaderRank: {
    width: 35,
    height: 35,
    borderRadius: 17.5,
    backgroundColor: '#FFB74D',
    justifyContent: 'center',
    alignItems: 'center'
  },
  leaderRankText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#FFF'
  },
  leaderInfo: {
    flex: 1
  },
  leaderName: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.PRIMARY
  },
  leaderTeam: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 2
  },
  leaderPoints: {
    backgroundColor: '#81C784',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: 4
  },
  leaderPointsText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#FFF'
  },
  // Summary Styles
  summaryGrid: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: SPACING.sm
  },
  summaryCard: {
    flex: 1,
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 6,
    padding: SPACING.sm,
    alignItems: 'center'
  },
  summaryEmoji: {
    fontSize: 20,
    marginBottom: 4
  },
  summaryValue: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.SECONDARY,
    marginBottom: 2
  },
  summaryLabel: {
    fontSize: 9,
    color: COLORS.TEXT_SECONDARY,
    textAlign: 'center',
    fontWeight: '500'
  },
  // Insight Card Styles
  insightCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 6,
    padding: SPACING.sm,
    marginBottom: 8,
    gap: 10
  },
  insightIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center'
  },
  insightIconText: {
    fontSize: 18
  },
  insightContent: {
    flex: 1
  },
  insightTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  insightText: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    lineHeight: 14
  },
  emptyText: {
    color: COLORS.TEXT_SECONDARY,
    fontSize: 12,
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: SPACING.sm
  },
  // Week Streak Styles
  weekStreakSection: {
    marginBottom: SPACING.md,
    paddingVertical: SPACING.sm
  },
  weekStreakTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginBottom: SPACING.sm,
    paddingHorizontal: SPACING.xs
  },
  weekOverviewCard: {
    backgroundColor: '#E3F2FD',
    borderRadius: 10,
    padding: SPACING.sm,
    marginBottom: SPACING.sm,
    borderLeftWidth: 4,
    borderLeftColor: '#64B5F6'
  },
  weekInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12
  },
  weekInfoItem: {
    flex: 1,
    paddingHorizontal: 8
  },
  weekInfoLabel: {
    fontSize: 11,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '600',
    marginBottom: 4
  },
  weekInfoValue: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.PRIMARY
  },
  streakItem: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 8,
    padding: 10,
    marginHorizontal: 4
  },
  streakEmoji: {
    fontSize: 20,
    marginBottom: 6
  },
  streakLabel: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '600',
    marginBottom: 4
  },
  streakValue: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.PRIMARY
  },
  dailyStatsContainer: {
    marginBottom: SPACING.sm
  },
  dailyStatsTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginBottom: 8,
    paddingHorizontal: SPACING.xs
  },
  dailyGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 6
  },
  dailyStatCard: {
    flex: 1,
    alignItems: 'center',
    borderRadius: 8,
    padding: 10,
    minHeight: 80
  },
  dailyDay: {
    fontSize: 10,
    fontWeight: '700',
    color: '#FFF',
    marginBottom: 4
  },
  dailyEmoji: {
    fontSize: 18,
    marginBottom: 4
  },
  dailyGameCount: {
    fontSize: 12,
    fontWeight: '700',
    color: '#FFF'
  },
  statsBreakdown: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 8
  },
  breakdownCard: {
    width: '48%',
    alignItems: 'center',
    borderRadius: 8,
    padding: 12,
    minHeight: 90
  },
  breakdownCardGreen: {
    backgroundColor: '#81C784'
  },
  breakdownCardBlue: {
    backgroundColor: '#64B5F6'
  },
  breakdownCardOrange: {
    backgroundColor: '#FFB74D'
  },
  breakdownCardPurple: {
    backgroundColor: '#CE93D8'
  },
  breakdownEmoji: {
    fontSize: 24,
    marginBottom: 6
  },
  breakdownValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FFF',
    marginBottom: 4
  },
  breakdownLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#FFF'
  },
  noDataContainer: {
    backgroundColor: '#E3F2FD',
    borderRadius: 8,
    padding: SPACING.sm,
    alignItems: 'center'
  },
  noDataText: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '500'
  },
  // New Highlights Styles - Card 1 (MVP & Teams) - Purple Theme
  highlightsCard1: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8
  },
  highlightsCard1Row2: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8
  },
  highlightItem: {
    backgroundColor: '#F3E5F5',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    borderLeftWidth: 4,
    borderLeftColor: '#9C27B0'
  },
  highlightEmoji: {
    fontSize: 28,
    marginBottom: 6
  },
  highlightLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 4
  },
  highlightName: {
    fontSize: 13,
    fontWeight: '700',
    color: '#7B1FA2',
    marginBottom: 4,
    textAlign: 'center'
  },
  highlightValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#9C27B0',
    marginBottom: 4
  },
  highlightTeam: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '500'
  },
  // Card 2 (Scoring Leaders) - Orange/Gold Theme
  highlightsCard2: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8
  },
  // Card 3 (Defense & Lows) - Teal/Cyan Theme
  highlightsCard3: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 8
  },
  // Small items for Cards 2 and 3
  highlightSmallItem: {
    flex: 1,
    backgroundColor: '#FFF3E0',
    borderRadius: 8,
    padding: 10,
    alignItems: 'center',
    borderLeftWidth: 3,
    borderLeftColor: '#FF9800'
  },
  highlightSmallEmoji: {
    fontSize: 20,
    marginBottom: 4
  },
  highlightSmallLabel: {
    fontSize: 9,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 3
  },
  highlightSmallName: {
    fontSize: 11,
    fontWeight: '700',
    color: '#E65100',
    marginBottom: 3,
    textAlign: 'center'
  },
  highlightSmallValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FF6F00'
  },
  // Card 3 specific styling - Teal theme
  highlightSmallItemCard3: {
    flex: 1,
    backgroundColor: '#E0F2F1',
    borderRadius: 8,
    padding: 10,
    alignItems: 'center',
    borderLeftWidth: 3,
    borderLeftColor: '#00897B'
  },
  highlightSmallNameCard3: {
    fontSize: 11,
    fontWeight: '700',
    color: '#004D40',
    marginBottom: 3,
    textAlign: 'center'
  },
  highlightSmallValueCard3: {
    fontSize: 14,
    fontWeight: '700',
    color: '#00897B'
  },
  // Animated highlights section titles - Basketball themed with color matching
  highlightsCardContainer: {
    marginBottom: 8
  },
  highlightsTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
    marginTop: 12,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 6
  },
  highlightsSectionTitle1: {
    fontSize: 18,
    fontWeight: '700',
    color: '#7B1FA2',
    backgroundColor: '#F3E5F5',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#9C27B0'
  },
  highlightsTitleText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#7B1FA2',
    backgroundColor: '#F3E5F5',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 6,
    borderLeftWidth: 4,
    borderLeftColor: '#9C27B0',
    flex: 1
  },
  highlightsSectionTitle2: {
    fontSize: 18,
    fontWeight: '700',
    color: '#E65100',
    backgroundColor: '#FFF3E0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#FF9800'
  },
  highlightsTitleText2: {
    fontSize: 14,
    fontWeight: '700',
    color: '#E65100',
    backgroundColor: '#FFF3E0',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 6,
    borderLeftWidth: 4,
    borderLeftColor: '#FF9800',
    flex: 1
  },
  highlightsSectionTitle3: {
    fontSize: 18,
    fontWeight: '700',
    color: '#004D40',
    backgroundColor: '#E0F2F1',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#00897B'
  },
  highlightsTitleText3: {
    fontSize: 14,
    fontWeight: '700',
    color: '#004D40',
    backgroundColor: '#E0F2F1',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 6,
    borderLeftWidth: 4,
    borderLeftColor: '#00897B',
    flex: 1
  }
});

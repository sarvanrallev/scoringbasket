import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
  FlatList,
  Modal,
  TextInput,
  Animated
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { teamsAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function TeamsScreen() {
  const router = useRouter();
  const [teams, setTeams] = useState([]);
  const [myTeams, setMyTeams] = useState([]);
  const [allTeams, setAllTeams] = useState([]);
  const [filter, setFilter] = useState('my'); // 'my' or 'all'
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [teamName, setTeamName] = useState('');
  const [teamCity, setTeamCity] = useState('');
  const [creating, setCreating] = useState(false);
  
  // Animation refs
  const scaleAnim = new Animated.Value(0);
  const opacityAnim = new Animated.Value(0);

  useEffect(() => {
    loadUserData();
    loadTeams();
  }, []);

  // Refresh teams when screen comes into focus (e.g., after adding members)
  useFocusEffect(
    React.useCallback(() => {
      loadTeams();
    }, [])
  );

  // Trigger animations when teams load
  useEffect(() => {
    if (teams.length > 0) {
      scaleAnim.setValue(0);
      opacityAnim.setValue(0);
      Animated.parallel([
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true
        }),
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true
        })
      ]).start();
    }
  }, [teams]);

  const loadUserData = async () => {
    // Load user data for team context (commented out - not currently used)
    try {
      await AsyncStorage.getItem('user_data');
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const loadTeams = async () => {
    setLoading(true);
    try {
      // Load all teams (public list - don't fetch member counts to avoid 403s)
      const allTeamsResponse = await teamsAPI.getTeams();
      const allTeamsData = Array.isArray(allTeamsResponse) ? allTeamsResponse : [];
      
      // Use player_count from API response directly (no member fetch for public list)
      setAllTeams(allTeamsData);

      // Load user's teams
      const userData = await AsyncStorage.getItem('user_data');
      if (userData) {
        try {
          const userTeamsResponse = await teamsAPI.myTeams();
          const userTeamsData = Array.isArray(userTeamsResponse) ? userTeamsResponse : [];
          
          // Fetch member counts for user's teams (user has access to these)
          const userTeamsWithCounts = await Promise.all(
            userTeamsData.map(async (team) => {
              try {
                const members = await teamsAPI.getTeamMembers(team.id);
                return { ...team, player_count: members.length };
              } catch (error) {
                console.warn(`Could not fetch members for team ${team.id}:`, error);
                return { ...team, player_count: team.player_count || 0 };
              }
            })
          );
          
          setMyTeams(userTeamsWithCounts);
          // Respect current filter state
          if (filter === 'all') {
            setTeams(allTeamsData);
          } else {
            setTeams(userTeamsWithCounts);
          }
        } catch (error) {
          console.warn('Error loading user teams:', error);
          setMyTeams([]);
          setTeams(allTeamsData);
        }
      } else {
        // No user logged in, show all teams
        setMyTeams([]);
        setTeams(allTeamsData);
      }
    } catch (error) {
      console.error('Error loading teams:', error);
      if (error.response?.status === 401) {
        Alert.alert('Session Expired', 'Please log in again', [
          { text: 'OK', onPress: () => router.replace('/login') }
        ]);
      } else {
        Alert.alert('Error', 'Failed to load teams');
      }
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTeams();
    setRefreshing(false);
  };

  const handleCreateTeam = async () => {
    if (!teamName.trim()) {
      Alert.alert('Error', 'Please enter team name');
      return;
    }

    if (teamName.trim().length < 2) {
      Alert.alert('Error', 'Team name must be at least 2 characters');
      return;
    }

    setCreating(true);
    try {
      const trimmedName = teamName.trim();
      const trimmedCity = teamCity.trim();
      
      const payload = {
        name: trimmedName,
        description: trimmedCity 
          ? `${trimmedCity} ${trimmedName}`
          : trimmedName,
      };
      
      // Only include city if it has a value
      if (trimmedCity) {
        payload.city = trimmedCity;
      }

      console.log('[DEBUG] Create team payload:', payload);

      const response = await teamsAPI.createTeam(payload);

      console.log('[DEBUG] Team created:', response);
      
      const newTeam = response.team || response;
      
      // Fetch updated member count for newly created team
      try {
        const members = await teamsAPI.getTeamMembers(newTeam.id);
        newTeam.player_count = members.length;
        console.log('[DEBUG] Team created with member count:', newTeam.player_count);
      } catch (error) {
        // Skip if 403 (shouldn't happen for new team, but handle gracefully)
        if (error.response?.status === 403) {
          newTeam.player_count = 0;
        } else {
          console.warn('Could not fetch member count for new team:', error);
          newTeam.player_count = 0;
        }
      }
      
      // Add to myTeams (current user's team)
      const updatedMyTeams = [...myTeams, newTeam];
      setMyTeams(updatedMyTeams);
      
      // Add to allTeams
      const updatedAllTeams = [...allTeams, newTeam];
      setAllTeams(updatedAllTeams);
      
      // Update displayed teams based on current filter
      if (filter === 'all') {
        setTeams(updatedAllTeams);
      } else {
        setTeams(updatedMyTeams);
      }
      
      setTeamName('');
      setTeamCity('');
      setModalVisible(false);
      Alert.alert('Success', 'Team created successfully');
    } catch (error) {
      console.error('[DEBUG] Create team error:', error);
      console.error('[DEBUG] Error response:', error.response?.data);
      console.error('[DEBUG] Error status:', error.response?.status);
      console.error('[DEBUG] Error message:', error.message);
      
      let errorMsg = 'Failed to create team';
      
      // Handle 401 - redirect to login
      if (error.response?.status === 401) {
        Alert.alert('Session Expired', 'Your session has expired. Please log in again.', [
          {
            text: 'OK',
            onPress: () => {
              setModalVisible(false);
              router.replace('/login');
            }
          }
        ]);
        return;
      }
      
      if (error.response?.data?.detail) {
        errorMsg = error.response.data.detail;
      } else if (error.response?.data?.message) {
        errorMsg = error.response.data.message;
      } else if (error.response?.data?.errors) {
        errorMsg = JSON.stringify(error.response.data.errors);
      } else if (error.message) {
        errorMsg = error.message;
      }
      
      Alert.alert('Error', errorMsg);
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteTeam = (teamId, teamName) => {
    Alert.alert(
      'Delete Team',
      `Are you sure you want to delete "${teamName}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await teamsAPI.deleteTeam(teamId);
              Alert.alert('Success', 'Team deleted successfully');
              loadTeams();
            } catch (error) {
              console.error('Error deleting team:', error);
              Alert.alert('Error', 'Failed to delete team');
            }
          }
        }
      ]
    );
  };

  const renderTeamCard = ({ item: team }) => {
    const isMyTeam = myTeams.some(t => t.id === team.id);
    
    // Determine card color based on filter and user status
    let cardStyle = styles.teamCard;
    if (isMyTeam) {
      if (filter === 'my') {
        cardStyle = [styles.teamCard, styles.teamCardMyTeams];
      } else {
        cardStyle = [styles.teamCard, styles.teamCardAll];
      }
    } else {
      if (filter === 'all') {
        cardStyle = [styles.teamCard, styles.teamCardOther];
      }
    }
    
    return (
      <TouchableOpacity
        style={cardStyle}
        onPress={() => router.push(`/teams/details?teamId=${team.id}`)}
      >
        <View style={styles.teamInfo}>
          <Text style={styles.teamNameText}>{team.name}</Text>
          {team.captain && (
            <Text style={styles.captainText}>Captain: {team.captain.name}</Text>
          )}
          <Text style={styles.teamCity}>{team.city || 'Unknown City'}</Text>
          <View style={styles.statsRow}>
            <Text style={styles.stat}>
              {team.wins || 0}W - {team.losses || 0}L
            </Text>
            <Text style={styles.playerCountText}>
              👥 {team.player_count || 0} Players
            </Text>
          </View>
        </View>
        {isMyTeam && (
          <TouchableOpacity
            style={styles.deleteButton}
            onPress={() => handleDeleteTeam(team.id, team.name)}
          >
            <Text style={styles.deleteButtonText}>🗑️</Text>
          </TouchableOpacity>
        )}
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>🏀 Teams</Text>
        <TouchableOpacity
          style={styles.createButton}
          onPress={() => setModalVisible(true)}
        >
          <Text style={styles.createButtonText}>+ New Team</Text>
        </TouchableOpacity>
      </View>

      {/* Filter Tabs */}
      <Animated.View style={[styles.filterTabs, { opacity: opacityAnim }]}>
        <TouchableOpacity
          style={[styles.filterTab, filter === 'my' && styles.filterTabActive, filter === 'my' && styles.filterTabMy]}
          onPress={() => {
            setFilter('my');
            setTeams(myTeams);
          }}
        >
          <Text
            style={[
              styles.filterText,
              filter === 'my' && styles.filterTextActive
            ]}
          >
            My Teams ({myTeams.length})
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.filterTab, filter === 'all' && styles.filterTabActive, filter === 'all' && styles.filterTabAll]}
          onPress={() => {
            setFilter('all');
            setTeams(allTeams);
          }}
        >
          <Text
            style={[
              styles.filterText,
              filter === 'all' && styles.filterTextActive
            ]}
          >
            All Teams ({allTeams.length})
          </Text>
        </TouchableOpacity>
      </Animated.View>

      {/* Teams List */}
      {teams.length > 0 ? (
        <FlatList
          data={teams}
          renderItem={renderTeamCard}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        />
      ) : null}

      {/* Create Team Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Create Team</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.form}>
              <Text style={styles.label}>Team Name *</Text>
              <TextInput
                style={styles.input}
                placeholder="e.g., Lakers"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={teamName}
                onChangeText={setTeamName}
                editable={!creating}
              />

              <Text style={styles.label}>City</Text>
              <TextInput
                style={styles.input}
                placeholder="e.g., Los Angeles"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={teamCity}
                onChangeText={setTeamCity}
                editable={!creating}
              />

              <TouchableOpacity
                style={[styles.submitButton, creating && styles.buttonDisabled]}
                onPress={handleCreateTeam}
                disabled={creating}
              >
                {creating ? (
                  <ActivityIndicator color={COLORS.BG_LIGHT} />
                ) : (
                  <Text style={styles.submitButtonText}>Create Team</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BG_LIGHT
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.sm,
    backgroundColor: COLORS.BG_LIGHT,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  filterTabs: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.sm,
    gap: 6,
    backgroundColor: COLORS.BG_LIGHT,
    borderBottomWidth: 2,
    borderBottomColor: COLORS.SECONDARY
  },
  filterTab: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: COLORS.BG_SECONDARY,
    flex: 1,
    borderWidth: 2,
    borderColor: COLORS.BORDER
  },
  filterTabActive: {
    borderWidth: 2
  },
  filterTabMy: {
    backgroundColor: COLORS.SUCCESS,
    borderColor: COLORS.SUCCESS
  },
  filterTabAll: {
    backgroundColor: COLORS.SECONDARY,
    borderColor: COLORS.SECONDARY
  },
  filterText: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY,
    textAlign: 'center'
  },
  filterTextActive: {
    color: COLORS.BG_LIGHT,
    fontWeight: '700'
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.PRIMARY
  },
  createButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: 5
  },
  createButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 11
  },
  listContent: {
    padding: SPACING.sm
  },
  teamCard: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 10,
    marginBottom: 3,
    padding: SPACING.xs,
    borderWidth: 1,
    borderColor: COLORS.BORDER
  },
  teamCardMyTeams: {
    backgroundColor: '#E8F5E9',
    borderColor: COLORS.SUCCESS,
    borderWidth: 2,
    shadowColor: COLORS.SUCCESS,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5
  },
  teamCardAll: {
    backgroundColor: '#E3F2FD',
    borderColor: COLORS.SECONDARY,
    borderWidth: 2,
    shadowColor: COLORS.SECONDARY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5
  },
  teamCardOther: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderColor: COLORS.BORDER
  },
  teamCardHighlight: {
    backgroundColor: COLORS.SECONDARY_LIGHT
  },
  teamInfo: {
    flex: 1
  },
  teamNameText: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  teamCity: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 2
  },
  captainText: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.SECONDARY,
    marginBottom: 2,
    marginTop: 2
  },
  statsRow: {
    flexDirection: 'row',
    gap: 6,
    alignItems: 'center'
  },
  stat: {
    fontSize: 11,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '500'
  },
  playerCountText: {
    fontSize: 11,
    color: COLORS.PRIMARY,
    fontWeight: '500'
  },
  deleteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    padding: 6,
    backgroundColor: '#FFF5F5',
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center'
  },
  deleteButtonText: {
    fontSize: 16
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end'
  },
  modalContent: {
    backgroundColor: COLORS.BG_LIGHT,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    padding: SPACING.sm,
    paddingBottom: SPACING.md
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.PRIMARY
  },
  closeButton: {
    fontSize: 24,
    color: COLORS.TEXT_SECONDARY
  },
  form: {
    gap: SPACING.sm
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 6,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    fontSize: 13,
    color: COLORS.PRIMARY
  },
  submitButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingVertical: SPACING.sm,
    borderRadius: 6,
    alignItems: 'center',
    marginTop: SPACING.sm
  },
  buttonDisabled: {
    opacity: 0.6
  },
  submitButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 14
  }
});

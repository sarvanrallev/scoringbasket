import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  RefreshControl,
  Modal,
  TextInput,
  FlatList
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { teamsAPI, authAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function TeamDetailsScreen() {
  const navigation = useNavigation();
  const router = useRouter();
  const { teamId } = useLocalSearchParams();
  const teamIdNum = parseInt(teamId, 10);

  const [team, setTeam] = useState(null);
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [currentUserRole, setCurrentUserRole] = useState('member');

  // Modals
  const [inviteModalVisible, setInviteModalVisible] = useState(false);
  const [roleModalVisible, setRoleModalVisible] = useState(false);
  const [selectedMember, setSelectedMember] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const [inviting, setInviting] = useState(false);

  useEffect(() => {
    loadTeamData();
  }, [teamIdNum]);

  const loadTeamData = async () => {
    setLoading(true);
    try {
      const [teamData, membersData] = await Promise.all([
        teamsAPI.getTeam(teamIdNum),
        teamsAPI.getTeamMembers(teamIdNum)
      ]);

      setTeam(teamData);
      setMembers(membersData);

      // Determine current user's role
      const currentUser = await authAPI.getProfile();
      const userMember = membersData.find(m => m.user_id === currentUser.id);
      setCurrentUserRole(userMember?.is_admin ? 'admin' : 'member');

    } catch (error) {
      console.error('Error loading team data:', error);
      if (error.response?.status === 401) {
        Alert.alert('Session Expired', 'Please log in again', [
          { text: 'OK', onPress: () => router.replace('/login') }
        ]);
      } else {
        Alert.alert('Error', 'Failed to load team details');
      }
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTeamData();
    setRefreshing(false);
  };

  const handleSearchUsers = async (query) => {
    if (query.length < 1) {
      setSearchResults([]);
      return;
    }

    setSearching(true);
    try {
      const results = await authAPI.searchUsers(query, teamIdNum);
      setSearchResults(results);
    } catch (error) {
      console.error('Search error:', error);
      Alert.alert('Error', 'Failed to search users');
    } finally {
      setSearching(false);
    }
  };

  const handleInviteMember = async (user) => {
    setInviting(true);
    try {
      if (currentUserRole === 'admin') {
        // Admin can add directly
        await teamsAPI.addMember(teamIdNum, user.id, 'member');
        setInviteModalVisible(false);
        setSearchQuery('');
        setSearchResults([]);
        Alert.alert('Success', `${user.first_name} ${user.last_name} has been added to the team`);

        // Refresh members list
        const membersData = await teamsAPI.getTeamMembers(teamIdNum);
        setMembers(membersData);
      } else {
        // Non-admin sends invite
        await teamsAPI.inviteMember(teamIdNum, user.phone);
        setInviteModalVisible(false);
        setSearchQuery('');
        setSearchResults([]);
        Alert.alert('Success', `Invitation sent to ${user.first_name} ${user.last_name}`);

        // Refresh members list
        const membersData = await teamsAPI.getTeamMembers(teamIdNum);
        setMembers(membersData);
      }
    } catch (error) {
      Alert.alert('Error', error.response?.data?.detail || 'Failed to add/invite member');
    } finally {
      setInviting(false);
    }
  };

  const handleUpdateMemberRole = async (memberId, roleData) => {
    try {
      await teamsAPI.updateMemberRole(teamIdNum, memberId, roleData);
      Alert.alert('Success', 'Member roles updated');

      // Refresh members list
      const membersData = await teamsAPI.getTeamMembers(teamIdNum);
      setMembers(membersData);
    } catch (error) {
      Alert.alert('Error', 'Failed to update member roles');
    }
  };

  const handleRemoveMember = async (memberId, memberName) => {
    Alert.alert('Remove Member', `Are you sure you want to remove ${memberName}?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: async () => {
          try {
            await teamsAPI.removeMember(teamIdNum, memberId);
            Alert.alert('Success', 'Member removed');

            // Refresh members list
            const membersData = await teamsAPI.getTeamMembers(teamIdNum);
            setMembers(membersData);
          } catch (error) {
            Alert.alert('Error', 'Failed to remove member');
          }
        }
      }
    ]);
  };

  const renderMemberCard = ({ item: member }) => (
    <View style={styles.memberCard}>
      <TouchableOpacity 
        style={styles.memberInfo}
        onPress={() => member.user_id && router.push(`/player-profile?userId=${member.user_id}`)}
      >
        <Text style={styles.memberName}>
          {member.first_name} {member.last_name}
        </Text>
        <Text style={styles.memberUsername}>@{member.username}</Text>
        <View style={styles.roleContainer}>
          {member.is_admin && (
            <Text style={[styles.roleBadge, styles.adminBadge]}>👑 Admin</Text>
          )}
          {member.is_captain && (
            <Text style={[styles.roleBadge, styles.captainBadge]}>⭐ Captain</Text>
          )}
          {member.is_vice_captain && (
            <Text style={[styles.roleBadge, styles.viceCaptainBadge]}>⚡ Vice Captain</Text>
          )}
          {!member.is_admin && !member.is_captain && !member.is_vice_captain && (
            <Text style={[styles.roleBadge, styles.memberBadge]}>👤 Member</Text>
          )}
        </View>
      </TouchableOpacity>

      {currentUserRole === 'admin' && (
        <View style={styles.memberActions}>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => {
              setSelectedMember(member);
              setRoleModalVisible(true);
            }}
          >
            <Text style={styles.actionIcon}>⚙️</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionButton, styles.removeButton]}
            onPress={() => handleRemoveMember(member.id, `${member.first_name} ${member.last_name}`)}
          >
            <Text style={styles.removeIcon}>❌</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );

  const renderSearchResult = ({ item: user }) => (
    <TouchableOpacity
      style={styles.searchResultCard}
      onPress={() => handleInviteMember(user)}
      disabled={inviting}
    >
      <View style={styles.searchResultInfo}>
        <Text style={styles.searchResultName}>
          {user.first_name} {user.last_name}
        </Text>
        <Text style={styles.searchResultUsername}>@{user.username}</Text>
        <Text style={styles.searchResultPhone}>{user.phone}</Text>
      </View>
      <TouchableOpacity
        style={styles.inviteButton}
        onPress={() => handleInviteMember(user)}
        disabled={inviting}
      >
        <Text style={styles.inviteButtonText}>
          {inviting ? (currentUserRole === 'admin' ? 'Adding...' : 'Inviting...') : (currentUserRole === 'admin' ? 'Add' : 'Invite')}
        </Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  if (!team) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>Team not found</Text>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Text style={styles.backIcon}>←</Text>
          </TouchableOpacity>
          <Text style={styles.title}>👥 {team.name}</Text>
          {currentUserRole === 'admin' && (
            <TouchableOpacity
              style={styles.inviteButton}
              onPress={() => setInviteModalVisible(true)}
            >
              <Text style={styles.inviteButtonText}>+ {currentUserRole === 'admin' ? 'Add' : 'Invite'}</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Team Info */}
        <View style={[styles.teamInfoCard, { backgroundColor: '#F0F9FF', borderLeftWidth: 4, borderLeftColor: '#4F46E5' }]}>
          <Text style={styles.sectionTitle}>ℹ️ Team Information</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>City:</Text>
            <Text style={styles.infoValue}>{team.city || 'Not specified'}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Description:</Text>
            <Text style={styles.infoValue}>{team.description || 'No description'}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Created:</Text>
            <Text style={styles.infoValue}>
              {new Date(team.created_at).toLocaleDateString()}
            </Text>
          </View>
        </View>

        {/* Team Stats */}
        <View style={[styles.statsCard, { backgroundColor: '#E8F5E9', borderLeftWidth: 4, borderLeftColor: '#10B981' }]}>
          <Text style={styles.sectionTitle}>📊 Game Statistics</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>{team.wins || 0}</Text>
              <Text style={styles.statLabel}>Wins</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>{team.losses || 0}</Text>
              <Text style={styles.statLabel}>Losses</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>{(team.wins || 0) + (team.losses || 0)}</Text>
              <Text style={styles.statLabel}>Total</Text>
            </View>
          </View>
        </View>

        {/* Team Members */}
        <View style={[styles.membersCard, { backgroundColor: '#F3E5F5', borderLeftWidth: 4, borderLeftColor: '#8B5CF6' }]}>
          <Text style={styles.sectionTitle}>👤 Team Members ({members.length})</Text>
          <FlatList
            data={members}
            renderItem={renderMemberCard}
            keyExtractor={(item) => item.id.toString()}
            scrollEnabled={false}
            contentContainerStyle={styles.membersList}
          />
        </View>
      </ScrollView>

      {/* Invite Member Modal */}
      <Modal
        visible={inviteModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setInviteModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              {currentUserRole === 'admin' ? 'Add Team Member' : 'Invite Team Member'}
            </Text>

            <TextInput
              style={styles.searchInput}
              placeholder="Search by name or phone..."
              value={searchQuery}
              onChangeText={(text) => {
                setSearchQuery(text);
                handleSearchUsers(text);
              }}
            />

            {searching && (
              <View style={styles.searchingContainer}>
                <ActivityIndicator size="small" color={COLORS.SECONDARY} />
                <Text style={styles.searchingText}>Searching...</Text>
              </View>
            )}

            <FlatList
              data={searchResults}
              renderItem={renderSearchResult}
              keyExtractor={(item) => item.id.toString()}
              style={styles.searchResultsList}
              ListEmptyComponent={
                searchQuery.length >= 2 && !searching ? (
                  <Text style={styles.noResultsText}>No users found</Text>
                ) : null
              }
            />

            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => {
                setInviteModalVisible(false);
                setSearchQuery('');
                setSearchResults([]);
              }}
            >
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Role Selection Modal */}
      <Modal
        visible={roleModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setRoleModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Manage Member Roles</Text>
            {selectedMember && (
              <View style={styles.selectedMemberInfo}>
                <Text style={styles.selectedMemberName}>
                  {selectedMember.first_name} {selectedMember.last_name}
                </Text>
                <Text style={styles.selectedMemberUsername}>@{selectedMember.username}</Text>
                <Text style={styles.currentRoleText}>
                  Current Roles: {[
                    selectedMember.is_admin && 'Admin',
                    selectedMember.is_captain && 'Captain', 
                    selectedMember.is_vice_captain && 'Vice Captain'
                  ].filter(Boolean).join(', ') || 'Member'}
                </Text>
              </View>
            )}

            <View style={styles.roleOptions}>
              {[
                { key: 'is_admin', label: '👑 Admin', desc: 'Full team management access' },
                { key: 'is_captain', label: '⭐ Captain', desc: 'Team leadership role' },
                { key: 'is_vice_captain', label: '⚡ Vice Captain', desc: 'Assistant leadership role' }
              ].map((roleOption) => (
                <View key={roleOption.key} style={styles.roleToggleContainer}>
                  <View style={styles.roleToggleInfo}>
                    <Text style={styles.roleOptionLabel}>{roleOption.label}</Text>
                    <Text style={styles.roleOptionDesc}>{roleOption.desc}</Text>
                  </View>
                  <TouchableOpacity
                    style={[
                      styles.roleToggle,
                      selectedMember && selectedMember[roleOption.key] && styles.roleToggleActive
                    ]}
                    onPress={() => {
                      if (selectedMember) {
                        const updatedMember = {
                          ...selectedMember,
                          [roleOption.key]: !selectedMember[roleOption.key]
                        };
                        setSelectedMember(updatedMember);
                      }
                    }}
                  >
                    <Text style={[
                      styles.roleToggleText,
                      selectedMember && selectedMember[roleOption.key] && styles.roleToggleTextActive
                    ]}>
                      {selectedMember && selectedMember[roleOption.key] ? 'ON' : 'OFF'}
                    </Text>
                  </TouchableOpacity>
                </View>
              ))}
            </View>

            <TouchableOpacity
              style={styles.saveButton}
              onPress={() => {
                if (selectedMember) {
                  handleUpdateMemberRole(selectedMember.id, {
                    is_admin: selectedMember.is_admin,
                    is_captain: selectedMember.is_captain,
                    is_vice_captain: selectedMember.is_vice_captain
                  });
                  setRoleModalVisible(false);
                  setSelectedMember(null);
                }
              }}
            >
              <Text style={styles.saveButtonText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BG_LIGHT,
  },
  scrollContent: {
    padding: SPACING.sm,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: SPACING.sm,
    paddingVertical: SPACING.xs,
  },
  backButton: {
    padding: SPACING.sm,
  },
  backIcon: {
    fontSize: 24,
    color: COLORS.PRIMARY,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
    flex: 1,
    textAlign: 'center',
  },
  inviteButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: 8,
  },
  inviteButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: 'bold',
  },
  teamInfoCard: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 12,
    padding: SPACING.sm,
    marginBottom: SPACING.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
    marginBottom: SPACING.md,
  },
  infoRow: {
    flexDirection: 'row',
    marginBottom: SPACING.sm,
  },
  infoLabel: {
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
    width: 80,
  },
  infoValue: {
    color: COLORS.TEXT_SECONDARY,
    flex: 1,
  },
  statsCard: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 12,
    padding: SPACING.sm,
    marginBottom: SPACING.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.SECONDARY,
  },
  statLabel: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginTop: SPACING.sm,
  },
  membersCard: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 12,
    padding: SPACING.sm,
    marginBottom: SPACING.sm,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  membersList: {
    paddingVertical: SPACING.sm,
  },
  memberCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER,
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
  },
  memberUsername: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 2,
  },
  roleContainer: {
    marginTop: SPACING.sm,
  },
  roleBadge: {
    fontSize: 12,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 2,
    borderRadius: 12,
    alignSelf: 'flex-start',
    backgroundColor: COLORS.BORDER,
    color: COLORS.TEXT_SECONDARY,
  },
  adminBadge: {
    backgroundColor: '#FFD700',
    color: '#000',
  },
  captainBadge: {
    backgroundColor: '#FF6B35',
    color: COLORS.BG_LIGHT,
  },
  viceCaptainBadge: {
    backgroundColor: '#4ECDC4',
    color: COLORS.BG_LIGHT,
  },
  memberActions: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  actionButton: {
    padding: SPACING.sm,
    borderRadius: 6,
    backgroundColor: COLORS.BORDER,
  },
  actionIcon: {
    fontSize: 16,
  },
  removeButton: {
    backgroundColor: '#FF6B6B',
  },
  removeIcon: {
    color: COLORS.BG_LIGHT,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 12,
    padding: SPACING.lg,
    width: '90%',
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
    marginBottom: SPACING.md,
    textAlign: 'center',
  },
  searchInput: {
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 8,
    padding: SPACING.md,
    fontSize: 16,
    marginBottom: SPACING.md,
  },
  searchingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.md,
  },
  searchingText: {
    marginLeft: SPACING.sm,
    color: COLORS.TEXT_SECONDARY,
  },
  searchResultsList: {
    maxHeight: 300,
    marginBottom: SPACING.md,
  },
  searchResultCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER,
  },
  searchResultInfo: {
    flex: 1,
  },
  searchResultName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
  },
  searchResultUsername: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 2,
  },
  searchResultPhone: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 2,
  },
  noResultsText: {
    textAlign: 'center',
    color: COLORS.TEXT_SECONDARY,
    padding: SPACING.md,
  },
  closeButton: {
    backgroundColor: COLORS.BORDER,
    padding: SPACING.md,
    borderRadius: 8,
    alignItems: 'center',
  },
  closeButtonText: {
    fontSize: 16,
    color: COLORS.TEXT_PRIMARY,
  },
  selectedMemberInfo: {
    backgroundColor: COLORS.BG_LIGHT,
    padding: SPACING.md,
    borderRadius: 8,
    marginBottom: SPACING.lg,
  },
  selectedMemberName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
  },
  selectedMemberUsername: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 2,
  },
  currentRoleText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 4,
    fontStyle: 'italic',
  },
  roleOptions: {
    marginBottom: SPACING.lg,
  },
  roleOption: {
    backgroundColor: COLORS.BG_LIGHT,
    padding: SPACING.md,
    borderRadius: 8,
    marginBottom: SPACING.sm,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
  },
  selectedRoleOption: {
    borderColor: COLORS.PRIMARY,
    backgroundColor: COLORS.PRIMARY + '10', // Light primary background
  },
  roleOptionLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT_PRIMARY,
  },
  roleOptionDesc: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginTop: 2,
  },
  roleToggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER,
  },
  roleToggleInfo: {
    flex: 1,
  },
  roleToggle: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    backgroundColor: COLORS.BG_LIGHT,
  },
  roleToggleActive: {
    backgroundColor: COLORS.PRIMARY,
    borderColor: COLORS.PRIMARY,
  },
  roleToggleText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.TEXT_SECONDARY,
  },
  roleToggleTextActive: {
    color: COLORS.BG_LIGHT,
  },
  saveButton: {
    backgroundColor: COLORS.PRIMARY,
    padding: SPACING.md,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: SPACING.md,
  },
  saveButtonText: {
    color: COLORS.BG_LIGHT,
    fontSize: 16,
    fontWeight: 'bold',
  },
  memberBadge: {
    backgroundColor: COLORS.BG_LIGHT,
    color: COLORS.TEXT_SECONDARY,
  },
  errorText: {
    fontSize: 18,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: SPACING.lg,
  },
  backButtonText: {
    color: COLORS.PRIMARY,
    fontSize: 16,
  },
});
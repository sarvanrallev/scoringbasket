import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  FlatList
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useFocusEffect } from '@react-navigation/native';
import { authAPI, gamesAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';
import { useNavigation } from '@react-navigation/native';

export default function PlayerProfileScreen() {
  const router = useRouter();
  const navigation = useNavigation();
  const { userId } = useLocalSearchParams();
  const userIdNum = userId ? parseInt(userId, 10) : null;
  
  const [player, setPlayer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);
  const [gameHistory, setGameHistory] = useState([]);
  const [showAllGames, setShowAllGames] = useState(false);

  useEffect(() => {
    if (userIdNum) {
      loadPlayerData();
    } else {
      Alert.alert('Error', 'Invalid player ID');
      router.back();
    }
  }, [userIdNum]);

  useFocusEffect(
    React.useCallback(() => {
      if (userIdNum) {
        loadPlayerData();
      }
    }, [userIdNum])
  );

  const loadPlayerData = async () => {
    setLoading(true);
    try {
      const [playerData, statsData, gameStatsData] = await Promise.all([
        authAPI.getUserById(userIdNum),
        gamesAPI.getPlayerStats(userIdNum),
        gamesAPI.getPlayerGameStats(userIdNum)
      ]);

      setPlayer(playerData);
      setStats(statsData);
      setGameHistory(gameStatsData || []);
    } catch (error) {
      console.error('Error loading player data:', error);
      console.error('Error details:', {
        message: error.message,
        status: error.response?.status,
        data: error.response?.data,
        url: error.config?.url,
        method: error.config?.method
      });
      
      const errorMessage = error.response?.data?.detail || error.message || 'Failed to load player profile';
      Alert.alert('Error', errorMessage);
      router.back();
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={COLORS.SECONDARY} />
        </View>
      </SafeAreaView>
    );
  }

  if (!player) {
    return (
      <SafeAreaView style={styles.container}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButtonTop}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <View style={styles.centerContainer}>
          <Text style={styles.errorText}>Player not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  const renderInfoTab = () => (
    <ScrollView style={styles.scrollContent} showsVerticalScrollIndicator={false}>
      {/* Player Header */}
      <View style={styles.profileHeader}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {player.first_name?.charAt(0)}{player.last_name?.charAt(0)}
          </Text>
        </View>
        <Text style={styles.username}>
          {player.first_name} {player.last_name}
        </Text>
        <Text style={styles.email}>@{player.username}</Text>
      </View>

      {/* Player Details */}
      <View style={styles.detailsSection}>
        {player.profile?.preferred_position && (
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Position</Text>
            <Text style={styles.detailValue}>{player.profile.preferred_position}</Text>
          </View>
        )}
        
        {player.profile?.jersey_number && (
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Jersey Number</Text>
            <Text style={styles.detailValue}>#{player.profile.jersey_number}</Text>
          </View>
        )}

        {player.profile?.height_cm && (
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Height</Text>
            <Text style={styles.detailValue}>{player.profile.height_cm} cm</Text>
          </View>
        )}

        {player.profile?.hand_style && (
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Shooting Hand</Text>
            <Text style={styles.detailValue}>
              {player.profile.hand_style === 'right_hand' ? 'Right' : 'Left'}
            </Text>
          </View>
        )}

        {player.profile?.date_of_birth && (
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Date of Birth</Text>
            <Text style={styles.detailValue}>
              {new Date(player.profile.date_of_birth).toLocaleDateString()}
            </Text>
          </View>
        )}

        {(player.profile?.city || player.profile?.country) && (
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Location</Text>
            <Text style={styles.detailValue}>
              {player.profile.city && `${player.profile.city}`}
              {player.profile.city && player.profile.country && ', '}
              {player.profile.country && `${player.profile.country}`}
            </Text>
          </View>
        )}

        {player.profile?.favorite_player && (
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>Favorite Player</Text>
            <Text style={styles.detailValue}>{player.profile.favorite_player}</Text>
          </View>
        )}
      </View>

      {/* Bio Section */}
      {player.profile?.bio && (
        <View style={styles.bioSection}>
          <Text style={styles.bioLabel}>Bio</Text>
          <Text style={styles.bioText}>{player.profile.bio}</Text>
        </View>
      )}

      {/* Overall Stats */}
      {stats && (
        <TouchableOpacity
          style={styles.statsSection}
          onPress={() => setShowAllGames(!showAllGames)}
          activeOpacity={0.7}
        >
          <View style={styles.statsSectionHeader}>
            <Text style={styles.statsTitle}>Overall Stats</Text>
            <Text style={styles.viewAllText}>{showAllGames ? '▼ View Recent' : '▶ View All Games'}</Text>
          </View>
          <View style={styles.statsCards}>
            <View style={styles.statCard}>
              <Text style={styles.statCardLabel}>Games</Text>
              <Text style={styles.statCardValue}>{stats.total_games || 0}</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statCardLabel}>Points</Text>
              <Text style={styles.statCardValue}>{stats.total_points || 0}</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statCardLabel}>Avg Pts</Text>
              <Text style={styles.statCardValue}>{stats.avg_points?.toFixed(1) || '0.0'}</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statCardLabel}>Rebounds</Text>
              <Text style={styles.statCardValue}>{stats.total_rebounds || 0}</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statCardLabel}>Assists</Text>
              <Text style={styles.statCardValue}>{stats.total_assists || 0}</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statCardLabel}>Steals</Text>
              <Text style={styles.statCardValue}>{stats.total_steals || 0}</Text>
            </View>
          </View>
        </TouchableOpacity>
      )}
    </ScrollView>
  );

  const renderGameHistoryTab = (showAll = false) => {
    const gamesToShow = showAll ? gameHistory : gameHistory.slice(0, 2);
    
    return (
    <View style={styles.gameHistoryScroll}>
      {gamesToShow && gamesToShow.length > 0 ? (
        <ScrollView
          style={styles.gameHistoryContainer}
          scrollEnabled={true}
          showsVerticalScrollIndicator={true}
        >
          {gamesToShow.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.gameCardContainer}
              onPress={() => item.game_id && router.push(`/match-detail?gameId=${item.game_id}`)}
              activeOpacity={0.7}
            >
              <View style={styles.gameCardHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.gameDate}>
                    {item.game_date ? new Date(item.game_date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : 'N/A'}
                  </Text>
                  <Text style={styles.gameTime}>
                    {item.game_date ? new Date(item.game_date).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : ''}
                  </Text>
                  <Text style={styles.gameTeam}>{item.team_name || 'Team'}</Text>
                </View>
              </View>
              <View style={styles.gameCardStatsRow}>
                <View style={styles.gameStatCol}>
                  <Text style={styles.gameStatLabel}>Pts</Text>
                  <Text style={styles.gameStatValue}>{item.points || 0}</Text>
                </View>
                <View style={styles.gameStatCol}>
                  <Text style={styles.gameStatLabel}>Reb</Text>
                  <Text style={styles.gameStatValue}>{item.rebounds || 0}</Text>
                </View>
                <View style={styles.gameStatCol}>
                  <Text style={styles.gameStatLabel}>Ast</Text>
                  <Text style={styles.gameStatValue}>{item.assists || 0}</Text>
                </View>
                <View style={styles.gameStatCol}>
                  <Text style={styles.gameStatLabel}>Stl</Text>
                  <Text style={styles.gameStatValue}>{item.steals || 0}</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
      ) : (
        <View style={styles.noStatsContainer}>
          <Text style={styles.noStatsText}>No game history available</Text>
        </View>
      )}
    </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButtonTop}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{player.first_name} {player.last_name}</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Main Content */}
      <ScrollView style={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {renderInfoTab()}
      </ScrollView>

      {gameHistory && gameHistory.length > 0 && (
        <View style={styles.gamesSection}>
          <Text style={styles.gamesSectionTitle}>
            {showAllGames ? 'All Games' : 'Recent Games'}
          </Text>
          {renderGameHistoryTab(showAllGames)}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    flex: 1,
    textAlign: 'center'
  },
  backButtonTop: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.xs
  },
  backButtonText: {
    fontSize: 16,
    color: COLORS.SECONDARY,
    fontWeight: '600'
  },
  scrollContent: {
    paddingBottom: SPACING.lg
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: SPACING.xl,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.SECONDARY,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: SPACING.md
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.BG_LIGHT
  },
  username: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.PRIMARY,
    marginBottom: SPACING.xs
  },
  email: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY
  },
  detailsSection: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  detailLabel: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    flex: 1
  },
  detailValue: {
    fontSize: 14,
    color: COLORS.PRIMARY,
    fontWeight: '500',
    flex: 2,
    textAlign: 'right'
  },
  bioSection: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  bioLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: SPACING.md
  },
  bioText: {
    fontSize: 14,
    color: COLORS.TEXT_PRIMARY,
    lineHeight: 20
  },
  statsSection: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  statsSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6
  },
  statsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.PRIMARY
  },
  viewAllText: {
    fontSize: 11,
    fontWeight: '500',
    color: COLORS.SECONDARY
  },
  statsCards: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around'
  },
  statCard: {
    width: '30%',
    alignItems: 'center',
    paddingHorizontal: 4,
    paddingVertical: 4,
    marginBottom: 4,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 6,
    backgroundColor: COLORS.BG_SECONDARY
  },
  statCardLabel: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 2,
    fontWeight: '500'
  },
  statCardValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.SECONDARY
  },
  gamesSection: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderTopWidth: 1,
    borderTopColor: COLORS.BORDER,
    maxHeight: 350
  },
  gameHistoryScroll: {
    height: 350,
    flexDirection: 'column'
  },
  gameHistoryContainer: {
    flex: 1
  },
  gamesSectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: 6
  },
  gameCardContainer: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 6,
    padding: SPACING.sm,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: COLORS.BORDER
  },
  gameCardHeader: {
    paddingBottom: 6,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER,
    marginBottom: 6
  },
  gameDate: {
    fontSize: 9,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 2
  },
  gameTime: {
    fontSize: 10,
    fontWeight: '500',
    color: COLORS.SECONDARY,
    marginBottom: 2
  },
  gameTeam: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.PRIMARY
  },
  gameCardStatsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around'
  },
  gameStatCol: {
    alignItems: 'center'
  },
  gameStatLabel: {
    fontSize: 9,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: 2,
    fontWeight: '500'
  },
  gameStatValue: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.SECONDARY
  },
  noStatsContainer: {
    paddingVertical: SPACING.lg,
    alignItems: 'center',
    paddingHorizontal: SPACING.md
  },
  noStatsText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    fontStyle: 'italic'
  },
  errorText: {
    fontSize: 16,
    color: COLORS.TEXT_PRIMARY,
    fontStyle: 'italic'
  }
});

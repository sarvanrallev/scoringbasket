import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  Modal,
  TextInput,
  RefreshControl
} from 'react-native';
import { useRouter, useFocusEffect, useLocalSearchParams } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI, gamesAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function ProfileScreen() {
  const router = useRouter();
  const { userId } = useLocalSearchParams();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [passwordModalVisible, setPasswordModalVisible] = useState(false);
  const [deactivateModalVisible, setDeactivateModalVisible] = useState(false);
  const [favoritePlayers, setFavoritePlayers] = useState([]);
  const [handStyles, setHandStyles] = useState([]);
  const [positionOptions, setPositionOptions] = useState([
    'Point Guard',
    'Shooting Guard',
    'Small Forward',
    'Power Forward',
    'Center'
  ]);
  
  // Password change state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);
  
  // Profile form state
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [bio, setBio] = useState('');
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [preferredPosition, setPreferredPosition] = useState('');
  const [jerseyNumber, setJerseyNumber] = useState('');
  const [handStyle, setHandStyle] = useState('');
  const [favoritePlayer, setFavoritePlayer] = useState('');
  const [heightCm, setHeightCm] = useState('');
  const [updating, setUpdating] = useState(false);
  
  // Player stats state
  const [playerStats, setPlayerStats] = useState(null);
  const [gameStats, setGameStats] = useState([]);
  const [statsLoading, setStatsLoading] = useState(false);
  
  // Refresh state
  const [refreshing, setRefreshing] = useState(false);

  // Determine if viewing own profile or someone else's
  const isOwnProfile = !userId;

  useEffect(() => {
    // Reset user state when userId changes
    setUser(null);
    setPlayerStats(null);
    setGameStats([]);
    loadProfile();
    loadOptions();
  }, [userId]);

  // Reload stats when screen comes into focus
  useFocusEffect(
    React.useCallback(() => {
      if (user?.id) {
        loadPlayerStats(user.id);
      }
    }, [user?.id])
  );

  const loadProfile = async () => {
    setLoading(true);
    try {
      const response = userId 
        ? await authAPI.getUserById(userId)
        : await authAPI.getProfile();
      
      console.log('=== Profile Data Loaded ===');
      console.log('User ID:', response.id);
      console.log('User Name:', response.first_name, response.last_name);
      console.log('Profile Object:', response.profile);
      console.log('Profile Fields:', {
        bio: response.profile?.bio,
        city: response.profile?.city,
        country: response.profile?.country,
        date_of_birth: response.profile?.date_of_birth,
        preferred_position: response.profile?.preferred_position,
        jersey_number: response.profile?.jersey_number,
        hand_style: response.profile?.hand_style,
        favorite_player: response.profile?.favorite_player,
        height_cm: response.profile?.height_cm
      });
      console.log('============================');
      
      setUser(response);
      
      // Initialize form fields (only for own profile)
      if (!userId) {
        setFirstName(response.first_name || '');
        setLastName(response.last_name || '');
        setBio(response.profile?.bio || '');
        setCity(response.profile?.city || '');
        setCountry(response.profile?.country || '');
        setDateOfBirth(response.profile?.date_of_birth ? response.profile.date_of_birth.split('T')[0] : '');
        setPreferredPosition(response.profile?.preferred_position || '');
        setJerseyNumber(response.profile?.jersey_number ? response.profile.jersey_number.toString() : '');
        setHandStyle(response.profile?.hand_style || '');
        setFavoritePlayer(response.profile?.favorite_player || '');
        setHeightCm(response.profile?.height_cm ? response.profile.height_cm.toString() : '');
      }
    } catch (error) {
      console.error('Profile load error:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const loadPlayerStats = async (userId) => {
    setStatsLoading(true);
    try {
      const [stats, games] = await Promise.all([
        gamesAPI.getPlayerStats(userId),
        gamesAPI.getPlayerGameStats(userId)
      ]);
      setPlayerStats(stats);
      setGameStats(games || []);
    } catch (error) {
      // Silently fail - stats may not exist yet
      console.log('Failed to load player stats:', error);
    } finally {
      setStatsLoading(false);
    }
  };

  const loadOptions = async () => {
    try {
      const [playersRes, stylesRes] = await Promise.all([
        authAPI.getFavoritePlayers(),
        authAPI.getHandStyles()
      ]);
      setFavoritePlayers(playersRes.favorite_players || []);
      setHandStyles(stylesRes.hand_styles || []);
    } catch (error) {
      console.log('Failed to load options:', error);
    }
  };

  const onRefresh = async () => {
    console.log('Refreshing profile screen...');
    setRefreshing(true);
    try {
      // Load profile and stats in parallel
      await Promise.all([
        loadProfile(),
        user?.id && loadPlayerStats(user.id)
      ]);
      console.log('Profile refresh completed');
    } catch (error) {
      console.error('Refresh error:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const calculateAge = (dateOfBirth) => {
    if (!dateOfBirth) return null;
    
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  };

  const handleUpdateProfile = async () => {
    if (!firstName.trim() || !lastName.trim()) {
      Alert.alert('Error', 'First name and last name are required');
      return;
    }

    // Validate jersey number
    if (jerseyNumber) {
      const jerseyNum = parseInt(jerseyNumber);
      if (isNaN(jerseyNum) || jerseyNum < 0 || jerseyNum > 99) {
        Alert.alert('Error', 'Jersey number must be between 0 and 99');
        return;
      }
    }

    // Validate height
    if (heightCm) {
      const height = parseInt(heightCm);
      if (isNaN(height) || height <= 0) {
        Alert.alert('Error', 'Height must be a positive number (in cm)');
        return;
      }
    }

    // Validate hand style
    if (handStyle && !['right_hand', 'left_hand'].includes(handStyle)) {
      Alert.alert('Error', 'Hand style must be either right or left');
      return;
    }

    // Validate date of birth format
    if (dateOfBirth) {
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
      if (!dateRegex.test(dateOfBirth)) {
        Alert.alert('Error', 'Date of birth must be in YYYY-MM-DD format');
        return;
      }
    }

    setUpdating(true);
    try {
      // Convert hand_style to lowercase format (right_hand or left_hand)
      let hand_style_value = null;
      if (handStyle && handStyle.trim()) {
        hand_style_value = handStyle.trim().toLowerCase().replace(/\s+/g, '_');
      }

      const profileData = {
        first_name: firstName.trim() || null,
        last_name: lastName.trim() || null,
        bio: bio && bio.trim() ? bio.trim() : null,
        city: city && city.trim() ? city.trim() : null,
        country: country && country.trim() ? country.trim() : null,
        date_of_birth: dateOfBirth ? `${dateOfBirth}T00:00:00` : null,
        preferred_position: preferredPosition && preferredPosition.trim() ? preferredPosition.trim() : null,
        jersey_number: jerseyNumber ? parseInt(jerseyNumber) : null,
        hand_style: hand_style_value,
        favorite_player: favoritePlayer && favoritePlayer.trim() ? favoritePlayer.trim() : null,
        height_cm: heightCm ? parseInt(heightCm) : null
      };

      console.log('=== Sending Profile Update ===');
      console.log('Profile Data:', profileData);
      console.log('=============================');

      const response = await authAPI.updateProfile(profileData);
      
      console.log('Update Response:', response);
      
      // Update local user data
      const updatedUser = { ...user, ...response };
      setUser(updatedUser);
      await AsyncStorage.setItem('user_data', JSON.stringify(updatedUser));
      
      // Reload profile to ensure fresh data from backend
      console.log('Reloading profile after update...');
      await loadProfile();
      
      setEditModalVisible(false);
      Alert.alert('Success', 'Profile updated successfully');
    } catch (error) {
      console.error('Profile update error:', error);
      const errorMessage = error.response?.data?.detail || error.message || 'Failed to update profile';
      console.error('Backend error detail:', errorMessage);
      Alert.alert('Error', errorMessage);
    } finally {
      setUpdating(false);
    }
  };

  const handlePasswordChange = async () => {
    if (!oldPassword || !newPassword || !confirmNewPassword) {
      Alert.alert('Error', 'All password fields are required');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      Alert.alert('Error', 'New passwords do not match');
      return;
    }

    if (newPassword.length < 8) {
      Alert.alert('Error', 'New password must be at least 8 characters long');
      return;
    }

    setChangingPassword(true);
    try {
      await authAPI.changePassword({
        old_password: oldPassword,
        new_password: newPassword
      });
      
      setPasswordModalVisible(false);
      setOldPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      Alert.alert('Success', 'Password changed successfully');
    } catch (error) {
      Alert.alert('Error', error.message || 'Failed to change password');
    } finally {
      setChangingPassword(false);
    }
  };

  const handleDeactivateAccount = () => {
    Alert.alert(
      'Deactivate Account',
      'Are you sure you want to deactivate your account? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Deactivate',
          style: 'destructive',
          onPress: async () => {
            try {
              await authAPI.deactivateAccount();
              await AsyncStorage.removeItem('access_token');
              await AsyncStorage.removeItem('user_data');
              navigation.replace('Login');
            } catch (error) {
              Alert.alert('Error', error.message || 'Failed to deactivate account');
            }
          }
        }
      ]
    );
  };

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          try {
            await authAPI.logout();
          } catch (error) {
            // Logout anyway
          }
          await AsyncStorage.removeItem('auth_token');
          await AsyncStorage.removeItem('user_data');
          router.replace('/login');
        }
      }
    ]);
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[COLORS.SECONDARY]}
            tintColor={COLORS.SECONDARY}
          />
        }
      >
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user?.first_name?.charAt(0).toUpperCase() || user?.username?.charAt(0).toUpperCase() || '?'}
            </Text>
          </View>
          <Text style={styles.username}>{user?.first_name} {user?.last_name}</Text>
          {!isOwnProfile && <Text style={styles.username}>@{user?.username}</Text>}
          {isOwnProfile && <Text style={styles.email}>{user?.email}</Text>}
          {user?.profile?.bio && (
            <Text style={styles.bio}>{user.profile.bio}</Text>
          )}
        </View>

        {/* Profile Details */}
        <View style={styles.detailsSection}>
          {/* Always show joined date */}
          {user?.created_at && (
            <View style={styles.detailItem}>
              <Text style={styles.detailLabel}>📅 Joined</Text>
              <Text style={styles.detailValue}>
                {new Date(user.created_at).toLocaleDateString()}
              </Text>
            </View>
          )}
          
          {/* Show age if available */}
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>🎂 Age</Text>
            <Text style={styles.detailValue}>
              {user?.profile?.date_of_birth 
                ? `${calculateAge(user.profile.date_of_birth)} years` 
                : 'Not provided'}
            </Text>
          </View>
          
          {/* Show location - always visible */}
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>📍 Location</Text>
            <Text style={styles.detailValue}>
              {user?.profile?.city || user?.profile?.country 
                ? [user?.profile?.city, user?.profile?.country].filter(Boolean).join(', ')
                : 'Not provided'}
            </Text>
          </View>
          
          {/* Show position - always visible */}
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>🏀 Position</Text>
            <Text style={styles.detailValue}>
              {user?.profile?.preferred_position || 'Not provided'}
            </Text>
          </View>
          
          {/* Show jersey number - always visible */}
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>🎽 Jersey #</Text>
            <Text style={styles.detailValue}>
              {user?.profile?.jersey_number || 'Not provided'}
            </Text>
          </View>
          
          {/* Show hand style - always visible */}
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>🤾 Hand Style</Text>
            <Text style={styles.detailValue}>
              {user?.profile?.hand_style 
                ? user.profile.hand_style.replace(/_/g, ' ') 
                : 'Not provided'}
            </Text>
          </View>
          
          {/* Show favorite player - always visible */}
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>⭐ Favorite Player</Text>
            <Text style={styles.detailValue} numberOfLines={1} ellipsizeMode="tail">
              {user?.profile?.favorite_player || 'Not provided'}
            </Text>
          </View>
          
          {/* Show height - always visible */}
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>📏 Height</Text>
            <Text style={styles.detailValue}>
              {user?.profile?.height_cm ? `${user.profile.height_cm} cm` : 'Not provided'}
            </Text>
          </View>

        </View>

        {/* Stats Section */}
        {statsLoading ? (
          <View style={styles.statsLoadingContainer}>
            <ActivityIndicator size="small" color={COLORS.SECONDARY} />
          </View>
        ) : playerStats ? (
          <>
            {/* Career Stats Summary */}
            <View style={styles.statsSectionHeader}>
              <Text style={styles.statsSectionTitle}>
                📊 {isOwnProfile ? 'Career Statistics' : 'Player Statistics'}
              </Text>
            </View>
            
            <View style={styles.statsGrid}>
              <View style={[styles.statCard, styles.statCardGreen]}>
                <Text style={styles.statCardEmoji}>🎮</Text>
                <Text style={styles.statCardValue}>{playerStats.total_games || 0}</Text>
                <Text style={styles.statCardLabel}>Games</Text>
              </View>
              <View style={[styles.statCard, styles.statCardBlue]}>
                <Text style={styles.statCardEmoji}>🏀</Text>
                <Text style={styles.statCardValue}>{playerStats.total_points || 0}</Text>
                <Text style={styles.statCardLabel}>Points</Text>
              </View>
              <View style={[styles.statCard, styles.statCardOrange]}>
                <Text style={styles.statCardEmoji}>📈</Text>
                <Text style={styles.statCardValue}>{(playerStats.average_points_per_game || 0).toFixed(1)}</Text>
                <Text style={styles.statCardLabel}>Avg PPG</Text>
              </View>
              <View style={[styles.statCard, styles.statCardPurple]}>
                <Text style={styles.statCardEmoji}>🎯</Text>
                <Text style={styles.statCardValue}>{playerStats.total_assists || 0}</Text>
                <Text style={styles.statCardLabel}>Assists</Text>
              </View>
              <View style={[styles.statCard, styles.statCardGreen]}>
                <Text style={styles.statCardEmoji}>📦</Text>
                <Text style={styles.statCardValue}>{playerStats.total_rebounds || 0}</Text>
                <Text style={styles.statCardLabel}>Rebounds</Text>
              </View>
              <View style={[styles.statCard, styles.statCardBlue]}>
                <Text style={styles.statCardEmoji}>⚠️</Text>
                <Text style={styles.statCardValue}>{playerStats.total_fouls || 0}</Text>
                <Text style={styles.statCardLabel}>Fouls</Text>
              </View>
            </View>
            
            {/* Extended Stats Row */}
            <View style={styles.statsGrid}>
              <View style={[styles.statCard, styles.statCardSmall, styles.statCardOrange]}>
                <Text style={styles.statCardEmojiSmall}>🎯</Text>
                <Text style={styles.statCardValueSmall}>{playerStats.total_shots_made || 0}</Text>
                <Text style={styles.statCardLabelSmall}>FG Made</Text>
              </View>
              <View style={[styles.statCard, styles.statCardSmall, styles.statCardPurple]}>
                <Text style={styles.statCardEmojiSmall}>3️⃣</Text>
                <Text style={styles.statCardValueSmall}>{playerStats.total_shots_attempted || 0}</Text>
                <Text style={styles.statCardLabelSmall}>Attempts</Text>
              </View>
              <View style={[styles.statCard, styles.statCardSmall, styles.statCardGreen]}>
                <Text style={styles.statCardEmojiSmall}>📈</Text>
                <Text style={styles.statCardValueSmall}>{playerStats.total_games > 0 ? (playerStats.total_assists / playerStats.total_games).toFixed(1) : '0'}</Text>
                <Text style={styles.statCardLabelSmall}>Ast/Game</Text>
              </View>
              <View style={[styles.statCard, styles.statCardSmall, styles.statCardBlue]}>
                <Text style={styles.statCardEmojiSmall}>📊</Text>
                <Text style={styles.statCardValueSmall}>{playerStats.total_games > 0 ? (playerStats.total_rebounds / playerStats.total_games).toFixed(1) : '0'}</Text>
                <Text style={styles.statCardLabelSmall}>Reb/Game</Text>
              </View>
              <View style={[styles.statCard, styles.statCardSmall, styles.statCardOrange]}>
                <Text style={styles.statCardEmojiSmall}>⚡</Text>
                <Text style={styles.statCardValueSmall}>{playerStats.total_violations || 0}</Text>
                <Text style={styles.statCardLabelSmall}>Violations</Text>
              </View>
              <View style={[styles.statCard, styles.statCardSmall, styles.statCardPurple]}>
                <Text style={styles.statCardEmojiSmall}>🔥</Text>
                <Text style={styles.statCardValueSmall}>{playerStats.total_games > 0 ? (playerStats.total_points / playerStats.total_games).toFixed(1) : '0'}</Text>
                <Text style={styles.statCardLabelSmall}>PPG</Text>
              </View>
            </View>
            
            {playerStats.career_shooting_percentage !== undefined && (
              <View style={styles.shootingStats}>
                <Text style={styles.shootingLabel}>Field Goal %</Text>
                <View style={styles.shootingBar}>
                  <View 
                    style={[
                      styles.shootingFill,
                      { width: `${playerStats.career_shooting_percentage || 0}%` }
                    ]}
                  />
                </View>
                <Text style={styles.shootingPercent}>{(playerStats.career_shooting_percentage || 0).toFixed(1)}%</Text>
              </View>
            )}

            {/* Recent Games */}
            {gameStats && gameStats.length > 0 && (
              <>
                <View style={styles.statsSectionHeader}>
                  <Text style={styles.statsSectionTitle}>🎮 Recent Games</Text>
                </View>
                
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.recentGamesScroll}>
                  {gameStats.slice(0, 5).map((game, index) => (
                    <TouchableOpacity 
                      key={index} 
                      style={styles.gameCard}
                      onPress={() => router.push(`/match-detail?gameId=${game.game_id || game.id}`)}
                      activeOpacity={0.7}
                    >
                      <View style={styles.gameCardHeader}>
                        <Text style={styles.gameDate}>
                          {new Date(game.created_at).toLocaleDateString()}
                        </Text>
                        <Text style={styles.gameCardArrow}>→</Text>
                      </View>
                      <View style={styles.gameCardStats}>
                        <View style={styles.gameStatRow}>
                          <Text style={styles.gameStatLabel}>PTS</Text>
                          <Text style={styles.gameStatValue}>{game.points}</Text>
                        </View>
                        <View style={styles.gameStatRow}>
                          <Text style={styles.gameStatLabel}>AST</Text>
                          <Text style={styles.gameStatValue}>{game.assists}</Text>
                        </View>
                        <View style={styles.gameStatRow}>
                          <Text style={styles.gameStatLabel}>REB</Text>
                          <Text style={styles.gameStatValue}>{game.rebounds}</Text>
                        </View>
                        <View style={styles.gameStatRow}>
                          <Text style={styles.gameStatLabel}>FG%</Text>
                          <Text style={styles.gameStatValue}>
                            {game.shots_attempted > 0 
                              ? ((game.shots_made / game.shots_attempted) * 100).toFixed(0)
                              : '0'}%
                          </Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </>
            )}
          </>
        ) : (
          <View style={styles.noStatsContainer}>
            <Text style={styles.noStatsText}>No games played yet</Text>
          </View>
        )}

        {/* Settings Section - Only show for own profile */}
        {isOwnProfile && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Account Settings</Text>

            <TouchableOpacity
              style={styles.settingItem}
              onPress={() => setEditModalVisible(true)}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>✏️</Text>
                <View>
                  <Text style={styles.settingName}>Edit Profile</Text>
                  <Text style={styles.settingDesc}>Update your information</Text>
                </View>
              </View>
              <Text style={styles.settingArrow}>→</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.settingItem}
              onPress={() => setPasswordModalVisible(true)}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🔒</Text>
                <View>
                  <Text style={styles.settingName}>Change Password</Text>
                  <Text style={styles.settingDesc}>Update your password</Text>
                </View>
              </View>
              <Text style={styles.settingArrow}>→</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.settingItem}
              onPress={() => Alert.alert('Info', 'Notifications settings coming soon')}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🔔</Text>
                <View>
                  <Text style={styles.settingName}>Notifications</Text>
                  <Text style={styles.settingDesc}>Manage notification preferences</Text>
                </View>
              </View>
              <Text style={styles.settingArrow}>→</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.settingItem}
              onPress={() => Alert.alert('Info', 'Theme settings coming soon')}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🎨</Text>
                <View>
                  <Text style={styles.settingName}>Appearance</Text>
                  <Text style={styles.settingDesc}>Light/Dark mode</Text>
                </View>
              </View>
              <Text style={styles.settingArrow}>→</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* About Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>

          <TouchableOpacity
            style={styles.settingItem}
            onPress={() => Alert.alert('About', 'Scoring Basket v1.0.0')}
          >
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>ℹ️</Text>
              <View>
                <Text style={styles.settingName}>About App</Text>
                <Text style={styles.settingDesc}>Version info</Text>
              </View>
            </View>
            <Text style={styles.settingArrow}>→</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.settingItem}
            onPress={() => Alert.alert('Help', 'Help center coming soon')}
          >
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>❓</Text>
              <View>
                <Text style={styles.settingName}>Help & Support</Text>
                <Text style={styles.settingDesc}>FAQ and contact us</Text>
              </View>
            </View>
            <Text style={styles.settingArrow}>→</Text>
          </TouchableOpacity>
        </View>

        {/* Danger Zone - Only show for own profile */}
        {isOwnProfile && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Danger Zone</Text>

            <TouchableOpacity
              style={[styles.settingItem, styles.dangerItem]}
              onPress={handleDeactivateAccount}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>⚠️</Text>
                <View>
                  <Text style={styles.settingName}>Deactivate Account</Text>
                  <Text style={styles.settingDesc}>Permanently delete your account</Text>
                </View>
              </View>
              <Text style={styles.settingArrow}>→</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Logout Button - Only show for own profile */}
        {isOwnProfile && (
          <TouchableOpacity
            style={styles.logoutButton}
            onPress={handleLogout}
          >
            <Text style={styles.logoutButtonText}>Logout</Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      {/* Edit Profile Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={editModalVisible}
        onRequestClose={() => setEditModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => setEditModalVisible(false)}
              >
                <Text style={styles.backButtonText}>Back</Text>
              </TouchableOpacity>
              <Text style={styles.modalTitle}>Edit Profile</Text>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setEditModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.form}>
              {/* Basic Info */}
              <Text style={styles.sectionLabel}>Basic Information</Text>
              
              <Text style={styles.label}>First Name *</Text>
              <TextInput
                style={styles.input}
                placeholder="John"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={firstName}
                onChangeText={setFirstName}
                editable={!updating}
              />

              <Text style={styles.label}>Last Name *</Text>
              <TextInput
                style={styles.input}
                placeholder="Doe"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={lastName}
                onChangeText={setLastName}
                editable={!updating}
              />

              <Text style={styles.label}>Bio</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Tell us about yourself..."
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={bio}
                onChangeText={setBio}
                multiline
                numberOfLines={3}
                editable={!updating}
              />

              {/* Location */}
              <Text style={styles.sectionLabel}>Location</Text>
              
              <Text style={styles.label}>City</Text>
              <TextInput
                style={styles.input}
                placeholder="Mumbai"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={city}
                onChangeText={setCity}
                editable={!updating}
              />

              <Text style={styles.label}>Country</Text>
              <TextInput
                style={styles.input}
                placeholder="India"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={country}
                onChangeText={setCountry}
                editable={!updating}
              />

              {/* Basketball Info */}
              <Text style={styles.sectionLabel}>Basketball Profile</Text>
              
              <Text style={styles.label}>Date of Birth</Text>
              <TextInput
                style={styles.input}
                placeholder="1995-05-15"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={dateOfBirth}
                onChangeText={setDateOfBirth}
                editable={!updating}
              />

              <Text style={styles.label}>Preferred Position</Text>
              <View style={styles.pickerContainer}>
                {positionOptions.map((position) => (
                  <TouchableOpacity
                    key={position}
                    style={[styles.pickerOption, preferredPosition === position && styles.pickerOptionSelected]}
                    onPress={() => setPreferredPosition(position)}
                    disabled={updating}
                  >
                    <Text style={[styles.pickerOptionText, preferredPosition === position && styles.pickerOptionTextSelected]}>
                      {position}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.label}>Jersey Number</Text>
              <TextInput
                style={styles.input}
                placeholder="23"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                keyboardType="numeric"
                value={jerseyNumber}
                onChangeText={setJerseyNumber}
                editable={!updating}
              />

              <Text style={styles.label}>Hand Style</Text>
              <View style={styles.pickerContainer}>
                {handStyles.map((style) => (
                  <TouchableOpacity
                    key={style}
                    style={[styles.pickerOption, handStyle === style && styles.pickerOptionSelected]}
                    onPress={() => setHandStyle(style)}
                    disabled={updating}
                  >
                    <Text style={[styles.pickerOptionText, handStyle === style && styles.pickerOptionTextSelected]}>
                      {style.replace('_', ' ')}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.label}>Favorite Player</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.horizontalScroll}>
                {favoritePlayers.map((player) => (
                  <TouchableOpacity
                    key={player}
                    style={[styles.playerChip, favoritePlayer === player && styles.playerChipSelected]}
                    onPress={() => setFavoritePlayer(favoritePlayer === player ? '' : player)}
                    disabled={updating}
                  >
                    <Text style={[styles.playerChipText, favoritePlayer === player && styles.playerChipTextSelected]}>
                      {player}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <Text style={styles.label}>Height (cm)</Text>
              <TextInput
                style={styles.input}
                placeholder="175"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                keyboardType="numeric"
                value={heightCm}
                onChangeText={setHeightCm}
                editable={!updating}
              />

              <TouchableOpacity
                style={[styles.submitButton, updating && styles.buttonDisabled]}
                onPress={handleUpdateProfile}
                disabled={updating}
              >
                {updating ? (
                  <ActivityIndicator color={COLORS.BG_LIGHT} />
                ) : (
                  <Text style={styles.submitButtonText}>Save Changes</Text>
                )}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Password Change Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={passwordModalVisible}
        onRequestClose={() => setPasswordModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Change Password</Text>
              <TouchableOpacity onPress={() => setPasswordModalVisible(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            <TextInput
              style={styles.input}
              placeholder="Current Password"
              secureTextEntry
              value={oldPassword}
              onChangeText={setOldPassword}
            />
            
            <TextInput
              style={styles.input}
              placeholder="New Password"
              secureTextEntry
              value={newPassword}
              onChangeText={setNewPassword}
            />
            
            <TextInput
              style={styles.input}
              placeholder="Confirm New Password"
              secureTextEntry
              value={confirmNewPassword}
              onChangeText={setConfirmNewPassword}
            />
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  setPasswordModalVisible(false);
                  setOldPassword('');
                  setNewPassword('');
                  setConfirmNewPassword('');
                }}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handlePasswordChange}
                disabled={changingPassword}
              >
                <Text style={styles.saveButtonText}>
                  {changingPassword ? 'Changing...' : 'Change Password'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  scrollContent: {
    paddingBottom: SPACING.md
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.SECONDARY,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: SPACING.sm
  },
  avatarText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.BG_LIGHT
  },
  username: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  email: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY
  },
  bio: {
    fontSize: 11,
    color: COLORS.TEXT_SECONDARY,
    textAlign: 'center',
    marginTop: 2
  },
  detailsSection: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER_LIGHT
  },
  detailLabel: {
    fontSize: 13,
    color: COLORS.TEXT_SECONDARY,
    flex: 1
  },
  detailValue: {
    fontSize: 13,
    color: COLORS.PRIMARY,
    fontWeight: '500',
    flex: 2,
    textAlign: 'right'
  },
  statsSection: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  statItem: {
    alignItems: 'center'
  },
  statNumber: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.SECONDARY,
    marginBottom: 2
  },
  statName: {
    fontSize: 11,
    color: COLORS.TEXT_SECONDARY
  },
  section: {
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: 6
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: SPACING.sm,
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 6,
    marginBottom: 4
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1
  },
  settingIcon: {
    fontSize: 20,
    marginRight: SPACING.sm
  },
  settingName: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  settingDesc: {
    fontSize: 11,
    color: COLORS.TEXT_SECONDARY
  },
  settingArrow: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    marginLeft: SPACING.sm
  },
  logoutButton: {
    marginHorizontal: SPACING.sm,
    marginTop: SPACING.sm,
    marginBottom: SPACING.sm,
    backgroundColor: COLORS.ACCENT,
    paddingVertical: SPACING.sm,
    borderRadius: 6,
    alignItems: 'center'
  },
  logoutButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 14
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.sm
  },
  modalContent: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 10,
    width: '100%',
    maxWidth: 400,
    maxHeight: '90%',
    padding: SPACING.md
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
    paddingBottom: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.PRIMARY,
    flex: 1,
    textAlign: 'center'
  },
  backButton: {
    paddingHorizontal: 4,
    paddingVertical: 2
  },
  backButtonText: {
    fontSize: 14,
    color: COLORS.SECONDARY,
    fontWeight: '600'
  },
  cancelButton: {
    paddingHorizontal: 4,
    paddingVertical: 2
  },
  cancelButtonText: {
    fontSize: 14,
    color: COLORS.ERROR,
    fontWeight: '600'
  },
  closeButton: {
    fontSize: 20,
    color: COLORS.TEXT_SECONDARY
  },
  form: {
    gap: SPACING.sm
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 6,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    fontSize: 13,
    color: COLORS.PRIMARY
  },
  submitButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingVertical: SPACING.sm,
    borderRadius: 6,
    alignItems: 'center',
    marginTop: SPACING.sm
  },
  buttonDisabled: {
    opacity: 0.6
  },
  submitButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 14
  },
  sectionLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.PRIMARY,
    marginTop: SPACING.md,
    marginBottom: SPACING.sm
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top'
  },
  pickerContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm
  },
  pickerOption: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: COLORS.BORDER
  },
  pickerOptionSelected: {
    backgroundColor: COLORS.SECONDARY,
    borderColor: COLORS.SECONDARY
  },
  pickerOptionText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY
  },
  pickerOptionTextSelected: {
    color: COLORS.BG_LIGHT
  },
  horizontalScroll: {
    marginBottom: SPACING.sm
  },
  playerChip: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    marginRight: SPACING.sm
  },
  playerChipSelected: {
    backgroundColor: COLORS.SECONDARY,
    borderColor: COLORS.SECONDARY
  },
  playerChipText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY
  },
  playerChipTextSelected: {
    color: COLORS.BG_LIGHT
  },
  dangerItem: {
    borderColor: COLORS.ERROR,
    borderWidth: 1
  },
  statsLoadingContainer: {
    paddingVertical: SPACING.lg,
    alignItems: 'center'
  },
  statsSectionHeader: {
    paddingHorizontal: SPACING.md,
    paddingTop: SPACING.lg,
    paddingBottom: SPACING.md
  },
  statsSectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.PRIMARY
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.md,
    paddingBottom: SPACING.md,
    gap: 8
  },
  statCard: {
    width: '31.5%',
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    marginBottom: 0,
    borderWidth: 2,
    borderColor: '#DDD'
  },
  statCardGreen: {
    backgroundColor: '#81C784',
    borderColor: '#66BB6A',
    shadowColor: '#81C784',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4
  },
  statCardBlue: {
    backgroundColor: '#64B5F6',
    borderColor: '#42A5F5',
    shadowColor: '#64B5F6',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4
  },
  statCardOrange: {
    backgroundColor: '#FFB74D',
    borderColor: '#FFA726',
    shadowColor: '#FFB74D',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4
  },
  statCardPurple: {
    backgroundColor: '#CE93D8',
    borderColor: '#BA68C8',
    shadowColor: '#CE93D8',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4
  },
  statCardEmoji: {
    fontSize: 24,
    marginBottom: 6
  },
  statCardLabel: {
    fontSize: 12,
    color: '#FFF',
    fontWeight: '600',
    textAlign: 'center'
  },
  statCardValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#FFF',
    marginVertical: 4
  },
  statCardSmall: {
    width: '30%',
    marginBottom: SPACING.md,
    paddingVertical: SPACING.xs,
    paddingHorizontal: SPACING.xs
  },
  statCardEmojiSmall: {
    fontSize: 16,
    marginBottom: 4
  },
  statCardValueSmall: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFF',
    marginVertical: 2
  },
  statCardLabelSmall: {
    fontSize: 10,
    color: '#FFF',
    fontWeight: '600',
    textAlign: 'center'
  },
  shootingStats: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  shootingLabel: {
    fontSize: 12,
    color: COLORS.TEXT_SECONDARY,
    marginBottom: SPACING.xs
  },
  shootingBar: {
    height: 8,
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: SPACING.xs
  },
  shootingFill: {
    height: '100%',
    backgroundColor: COLORS.SECONDARY,
    borderRadius: 4
  },
  shootingPercent: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.SECONDARY
  },
  recentGamesScroll: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md
  },
  gameCard: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 8,
    padding: SPACING.sm,
    marginRight: SPACING.md,
    width: 120,
    borderWidth: 1,
    borderColor: COLORS.BORDER_LIGHT
  },
  gameCardHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingBottom: SPACING.xs,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER_LIGHT
  },
  gameDate: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY
  },
  gameCardArrow: {
    fontSize: 12,
    color: COLORS.SECONDARY,
    fontWeight: 'bold'
  },
  gameCardStats: {
    marginTop: SPACING.xs
  },
  gameStatRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.xs
  },
  gameStatLabel: {
    fontSize: 10,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: '500'
  },
  gameStatValue: {
    fontSize: 12,
    fontWeight: 'bold',
    color: COLORS.SECONDARY
  },
  noStatsContainer: {
    paddingVertical: SPACING.lg,
    alignItems: 'center',
    paddingHorizontal: SPACING.md
  },
  noStatsText: {
    fontSize: 14,
    color: COLORS.TEXT_SECONDARY,
    fontStyle: 'italic'
  }
});

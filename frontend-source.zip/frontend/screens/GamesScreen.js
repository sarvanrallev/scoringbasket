import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
  FlatList,
  Animated
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { gamesAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function GamesScreen() {
  const router = useRouter();
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState('my_games'); // my_games, all, scheduled, completed, in_progress
  const [currentUser, setCurrentUser] = useState(null);
  const [userGameIds, setUserGameIds] = useState([]);
  
  // Animation refs
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    loadUserData();
  }, []);

  // Trigger animations when games load
  useEffect(() => {
    if (games.length > 0) {
      scaleAnim.setValue(0);
      opacityAnim.setValue(0);
      Animated.parallel([
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true
        }),
        Animated.timing(opacityAnim, {
          toValue: 1,
          duration: 400,
          useNativeDriver: true
        })
      ]).start();
    }
  }, [games]);

  // Load games when filter OR userGameIds changes
  useEffect(() => {
    loadGames();
  }, [filter, userGameIds]);

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user_data');
      console.log('[DEBUG] loadUserData - Retrieved userData from AsyncStorage:', userData ? 'YES' : 'NO');
      
      if (userData) {
        const parsed = JSON.parse(userData);
        console.log('[DEBUG] loadUserData - Parsed user:', {
          id: parsed.id,
          email: parsed.email,
          name: parsed.full_name
        });
        setCurrentUser(parsed);
        
        // Fetch user's game history - with timeout handling
        try {
          console.log('[DEBUG] loadUserData - Calling getPlayerGameStats with user ID:', parsed.id);
          
          // Create a timeout promise
          const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error('timeout')), 5000)
          );
          
          // Race between the API call and timeout
          const gameStats = await Promise.race([
            gamesAPI.getPlayerGameStats(parsed.id),
            timeoutPromise
          ]);
          
          console.log('[DEBUG] loadUserData - Got gameStats response:', {
            count: gameStats?.length || 0,
            data: gameStats
          });
          
          const gameIds = gameStats.map(stat => stat.game_id).filter(id => id);
          console.log('[DEBUG] loadUserData - Extracted gameIds:', gameIds);
          setUserGameIds(gameIds);
        } catch (err) {
          console.log('[DEBUG] loadUserData - Error fetching user game stats:', {
            message: err.message,
            isTimeout: err.message === 'timeout',
            status: err.response?.status,
          });
          // On timeout or error, set empty array and continue
          // User will see "All Games" instead of just "My Games"
          setUserGameIds([]);
        }
      } else {
        console.log('[DEBUG] loadUserData - No userData found in AsyncStorage');
        setCurrentUser(null);
        setUserGameIds([]);
      }
    } catch (error) {
      console.error('[DEBUG] loadUserData - Error loading user:', error);
      setUserGameIds([]);
    }
  };

  useFocusEffect(
    useCallback(() => {
      loadUserData();
      loadGames();
    }, [filter])
  );

  const loadGames = async () => {
    setLoading(true);
    try {
      console.log('[DEBUG] loadGames - Starting with filter:', filter);
      console.log('[DEBUG] loadGames - Current userGameIds:', userGameIds);
      console.log('[DEBUG] loadGames - Current user:', currentUser?.id);
      
      let params = {};
      if (filter !== 'all' && filter !== 'my_games') {
        params.status = filter;
      }
      
      const response = await gamesAPI.getGames(params);
      // Handle different response formats
      let gamesData = Array.isArray(response) ? response : (response?.matches || []);
      
      console.log('[DEBUG] loadGames - Got', gamesData.length, 'games from API');
      
      // Filter for "my_games" - only show games where user participated or created
      if (filter === 'my_games' && currentUser?.id) {
        console.log('[DEBUG] loadGames - Filtering for my_games...');
        console.log('[DEBUG] loadGames - userGameIds:', userGameIds);
        console.log('[DEBUG] loadGames - All game IDs:', gamesData.map(g => g.id));
        
        const beforeFilter = gamesData.length;
        gamesData = gamesData.filter(game => {
          // Include if user participated in the game OR if user created the game
          const isParticipant = userGameIds.includes(game.id);
          const isCreator = game.created_by && Number(game.created_by) === Number(currentUser.id);
          const isIncluded = isParticipant || isCreator;
          
          if (!isIncluded) {
            console.log('[DEBUG] loadGames - Filtering OUT game ID', game.id);
          } else if (isCreator) {
            console.log('[DEBUG] loadGames - Including game ID', game.id, '(created by user)');
          }
          return isIncluded;
        });
        
        console.log('[DEBUG] loadGames - After my_games filter:', beforeFilter, '→', gamesData.length, 'games');
        
        // Sort by date - newest first
        gamesData.sort((a, b) => new Date(b.match_date) - new Date(a.match_date));
      } else if (filter === 'my_games' && !currentUser?.id) {
        console.log('[DEBUG] loadGames - Not logged in, showing all games instead of my_games');
        // User not logged in - show all games instead
      } else if (filter === 'in_progress' && currentUser?.id) {
        console.log('[DEBUG] loadGames - Filtering for in_progress...');
        const beforeFilter = gamesData.length;
        
        gamesData = gamesData.filter(game => {
          // Include if user is the creator (since they create the game, they're automatically a member)
          const isCreator = game.created_by && Number(game.created_by) === Number(currentUser.id);
          
          if (!isCreator) {
            console.log('[DEBUG] loadGames - Filtering OUT game ID', game.id, '(not created by user)');
          } else {
            console.log('[DEBUG] loadGames - Including game ID', game.id, '(created by user)');
          }
          return isCreator;
        });
        
        console.log('[DEBUG] loadGames - After in_progress filter:', beforeFilter, '→', gamesData.length, 'games');
        
        // Sort by date - newest first
        gamesData.sort((a, b) => new Date(b.match_date) - new Date(a.match_date));
      } else {
        console.log('[DEBUG] loadGames - Filter is', filter, '- no additional filtering by user');
      }
      
      console.log('[DEBUG] loadGames - Final games to display:', gamesData.length);
      setGames(gamesData);
    } catch (error) {
      console.error('[DEBUG] loadGames - Error:', error);
      Alert.alert('Error', 'Failed to load matches');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadGames();
    setRefreshing(false);
  };

  const handleDeleteGame = (gameId, gameStatus) => {
    // Only allow deletion of scheduled games
    if (gameStatus !== 'scheduled') {
      Alert.alert('Cannot Delete', 'You can only delete scheduled games.');
      return;
    }

    Alert.alert(
      'Delete Game',
      'Are you sure you want to delete this game?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await gamesAPI.deleteGame(gameId);
              Alert.alert('Success', 'Game deleted successfully');
              loadGames();
            } catch (error) {
              console.error('Error deleting game:', error);
              Alert.alert('Error', 'Failed to delete game');
            }
          }
        }
      ]
    );
  };

  // Helper function to determine score color based on win/loss/tie
  const getScoreColor = (homeScore, awayScore) => {
    if (homeScore > awayScore) return { home: COLORS.SUCCESS, away: COLORS.DANGER }; // Home wins (green vs red)
    if (awayScore > homeScore) return { home: COLORS.DANGER, away: COLORS.SUCCESS }; // Away wins (red vs green)
    return { home: COLORS.WARNING, away: COLORS.WARNING }; // Tie (orange/yellow)
  };

  const renderGameCard = ({ item: game }) => {
    const isUserGame = userGameIds.includes(game.id);
    const scoreColors = getScoreColor(game.home_score || 0, game.away_score || 0);
    
    // Determine card color based on filter and user status
    let cardStyle = styles.gameCard;
    if (isUserGame) {
      if (filter === 'my_games') {
        cardStyle = [styles.gameCard, styles.gameCardMyGames];
      } else if (filter === 'all') {
        cardStyle = [styles.gameCard, styles.gameCardAll];
      } else if (filter === 'scheduled') {
        cardStyle = [styles.gameCard, styles.gameCardScheduled];
      } else if (filter === 'completed') {
        cardStyle = [styles.gameCard, styles.gameCardCompleted];
      } else if (filter === 'in_progress') {
        cardStyle = [styles.gameCard, styles.gameCardInProgress];
      }
    } else {
      // Other user's games with muted colors
      if (filter === 'scheduled') {
        cardStyle = [styles.gameCard, styles.gameCardScheduledOther];
      } else if (filter === 'completed') {
        cardStyle = [styles.gameCard, styles.gameCardCompletedOther];
      } else if (filter === 'all') {
        cardStyle = [styles.gameCard, styles.gameCardOther];
      } else if (filter === 'in_progress') {
        cardStyle = [styles.gameCard, styles.gameCardInProgressOther];
      }
    }
    
    return (
      <TouchableOpacity
        style={cardStyle}
        onPress={() => {
          router.push(`/match-detail?gameId=${game.id}`);
        }}
      >
        <View style={styles.gameHeader}>
          <View style={styles.teamContainer}>
            <Text style={styles.teamName}>{game.home_team?.name || 'Team A'}</Text>
            <Text style={[styles.score, { color: scoreColors.home }]}>{game.home_score || 0}</Text>
          </View>

          <View style={styles.vsContainer}>
            <Text style={styles.vs}>⚡</Text>
          </View>

          <View style={[styles.teamContainer, styles.awayTeam]}>
            <Text style={styles.teamName}>{game.away_team?.name || 'Team B'}</Text>
            <Text style={[styles.score, { color: scoreColors.away }]}>{game.away_score || 0}</Text>
          </View>
        </View>

        {/* Stats section removed for compact view */}

        <View style={styles.gameFooter}>
          <View style={styles.statusContainer}>
            <Text style={[styles.status, 
              game.status === 'in_progress' && styles.statusLive,
              game.status === 'scheduled' && styles.statusScheduled,
              game.status === 'completed' && styles.statusCompleted
            ]}>
              {game.status === 'scheduled' ? '⏱️ Scheduled' :
               game.status === 'in_progress' ? '🎯 LIVE' :
               game.status === 'completed' ? '✅ Completed' : '❌ Cancelled'}
            </Text>
          </View>
          <View style={styles.footerRight}>
            <Text style={styles.date}>
              {new Date(game.match_date).toLocaleDateString()}
            </Text>
            {game.status === 'scheduled' && isUserGame && (
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => handleDeleteGame(game.id, game.status)}
              >
                <Text style={styles.deleteButtonText}>🗑️</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>🎮 Games</Text>
        <TouchableOpacity
          style={styles.createButton}
          onPress={() => router.push('/create-game')}
        >
          <Text style={styles.createButtonText}>+ New Game</Text>
        </TouchableOpacity>
      </View>

      {/* Filter Tabs */}
      <Animated.View style={[styles.filterContainer, { opacity: opacityAnim }]}>
        <TouchableOpacity
          style={[styles.filterTab, filter === 'all' && styles.filterTabActive, filter === 'all' && styles.filterTabAll]}
          onPress={() => setFilter('all')}
        >
          <Text style={[styles.filterText, filter === 'all' && styles.filterTextActive]}>
            All
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterTab, filter === 'my_games' && styles.filterTabActive, filter === 'my_games' && styles.filterTabMy]}
          onPress={() => setFilter('my_games')}
        >
          <Text style={[styles.filterText, filter === 'my_games' && styles.filterTextActive]}>
            My Games
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterTab, filter === 'scheduled' && styles.filterTabActive, filter === 'scheduled' && styles.filterTabScheduled]}
          onPress={() => setFilter('scheduled')}
        >
          <Text style={[styles.filterText, filter === 'scheduled' && styles.filterTextActive]}>
            Scheduled
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterTab, filter === 'completed' && styles.filterTabActive, filter === 'completed' && styles.filterTabCompleted]}
          onPress={() => setFilter('completed')}
        >
          <Text style={[styles.filterText, filter === 'completed' && styles.filterTextActive]}>
            Completed
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterTab, filter === 'in_progress' && styles.filterTabActive, filter === 'in_progress' && styles.filterTabInProgress]}
          onPress={() => setFilter('in_progress')}
        >
          <Text style={[styles.filterText, filter === 'in_progress' && styles.filterTextActive]}>
            IN PROGRESS
          </Text>
        </TouchableOpacity>
      </Animated.View>

      {/* Games List */}
      {games.length > 0 ? (
        <FlatList
          data={games}
          renderItem={renderGameCard}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        />
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BG_LIGHT
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.sm,
    backgroundColor: COLORS.BG_LIGHT,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.PRIMARY
  },
  createButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: 5
  },
  createButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 11
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.sm,
    gap: 6,
    backgroundColor: COLORS.BG_LIGHT,
    borderBottomWidth: 2,
    borderBottomColor: COLORS.SECONDARY
  },
  filterTab: {
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: COLORS.BG_SECONDARY,
    borderWidth: 2,
    borderColor: COLORS.BORDER
  },
  filterTabActive: {
    borderWidth: 2
  },
  filterTabAll: {
    backgroundColor: COLORS.TEXT_SECONDARY,
    borderColor: COLORS.TEXT_SECONDARY
  },
  filterTabMy: {
    backgroundColor: COLORS.SUCCESS,
    borderColor: COLORS.SUCCESS
  },
  filterTabScheduled: {
    backgroundColor: COLORS.SECONDARY,
    borderColor: COLORS.SECONDARY
  },
  filterTabCompleted: {
    backgroundColor: COLORS.SUCCESS,
    borderColor: COLORS.SUCCESS
  },
  filterTabInProgress: {
    backgroundColor: COLORS.DANGER,
    borderColor: COLORS.DANGER
  },
  filterText: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY
  },
  filterTextActive: {
    color: COLORS.BG_LIGHT,
    fontWeight: '700'
  },
  listContent: {
    padding: SPACING.sm
  },
  gameCard: {
    backgroundColor: COLORS.BG_LIGHT,
    borderRadius: 10,
    marginBottom: 2,
    padding: 8,
    position: 'relative',
    borderWidth: 1,
    borderColor: COLORS.BORDER
  },
  gameCardMyGames: {
    backgroundColor: '#E8F5E9',
    borderColor: COLORS.SUCCESS,
    borderWidth: 2,
    shadowColor: COLORS.SUCCESS,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5
  },
  gameCardAll: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderColor: COLORS.TEXT_SECONDARY,
    shadowColor: COLORS.TEXT_SECONDARY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2
  },
  gameCardScheduled: {
    backgroundColor: '#E3F2FD',
    borderColor: COLORS.SECONDARY,
    borderWidth: 2,
    shadowColor: COLORS.SECONDARY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5
  },
  gameCardScheduledOther: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderColor: COLORS.BORDER
  },
  gameCardCompleted: {
    backgroundColor: '#E8F5E9',
    borderColor: COLORS.SUCCESS,
    borderWidth: 2,
    shadowColor: COLORS.SUCCESS,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5
  },
  gameCardCompletedOther: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderColor: COLORS.BORDER
  },
  gameCardInProgress: {
    backgroundColor: '#FFEBEE',
    borderColor: COLORS.DANGER,
    borderWidth: 2,
    shadowColor: COLORS.DANGER,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5
  },
  gameCardInProgressOther: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderColor: COLORS.BORDER
  },
  gameCardOther: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderColor: COLORS.BORDER
  },
  gameCardHighlight: {
    backgroundColor: COLORS.SECONDARY_LIGHT
  },
  gameHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 3
  },
  teamContainer: {
    alignItems: 'center',
    flex: 1
  },
  awayTeam: {
    alignItems: 'flex-end'
  },
  teamName: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginBottom: 1
  },
  score: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.SECONDARY
  },
  vsContainer: {
    alignItems: 'center',
    marginHorizontal: SPACING.xs
  },
  vs: {
    fontSize: 18,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: 'bold'
  },
  gameFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 4,
    borderTopWidth: 1,
    borderTopColor: COLORS.TEXT_LIGHT
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  liveIndicator: {
    backgroundColor: '#ff4444',
    paddingHorizontal: SPACING.xs,
    paddingVertical: 2,
    borderRadius: 3,
    marginRight: SPACING.xs
  },
  liveText: {
    fontSize: 9,
    fontWeight: 'bold',
    color: 'white'
  },
  status: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.TEXT_SECONDARY
  },
  statusLive: {
    color: COLORS.DANGER,
    fontWeight: 'bold',
    fontSize: 13
  },
  statusScheduled: {
    color: COLORS.SECONDARY,
    fontWeight: '600'
  },
  statusCompleted: {
    color: COLORS.SUCCESS,
    fontWeight: '600'
  },
  date: {
    fontSize: 11,
    color: COLORS.TEXT_LIGHT
  },
  footerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8
  },
  deleteButton: {
    padding: 6,
    backgroundColor: '#FFE0E0',
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center'
  },
  deleteButtonText: {
    fontSize: 16
  }
});

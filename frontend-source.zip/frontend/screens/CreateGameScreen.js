import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  TextInput,
  Modal,
  FlatList,
  Platform
} from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePicker from '@react-native-community/datetimepicker';
import { gamesAPI, teamsAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function CreateGameScreen() {
  const router = useRouter();
  const [teams, setTeams] = useState([]);
  const [allTeams, setAllTeams] = useState([]);
  const [myTeams, setMyTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [teamFilter, setTeamFilter] = useState('my'); // 'my' or 'all'

  // Game data
  const [homeTeam, setHomeTeam] = useState(null);
  const [awayTeam, setAwayTeam] = useState(null);
  const [gameDate, setGameDate] = useState(new Date());
  const [gameTime, setGameTime] = useState(new Date());
  const [location, setLocation] = useState('');
  const [title, setTitle] = useState('');

  // Date/Time picker states
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);

  // Date/Time picker handlers
  const onDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || gameDate;
    setShowDatePicker(Platform.OS === 'ios');
    setGameDate(currentDate);
  };

  const onTimeChange = (event, selectedTime) => {
    const currentTime = selectedTime || gameTime;
    setShowTimePicker(Platform.OS === 'ios');
    setGameTime(currentTime);
  };

  const showDatepicker = () => {
    setShowDatePicker(true);
  };

  const showTimepicker = () => {
    setShowTimePicker(true);
  };

  // Player selection
  const [homePlayers, setHomePlayers] = useState([]);
  const [awayPlayers, setAwayPlayers] = useState([]);
  const [selectedHomePlayers, setSelectedHomePlayers] = useState([]);
  const [selectedAwayPlayers, setSelectedAwayPlayers] = useState([]);

  // Modals
  const [teamModalVisible, setTeamModalVisible] = useState(false);
  const [selectingForHome, setSelectingForHome] = useState(true);
  const [playerModalVisible, setPlayerModalVisible] = useState(false);

  useEffect(() => {
    loadUserData();
    loadTeams();
  }, []);

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem('user_data');
      if (userData) {
        const parsed = JSON.parse(userData);
        setCurrentUser(parsed);
      }
    } catch (error) {
      console.error('Error loading user:', error);
    }
  };

  const loadTeams = async () => {
    setLoading(true);
    try {
      const response = await teamsAPI.getTeams();
      const allTeamsData = Array.isArray(response) ? response : [];
      setAllTeams(allTeamsData);

      // Get user's teams
      if (currentUser?.id) {
        const userTeamsResponse = await teamsAPI.getUserTeams(currentUser.id);
        const userTeamsData = Array.isArray(userTeamsResponse) ? userTeamsResponse : [];
        setMyTeams(userTeamsData);
      }
      
      setTeams(allTeamsData);
    } catch (error) {
      console.error('Error loading teams:', error);
      Alert.alert('Error', 'Failed to load teams');
    } finally {
      setLoading(false);
    }
  };

  const handleTeamSelect = (team) => {
    // Prevent selecting the same team for both home and away
    const otherTeam = selectingForHome ? awayTeam : homeTeam;
    if (otherTeam && otherTeam.id === team.id) {
      Alert.alert('Error', 'Home and away teams must be different');
      return;
    }

    if (selectingForHome) {
      setHomeTeam(team);
      loadTeamPlayers(team.id, true);
    } else {
      setAwayTeam(team);
      loadTeamPlayers(team.id, false);
    }
    setTeamModalVisible(false);
  };

  const loadTeamPlayers = async (teamId, isHome) => {
    try {
      const response = await teamsAPI.getTeamWithMembers(teamId);
      const players = response.members || [];
      console.log('Loaded players:', players); // Debug log
      if (isHome) {
        setHomePlayers(players);
      } else {
        setAwayPlayers(players);
      }
    } catch (error) {
      console.error('Error loading team players:', error);
    }
  };

  const handleCreateGame = async () => {
    if (!homeTeam || !awayTeam) {
      Alert.alert('Error', 'Please select both home and away teams');
      return;
    }

    if (homeTeam.id === awayTeam.id) {
      Alert.alert('Error', 'Home and away teams cannot be the same');
      return;
    }

    if (!gameDate || !gameTime) {
      Alert.alert('Error', 'Please select game date and time');
      return;
    }

    if (selectedHomePlayers.length === 0 || selectedAwayPlayers.length === 0) {
      Alert.alert('Error', 'Please select at least one player for each team');
      return;
    }

    setCreating(true);
    try {
      // Combine date and time into a single Date object
      const combinedDateTime = new Date(
        gameDate.getFullYear(),
        gameDate.getMonth(),
        gameDate.getDate(),
        gameTime.getHours(),
        gameTime.getMinutes()
      );

      const payload = {
        home_team_id: homeTeam.id,
        away_team_id: awayTeam.id,
        match_date: combinedDateTime.toISOString(),
        title: title.trim() || `${homeTeam.name} vs ${awayTeam.name}`,
        location: location.trim() || null,
        home_players: selectedHomePlayers.map(player => {
          console.log('Player data:', player); // Debug log
          const userId = player.user_id || player.userId;
          if (!userId) {
            console.error('Player missing user_id:', player);
            throw new Error(`Player ${player.username || player.id} is missing user_id`);
          }
          return {
            user_id: userId,
            jersey_number: player.jersey_number || null,
            position: player.position || null,
            is_starter: true // For now, all selected players are starters
          };
        }),
        away_players: selectedAwayPlayers.map(player => {
          console.log('Player data:', player); // Debug log
          const userId = player.user_id || player.userId;
          if (!userId) {
            console.error('Player missing user_id:', player);
            throw new Error(`Player ${player.username || player.id} is missing user_id`);
          }
          return {
            user_id: userId,
            jersey_number: player.jersey_number || null,
            position: player.position || null,
            is_starter: true
          };
        })
      };

      console.log('Game creation payload:', payload); // Debug log

      const response = await gamesAPI.createGame(payload);
      Alert.alert('Success', 'Game created successfully', [
        { text: 'OK', onPress: () => router.back() }
      ]);
    } catch (error) {
      console.error('Create game error:', error);
      Alert.alert('Error', error.response?.data?.detail || 'Failed to create game');
    } finally {
      setCreating(false);
    }
  };

  const togglePlayerSelection = (player, isHome) => {
    if (isHome) {
      const isSelected = selectedHomePlayers.some(p => p.id === player.id);
      if (isSelected) {
        setSelectedHomePlayers(selectedHomePlayers.filter(p => p.id !== player.id));
      } else {
        setSelectedHomePlayers([...selectedHomePlayers, player]);
      }
    } else {
      const isSelected = selectedAwayPlayers.some(p => p.id === player.id);
      if (isSelected) {
        setSelectedAwayPlayers(selectedAwayPlayers.filter(p => p.id !== player.id));
      } else {
        setSelectedAwayPlayers([...selectedAwayPlayers, player]);
      }
    }
  };

  const renderTeamCard = ({ item: team }) => {
    // Check if this is a user's team
    const isMyTeam = myTeams.some(t => t.id === team.id);
    
    // Get team captain
    const captain = team.members?.find(m => m.is_captain) || 
                    team.members?.find(m => m.role === 'captain');
    
    // Get member count
    const memberCount = team.members?.length || 0;

    return (
      <TouchableOpacity
        style={styles.teamCard}
        onPress={() => handleTeamSelect(team)}
      >
        <View style={styles.teamCardHeader}>
          <View style={styles.teamInfo}>
            <View style={styles.teamNameContainer}>
              <Text style={styles.teamName}>{team.name}</Text>
              {isMyTeam && (
                <Text style={styles.myTeamBadge}>✓ My Team</Text>
              )}
            </View>
          </View>
        </View>
        
        <Text style={styles.teamCity}>{team.city || 'Unknown City'}</Text>
        
        <View style={styles.teamDetails}>
          <Text style={styles.teamDetail}>
            👥 {memberCount} member{memberCount !== 1 ? 's' : ''}
          </Text>
          {captain && (
            <Text style={styles.teamDetail}>
              👨‍💼 Captain: <Text style={styles.captainName}>{captain.username || captain.name || 'N/A'}</Text>
            </Text>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  const renderPlayerCard = ({ item: player }) => {
    const isHome = selectingForHome;
    const selectedPlayers = isHome ? selectedHomePlayers : selectedAwayPlayers;
    const isSelected = selectedPlayers.some(p => p.id === player.id);

    return (
      <TouchableOpacity
        style={[styles.playerCard, isSelected && styles.playerCardSelected]}
        onPress={() => togglePlayerSelection(player, isHome)}
      >
        <View style={styles.playerInfo}>
          <Text style={[styles.playerName, isSelected && styles.playerNameSelected]}>
            {player.username || player.name}
          </Text>
          {player.jersey_number && (
            <Text style={[styles.playerNumber, isSelected && styles.playerNumberSelected]}>
              #{player.jersey_number}
            </Text>
          )}
        </View>
        {isSelected && <Text style={styles.checkmark}>✓</Text>}
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={styles.backButton}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Create Game</Text>
          <View style={{ width: 50 }} />
        </View>

        {/* Team Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Teams</Text>

          <View style={styles.teamSelection}>
            <TouchableOpacity
              style={[styles.teamSelectButton, homeTeam && styles.teamSelectButtonSelected]}
              onPress={() => {
                setSelectingForHome(true);
                setTeamModalVisible(true);
              }}
            >
              <Text style={[styles.teamSelectText, homeTeam && styles.teamSelectTextSelected]}>
                {homeTeam ? homeTeam.name : 'Select Home Team'}
              </Text>
            </TouchableOpacity>

            <Text style={styles.vsText}>VS</Text>

            <TouchableOpacity
              style={[styles.teamSelectButton, awayTeam && styles.teamSelectButtonSelected]}
              onPress={() => {
                setSelectingForHome(false);
                setTeamModalVisible(true);
              }}
            >
              <Text style={[styles.teamSelectText, awayTeam && styles.teamSelectTextSelected]}>
                {awayTeam ? awayTeam.name : 'Select Away Team'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Player Selection */}
        {(homeTeam || awayTeam) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Players</Text>

            {homeTeam && (
              <View style={styles.teamPlayersSection}>
                <TouchableOpacity
                  style={styles.playerSelectButton}
                  onPress={() => {
                    setSelectingForHome(true);
                    setPlayerModalVisible(true);
                  }}
                >
                  <Text style={styles.playerSelectText}>
                    Home: {selectedHomePlayers.length} players selected
                  </Text>
                </TouchableOpacity>
              </View>
            )}

            {awayTeam && (
              <View style={styles.teamPlayersSection}>
                <TouchableOpacity
                  style={styles.playerSelectButton}
                  onPress={() => {
                    setSelectingForHome(false);
                    setPlayerModalVisible(true);
                  }}
                >
                  <Text style={styles.playerSelectText}>
                    Away: {selectedAwayPlayers.length} players selected
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}

        {/* Game Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Game Details</Text>

          <TextInput
            style={styles.input}
            placeholder="Game Title (optional)"
            placeholderTextColor={COLORS.TEXT_LIGHT}
            value={title}
            onChangeText={setTitle}
          />

          <TextInput
            style={styles.input}
            placeholder="Location (optional)"
            placeholderTextColor={COLORS.TEXT_LIGHT}
            value={location}
            onChangeText={setLocation}
          />

          <View style={styles.dateTimeContainer}>
            <TouchableOpacity
              style={[styles.input, styles.dateInput]}
              onPress={showDatepicker}
            >
              <Text style={[styles.inputText, { color: gameDate ? COLORS.TEXT : COLORS.TEXT_LIGHT }]}>
                {gameDate ? gameDate.toLocaleDateString() : 'Select Date'}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.input, styles.timeInput]}
              onPress={showTimepicker}
            >
              <Text style={[styles.inputText, { color: gameTime ? COLORS.TEXT : COLORS.TEXT_LIGHT }]}>
                {gameTime ? gameTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Select Time'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Create Button */}
        <TouchableOpacity
          style={[styles.createButton, creating && styles.buttonDisabled]}
          onPress={handleCreateGame}
          disabled={creating}
        >
          {creating ? (
            <ActivityIndicator color={COLORS.BG_LIGHT} />
          ) : (
            <Text style={styles.createButtonText}>Create Game</Text>
          )}
        </TouchableOpacity>
      </ScrollView>

      {/* Team Selection Modal */}
      <Modal
        visible={teamModalVisible}
        animationType="slide"
        onRequestClose={() => setTeamModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setTeamModalVisible(false)}>
              <Text style={styles.closeButton}>✕</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              Select {selectingForHome ? 'Home' : 'Away'} Team
            </Text>
            <View style={{ width: 30 }} />
          </View>

          {/* Team Filter Tabs */}
          <View style={styles.filterTabs}>
            <TouchableOpacity
              style={[styles.filterTab, teamFilter === 'my' && styles.filterTabActive]}
              onPress={() => {
                setTeamFilter('my');
                setTeams(myTeams);
              }}
            >
              <Text
                style={[
                  styles.filterTabText,
                  teamFilter === 'my' && styles.filterTabTextActive
                ]}
              >
                My Teams ({myTeams.length})
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.filterTab, teamFilter === 'all' && styles.filterTabActive]}
              onPress={() => {
                setTeamFilter('all');
                setTeams(allTeams);
              }}
            >
              <Text
                style={[
                  styles.filterTabText,
                  teamFilter === 'all' && styles.filterTabTextActive
                ]}
              >
                All Teams ({allTeams.length})
              </Text>
            </TouchableOpacity>
          </View>

          <FlatList
            data={teams}
            renderItem={renderTeamCard}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.teamList}
          />
        </SafeAreaView>
      </Modal>

      {/* Player Selection Modal */}
      <Modal
        visible={playerModalVisible}
        animationType="slide"
        onRequestClose={() => setPlayerModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setPlayerModalVisible(false)}>
              <Text style={styles.closeButton}>✕</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              Select Players - {selectingForHome ? homeTeam?.name : awayTeam?.name}
            </Text>
            <TouchableOpacity onPress={() => setPlayerModalVisible(false)}>
              <Text style={styles.doneButton}>Done</Text>
            </TouchableOpacity>
          </View>

          <FlatList
            data={selectingForHome ? homePlayers : awayPlayers}
            renderItem={renderPlayerCard}
            keyExtractor={(item) => item.id.toString()}
            contentContainerStyle={styles.playerList}
          />
        </SafeAreaView>
      </Modal>

      {/* Date Picker */}
      {showDatePicker && (
        <DateTimePicker
          testID="dateTimePicker"
          value={gameDate}
          mode="date"
          is24Hour={true}
          display="default"
          minimumDate={new Date()}
          onChange={onDateChange}
        />
      )}

      {/* Time Picker */}
      {showTimePicker && (
        <DateTimePicker
          testID="timePicker"
          value={gameTime}
          mode="time"
          is24Hour={true}
          display="default"
          onChange={onTimeChange}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.BG_LIGHT
  },
  scrollView: {
    flex: 1
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
    backgroundColor: COLORS.BG_LIGHT,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  backButton: {
    fontSize: 16,
    color: COLORS.SECONDARY
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK
  },
  section: {
    padding: SPACING.md
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK,
    marginBottom: SPACING.md
  },
  teamSelection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  teamSelectButton: {
    flex: 1,
    padding: SPACING.md,
    borderWidth: 2,
    borderColor: COLORS.BORDER,
    borderRadius: 8,
    alignItems: 'center'
  },
  teamSelectButtonSelected: {
    borderColor: COLORS.SECONDARY,
    backgroundColor: COLORS.SECONDARY_LIGHT
  },
  teamSelectText: {
    fontSize: 16,
    color: COLORS.TEXT_LIGHT
  },
  teamSelectTextSelected: {
    color: COLORS.SECONDARY
  },
  vsText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK,
    marginHorizontal: SPACING.md
  },
  teamPlayersSection: {
    marginBottom: SPACING.md
  },
  playerSelectButton: {
    padding: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 8,
    backgroundColor: COLORS.BG_LIGHT
  },
  playerSelectText: {
    fontSize: 16,
    color: COLORS.TEXT_DARK
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 8,
    padding: SPACING.md,
    fontSize: 16,
    color: COLORS.TEXT_DARK,
    marginBottom: SPACING.md,
    backgroundColor: COLORS.BG_LIGHT
  },
  inputText: {
    fontSize: 16,
    color: COLORS.TEXT_DARK
  },
  dateTimeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  dateInput: {
    flex: 1,
    marginRight: SPACING.sm
  },
  timeInput: {
    flex: 1,
    marginLeft: SPACING.sm
  },
  createButton: {
    backgroundColor: COLORS.SECONDARY,
    padding: SPACING.md,
    borderRadius: 8,
    alignItems: 'center',
    margin: SPACING.md
  },
  buttonDisabled: {
    opacity: 0.6
  },
  createButtonText: {
    color: COLORS.BG_LIGHT,
    fontSize: 18,
    fontWeight: 'bold'
  },
  modalContainer: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  closeButton: {
    fontSize: 24,
    color: COLORS.TEXT_DARK
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK
  },
  doneButton: {
    fontSize: 16,
    color: COLORS.SECONDARY
  },
  filterTabs: {
    flexDirection: 'row',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER,
    gap: SPACING.sm
  },
  filterTab: {
    flex: 1,
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.md,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    alignItems: 'center'
  },
  filterTabActive: {
    borderColor: COLORS.SECONDARY,
    backgroundColor: COLORS.SECONDARY_LIGHT
  },
  filterTabText: {
    fontSize: 13,
    color: COLORS.TEXT_LIGHT,
    fontWeight: '500'
  },
  filterTabTextActive: {
    color: COLORS.SECONDARY,
    fontWeight: '600'
  },
  teamList: {
    padding: SPACING.md
  },
  teamCard: {
    padding: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 8,
    marginBottom: SPACING.sm,
    backgroundColor: COLORS.BG_LIGHT
  },
  teamCardHeader: {
    marginBottom: SPACING.sm
  },
  teamInfo: {
    flex: 1
  },
  teamNameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: SPACING.xs
  },
  teamName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.TEXT_DARK,
    flex: 1
  },
  myTeamBadge: {
    fontSize: 12,
    color: COLORS.SUCCESS,
    fontWeight: '600',
    marginLeft: SPACING.sm
  },
  teamCity: {
    fontSize: 14,
    color: COLORS.TEXT_LIGHT,
    marginBottom: SPACING.sm
  },
  teamDetails: {
    marginTop: SPACING.sm
  },
  teamDetail: {
    fontSize: 13,
    color: COLORS.TEXT_LIGHT,
    marginBottom: SPACING.xs
  },
  captainName: {
    fontWeight: '600',
    color: COLORS.TEXT_DARK
  },
  playerList: {
    padding: SPACING.md
  },
  playerCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 8,
    marginBottom: SPACING.sm,
    backgroundColor: COLORS.BG_LIGHT
  },
  playerCardSelected: {
    borderColor: COLORS.SECONDARY,
    backgroundColor: COLORS.SECONDARY_LIGHT
  },
  playerInfo: {
    flex: 1
  },
  playerName: {
    fontSize: 16,
    color: COLORS.TEXT_DARK
  },
  playerNameSelected: {
    color: COLORS.SECONDARY
  },
  playerNumber: {
    fontSize: 14,
    color: COLORS.TEXT_LIGHT
  },
  playerNumberSelected: {
    color: COLORS.SECONDARY
  },
  checkmark: {
    fontSize: 20,
    color: COLORS.SECONDARY
  }
});
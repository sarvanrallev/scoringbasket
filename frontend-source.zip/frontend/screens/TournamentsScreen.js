import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  RefreshControl,
  FlatList,
  Modal,
  TextInput
} from 'react-native';
import { useRouter } from 'expo-router';
import { tournamentsAPI } from '../services/apiService';
import { COLORS, SPACING } from '../config';

export default function TournamentsScreen() {
  const router = useRouter();
  const [tournaments, setTournaments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [title, setTitle] = useState('');
  const [maxTeams, setMaxTeams] = useState('8');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    loadTournaments();
  }, []);

  const loadTournaments = async () => {
    setLoading(true);
    try {
      const response = await tournamentsAPI.getTournaments();
      setTournaments(response.tournaments || []);
    } catch (error) {
      Alert.alert('Error', 'Failed to load tournaments');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTournaments();
    setRefreshing(false);
  };

  const handleCreateTournament = async () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter tournament title');
      return;
    }

    setCreating(true);
    try {
      const response = await tournamentsAPI.createTournament({
        title: title,
        format: 'single_elimination',
        max_teams: parseInt(maxTeams) || 8,
        start_date: new Date().toISOString().split('T')[0]
      });

      setTournaments([...tournaments, response.tournament || response]);
      setTitle('');
      setMaxTeams('8');
      setModalVisible(false);
      Alert.alert('Success', 'Tournament created successfully');
    } catch (error) {
      Alert.alert('Error', error.message || 'Failed to create tournament');
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteTournament = (tourId) => {
    Alert.alert('Delete Tournament', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await tournamentsAPI.deleteTournament(tourId);
            setTournaments(tournaments.filter(t => t.id !== tourId));
            Alert.alert('Success', 'Tournament deleted');
          } catch (error) {
            Alert.alert('Error', 'Failed to delete tournament');
          }
        }
      }
    ]);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'draft':
        return COLORS.WARNING;
      case 'active':
        return COLORS.SUCCESS;
      case 'completed':
        return COLORS.ACCENT;
      default:
        return COLORS.SECONDARY;
    }
  };

  const renderTournamentCard = ({ item: tour }) => (
    <TouchableOpacity
      style={styles.tournamentCard}
      onPress={() => Alert.alert('Tournament Details', `Viewing details for ${tour.title}`)}
    >
      <View style={styles.tourInfo}>
        <Text style={styles.tourTitle}>{tour.title}</Text>
        <View style={styles.tourMeta}>
          <Text style={styles.metaText}>
            {tour.teams?.length || 0} / {tour.max_teams || 8} Teams
          </Text>
          <Text style={styles.metaText}>
            Format: {tour.format?.replace('_', ' ') || 'Single Elim'}
          </Text>
        </View>
      </View>

      <View style={[styles.statusBadge, { backgroundColor: getStatusColor(tour.status) }]}>
        <Text style={styles.statusText}>
          {tour.status?.charAt(0).toUpperCase() + tour.status?.slice(1) || 'Draft'}
        </Text>
      </View>

      <View style={styles.cardActions}>
        <TouchableOpacity
          style={[styles.actionBtn, styles.viewBtn]}
          onPress={() => Alert.alert('Tournament Details', `Viewing details for ${tour.title}`)}
        >
          <Text style={styles.actionBtnText}>View</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.actionBtn, styles.deleteBtn]}
          onPress={() => handleDeleteTournament(tour.id)}
        >
          <Text style={styles.deleteBtnText}>🗑️</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>🏆 Tournaments</Text>
        <TouchableOpacity
          style={styles.createButton}
          onPress={() => setModalVisible(true)}
        >
          <Text style={styles.createButtonText}>+ New</Text>
        </TouchableOpacity>
      </View>

      {/* Tournaments List */}
      {tournaments.length > 0 ? (
        <FlatList
          data={tournaments}
          renderItem={renderTournamentCard}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        />
      ) : null}

      {/* Create Tournament Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>New Tournament</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.form}>
              <Text style={styles.label}>Tournament Title *</Text>
              <TextInput
                style={styles.input}
                placeholder="e.g., Spring Championship"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={title}
                onChangeText={setTitle}
                editable={!creating}
              />

              <Text style={styles.label}>Max Teams</Text>
              <TextInput
                style={styles.input}
                placeholder="8"
                placeholderTextColor={COLORS.TEXT_LIGHT}
                value={maxTeams}
                onChangeText={setMaxTeams}
                keyboardType="number-pad"
                editable={!creating}
              />

              <TouchableOpacity
                style={[styles.submitButton, creating && styles.buttonDisabled]}
                onPress={handleCreateTournament}
                disabled={creating}
              >
                {creating ? (
                  <ActivityIndicator color={COLORS.BG_LIGHT} />
                ) : (
                  <Text style={styles.submitButtonText}>Create</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.BG_LIGHT
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.sm,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.BORDER
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.PRIMARY
  },
  createButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 4,
    borderRadius: 5
  },
  createButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 11
  },
  listContent: {
    padding: SPACING.sm
  },
  tournamentCard: {
    backgroundColor: COLORS.BG_SECONDARY,
    borderRadius: 6,
    marginBottom: 6,
    padding: SPACING.sm,
    borderTopWidth: 2,
    borderTopColor: COLORS.SECONDARY
  },
  tourInfo: {
    marginBottom: 6
  },
  tourTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.PRIMARY,
    marginBottom: 4
  },
  tourMeta: {
    gap: 2
  },
  metaText: {
    fontSize: 11,
    color: COLORS.TEXT_SECONDARY
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 2,
    borderRadius: 3,
    marginBottom: 6
  },
  statusText: {
    color: COLORS.BG_LIGHT,
    fontSize: 10,
    fontWeight: '600'
  },
  cardActions: {
    flexDirection: 'row',
    gap: 4
  },
  actionBtn: {
    flex: 1,
    paddingVertical: 6,
    borderRadius: 5,
    alignItems: 'center'
  },
  viewBtn: {
    backgroundColor: COLORS.SECONDARY
  },
  deleteBtn: {
    backgroundColor: COLORS.BG_LIGHT,
    borderWidth: 1,
    borderColor: COLORS.ACCENT
  },
  actionBtnText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 11
  },
  deleteBtnText: {
    fontSize: 13
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end'
  },
  modalContent: {
    backgroundColor: COLORS.BG_LIGHT,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    padding: SPACING.sm,
    paddingBottom: SPACING.md
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.PRIMARY
  },
  closeButton: {
    fontSize: 24,
    color: COLORS.TEXT_SECONDARY
  },
  form: {
    gap: SPACING.sm
  },
  label: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.PRIMARY,
    marginBottom: 2
  },
  input: {
    borderWidth: 1,
    borderColor: COLORS.BORDER,
    borderRadius: 6,
    paddingHorizontal: SPACING.sm,
    paddingVertical: 6,
    fontSize: 13,
    color: COLORS.PRIMARY
  },
  submitButton: {
    backgroundColor: COLORS.SECONDARY,
    paddingVertical: SPACING.sm,
    borderRadius: 6,
    alignItems: 'center',
    marginTop: SPACING.sm
  },
  buttonDisabled: {
    opacity: 0.6
  },
  submitButtonText: {
    color: COLORS.BG_LIGHT,
    fontWeight: '600',
    fontSize: 14
  }
});

import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL, STORAGE_KEYS } from '../config';

// Create axios instance
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15000, // Increased timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
apiClient.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem(STORAGE_KEYS.TOKEN);
    console.log('API Request:', config.method?.toUpperCase(), config.url);
    console.log('Token found:', !!token);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log('Authorization header set');
    } else {
      console.log('No token found in storage');
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
apiClient.interceptors.response.use(
  (response) => response.data,
  async (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized - clear token and redirect to login
      try {
        await AsyncStorage.removeItem(STORAGE_KEYS.TOKEN);
        await AsyncStorage.removeItem(STORAGE_KEYS.USER);
        console.log('Token expired or invalid, cleared from storage');
      } catch (storageError) {
        console.error('Error clearing storage:', storageError);
      }
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (userData) =>
    apiClient.post('/auth/register', userData),
  login: (email, password) =>
    apiClient.post('/auth/login', { email, password }),
  logout: () => apiClient.post('/auth/logout'),
  getProfile: () => apiClient.get('/auth/me'),
  updateProfile: (data) => apiClient.put('/auth/profile', data),
  changePassword: (data) => apiClient.post('/auth/change-password', data),
  deactivateAccount: () => apiClient.post('/auth/deactivate'),
  getFavoritePlayers: () => apiClient.get('/auth/favorite-players'),
  getHandStyles: () => apiClient.get('/auth/hand-styles'),
  getUserByUsername: (username) => apiClient.get(`/auth/users/${username}`),
  getUserById: (userId) => apiClient.get(`/auth/users/id/${userId}`),
  searchUsers: (query, teamId) => apiClient.get('/auth/search-users', {
    params: { q: query, team_id: teamId }
  })
};

// Teams API
export const teamsAPI = {
  getTeams: () => apiClient.get('/games/teams'),
  getTeam: (teamId) => apiClient.get(`/games/teams/${teamId}`),
  createTeam: (data) => apiClient.post('/games/teams', data),
  updateTeam: (teamId, data) => apiClient.put(`/games/teams/${teamId}`, data),
  deleteTeam: (teamId) => apiClient.delete(`/games/teams/${teamId}`),
  myTeams: () => apiClient.get('/games/my-teams'),
  addPlayer: (teamId, playerId) =>
    apiClient.post(`/games/teams/${teamId}/players`, { player_id: playerId }),
  removePlayer: (teamId, userId) =>
    apiClient.delete(`/games/teams/${teamId}/players/${userId}`),
  // Team membership endpoints
  inviteMember: (teamId, phone) =>
    apiClient.post(`/games/teams/${teamId}/members/invite`, { phone }),
  addMember: (teamId, userId, role = 'member') =>
    apiClient.post(`/games/teams/${teamId}/members/add`, { user_id: userId, role }),
  updateMemberRole: (teamId, memberId, role) =>
    apiClient.put(`/games/teams/${teamId}/members/${memberId}/role`, role),
  removeMember: (teamId, memberId) =>
    apiClient.delete(`/games/teams/${teamId}/members/${memberId}`),
  getTeamMembers: (teamId) => apiClient.get(`/games/teams/${teamId}/members`),
  getTeamWithMembers: (teamId) => apiClient.get(`/games/teams/${teamId}/with-members`)
};

// Games API
export const gamesAPI = {
  getGames: (params) => apiClient.get('/games/games', { params }),
  getGame: (gameId) => apiClient.get(`/games/games/${gameId}`),
  createGame: (data) => apiClient.post('/games/games', data),
  updateGame: (gameId, data) => apiClient.put(`/games/games/${gameId}`, data),
  deleteGame: (gameId) => apiClient.delete(`/games/games/${gameId}`),
  getMyGames: () => apiClient.get('/games/my-games'),
  getMyLiveGames: () => apiClient.get('/games/my-live-games'),
  getUpcomingGames: () => apiClient.get('/games/upcoming'),
  getCompletedGames: () => apiClient.get('/games/completed'),
  getTeamGames: (teamId) => apiClient.get(`/games/teams/${teamId}/games`),
  // Live scoring methods
  getGameEvents: (gameId) => apiClient.get(`/games/games/${gameId}/events`),
  recordGameEvent: (gameId, data) => apiClient.post(`/games/games/${gameId}/events`, data),
  updateGameScore: (gameId, data) => apiClient.post(`/games/games/${gameId}/score`, data),
  getGameStats: (gameId) => apiClient.get(`/games/games/${gameId}/stats`),
  finalizeGame: (gameId) => apiClient.post(`/games/games/${gameId}/finalize`),
  // Player stats methods
  getPlayerStats: (userId) => apiClient.get(`/games/users/${userId}/stats`),
  getPlayerGameStats: (userId) => apiClient.get(`/games/users/${userId}/game-stats`)
};

// Tournaments API
export const tournamentsAPI = {
  getTournaments: () => apiClient.get('/games/tournaments'),
  getTournament: (tourId) => apiClient.get(`/games/tournaments/${tourId}`),
  createTournament: (data) => apiClient.post('/games/tournaments', data),
  updateTournament: (tourId, data) =>
    apiClient.put(`/games/tournaments/${tourId}`, data),
  deleteTournament: (tourId) =>
    apiClient.delete(`/games/tournaments/${tourId}`),
  addTeam: (tourId, teamId) =>
    apiClient.post(`/games/tournaments/${tourId}/teams/${teamId}`),
  getBracket: (tourId) => apiClient.get(`/games/tournaments/${tourId}/bracket`),
  generateBracket: (tourId) =>
    apiClient.post(`/games/tournaments/${tourId}/bracket`)
};

// Social API
export const socialAPI = {
  followUser: (userId) => apiClient.post(`/social/follow/${userId}`),
  unfollowUser: (userId) => apiClient.delete(`/social/follow/${userId}`),
  getFollowers: (userId) => apiClient.get(`/social/followers/${userId}`),
  getFollowing: (userId) => apiClient.get(`/social/following/${userId}`),
  likeGame: (gameId) => apiClient.post(`/social/likes/game/${gameId}`),
  unlikeGame: (gameId) => apiClient.delete(`/social/likes/game/${gameId}`),
  getActivityFeed: (limit = 20) =>
    apiClient.get('/social/activity-feed', { params: { limit } })
};

export default apiClient;

// API Configuration
// For web/iOS simulator use localhost, for physical device use machine IP
// Run: python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
export const API_BASE_URL = 'http://localhost:8000/api';

// Storage Keys
export const STORAGE_KEYS = {
  TOKEN: 'auth_token',
  USER: 'user_data',
  THEME: 'app_theme'
};

// Theme Colors
export const COLORS = {
  PRIMARY: '#1f2937',
  SECONDARY: '#3b82f6',
  ACCENT: '#ef4444',
  SUCCESS: '#10b981',
  WARNING: '#f59e0b',
  DANGER: '#ef4444',
  
  // Backgrounds
  BG_LIGHT: '#ffffff',
  BG_DARK: '#111827',
  BG_SECONDARY: '#f3f4f6',
  
  // Text
  TEXT_PRIMARY: '#1f2937',
  TEXT_SECONDARY: '#6b7280',
  TEXT_LIGHT: '#9ca3af',
  
  // Borders
  BORDER: '#e5e7eb'
};

// Spacing
export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32
};

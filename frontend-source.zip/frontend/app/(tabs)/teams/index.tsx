import React from 'react';
import TeamsScreen from '../../../screens/TeamsScreen';

export default function TeamsIndex() {
  return <TeamsScreen />;
}
import React from 'react';
import TeamDetailsScreen from '../../../screens/TeamDetailsScreen';

export default function TeamDetails() {
  return <TeamDetailsScreen />;
}
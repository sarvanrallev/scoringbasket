import React from 'react';
import GamesScreen from '../../screens/GamesScreen';

export default function GamesTab() {
  return <GamesScreen />;
}

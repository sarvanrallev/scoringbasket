import React from 'react';
import TournamentsScreen from '../../screens/TournamentsScreen';

export default function TournamentsTab() {
  return <TournamentsScreen />;
}
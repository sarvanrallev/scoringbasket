import React from 'react';
import ProfileScreen from '../../screens/ProfileScreen';

export default function ProfileTab() {
  return <ProfileScreen />;
}
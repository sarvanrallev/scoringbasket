import React from 'react';
import LiveScoringScreen from '../screens/LiveScoringScreen';

export default function LiveScoring() {
  return <LiveScoringScreen />;
}

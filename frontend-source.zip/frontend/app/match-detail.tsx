import MatchDetailScreen from '../screens/MatchDetailScreen';

export default MatchDetailScreen;
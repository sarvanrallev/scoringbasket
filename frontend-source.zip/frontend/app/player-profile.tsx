import PlayerProfileScreen from '../screens/PlayerProfileScreen';

export default PlayerProfileScreen;

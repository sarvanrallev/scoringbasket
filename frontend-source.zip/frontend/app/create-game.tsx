import React from 'react';
import CreateGameScreen from '../screens/CreateGameScreen';

export default function CreateGame() {
  return <CreateGameScreen />;
}
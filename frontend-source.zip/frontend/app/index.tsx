import React, { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ActivityIndicator, View } from 'react-native';
import { useRouter } from 'expo-router';
import { COLORS, STORAGE_KEYS } from '../config';

export default function Index() {
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const bootstrapAsync = async () => {
      try {
        console.log('Checking for stored token...');
        const token = await AsyncStorage.getItem(STORAGE_KEYS.TOKEN);
        console.log('Token found on app start:', token ? 'yes' : 'no');
        if (token) {
          console.log('Token value (first 20 chars):', token.substring(0, 20));
          router.replace('/(tabs)');
        } else {
          console.log('No token found, redirecting to register');
          router.replace('/register');
        }
      } catch (e) {
        console.error('Failed to restore token', e);
        router.replace('/register');
      } finally {
        setIsLoading(false);
      }
    };

    bootstrapAsync();
  }, [router]);

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color={COLORS.SECONDARY} />
      </View>
    );
  }

  return null;
}
